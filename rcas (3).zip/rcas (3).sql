-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 25 2021 г., 06:28
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `rcas`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paragraph1` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paragraph2` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `title`, `image`, `paragraph1`, `paragraph2`, `created_at`, `updated_at`) VALUES
(1, 'Статья 1', 'articles\\January2021\\xCHxcSgAHj1c9qUnBhaM.jpg', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis delectus eius eos, eum obcaecati officiis omnis perspiciatis soluta. Accusantium asperiores consectetur cupiditate eligendi ipsam magnam modi, nostrum praesentium quis vitae. Commodi consectetur delectus dolor dolore eius itaque nulla, omnis quibusdam vero voluptate! At beatae illo incidunt possimus qui ratione vitae! Aut eius eligendi eos esse inventore maiores obcaecati pariatur recusandae similique ut, voluptate voluptates. Animi cumque, cupiditate dolorum eaque et illo impedit necessitatibus nihil optio quas quasi quibusdam repellendus similique tempore temporibus voluptatem voluptates. Ab consectetur dignissimos dolore dolorum eum excepturi ipsum iusto neque nesciunt nisi numquam optio, placeat possimus quasi quia, quibusdam quis rerum tempore vero voluptatum? Ab aperiam assumenda culpa debitis deleniti dolorem doloremque in ipsam libero maiores officia quibusdam, quidem quisquam, tempora, vero? Accusantium consequuntur deleniti earum, et explicabo facere facilis iusto molestiae porro praesentium quasi qui, quis repellat veritatis voluptates. Aliquid beatae cumque dolorum natus pariatur. Itaque optio quaerat quia vel. Dolorem iure nam natus quaerat quasi saepe, veritatis? Assumenda id iure minus provident voluptate. Aliquid assumenda atque delectus deleniti deserunt esse exercitationem facilis id illum, laudantium minus nam, porro provident quia quisquam quo soluta? Aspernatur dolorum et maxime modi nulla omnis porro praesentium, quas sunt.', '<pre style=\"background-color: #2b2b2b; color: #a9b7c6; font-family: \'JetBrains Mono\',monospace; font-size: 9,8pt;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad autem d<br />electus deleniti, dolores error fugiat in ipsa, itaque, libero maior<br />es nesciunt<br /> nobis obcaecati placeat possimus praesentium quae quibusdam quis quos ratione reiciendi<br />s rerum saepe similique totam vel velit. At incidunt molestias odit, <br />quis tempore unde v<br /><br />itae voluptas. Ad adipisci aspernatur beatae blanditiis corporis cupiditate dignissimos dolor </pre>\r\n<figure class=\"image align-left\"><img style=\"width: 244px; height: 205px;\" title=\"article\" src=\"http://RCAS.kz/storage/articles/January2021/article4.jpg\" alt=\"fdg\" width=\"458\" height=\"385\" />\r\n<figcaption>df</figcaption>\r\n</figure>\r\n<pre style=\"background-color: #2b2b2b; color: #a9b7c6; font-family: \'JetBrains Mono\',monospace; font-size: 9,8pt;\">ducimus, error esse facere fuga fugiat incidunt iure laborum maxime m<br />olestias natus necessitatibus <br />non officiis omnis optio perferendis placeat quia quis saepe sint, tempora unde velit <br />voluptatem! Ab alias consequatur <br /><br />eligendi, excepturi incidunt iure labore maxime minus molestiae, optio, perspiciatis<br /> quo rerum veniam? Ipsam!</pre>\r\n<p style=\"font-family: \'JetBrains Mono\', monospace;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad autem delectus deleni<br />ti, dolores error fugiat in ipsa, itaque, libero maiores nesciunt nobis obcaecati placeat poss<br />imus praesentium&nbsp;<br />quae quibusdam quis quos ratione reiciendis rerum saepe similique totam vel velit. At incidunt molestia<br />s odit, quis tempore&nbsp;<br />unde vitae voluptas. Ad adipisci aspernatur beatae blanditiis corporis cupiditate dignissimos dolor du<br />cimus, error esse&nbsp;<br />facere fuga fugiat incidunt iure laborum maxime molestias natus n</p>\r\n<p style=\"font-family: \'JetBrains Mono\', monospace;\">ecessitatibus non officiis omnis optio perferendis placeat&nbsp;<br />quia quis saepe sint, tempora unde velit voluptatem! Ab alias consequatur eligendi, excepturi inci<br />dunt iure labore maxime&nbsp;<br />minus molestiae, optio, perspiciatis quo rerum veniam? Ipsam!</p>\r\n<pre style=\"font-family: \'JetBrains Mono\', monospace;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad autem delec<br />tus deleniti, dolores error fugiat in ipsa</pre>', '2021-01-08 11:43:50', '2021-01-08 13:33:01');

-- --------------------------------------------------------

--
-- Структура таблицы `bids`
--

CREATE TABLE `bids` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `bids`
--

INSERT INTO `bids` (`id`, `name`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'Noname', '+7(777) 777-77-77', '2021-01-18 10:27:38', '2021-01-18 10:27:38'),
(2, 'dfvf', 'rdfg', '2021-01-20 01:24:19', '2021-01-20 01:24:19'),
(3, 'sdfghsadfgh', 'sadfg', '2021-01-20 01:24:57', '2021-01-20 01:24:57'),
(7, 'edsfgh', 'sdfgh', '2021-01-20 03:15:28', '2021-01-20 03:15:28'),
(8, 'wqerty', 'asdfghj', '2021-01-20 03:20:36', '2021-01-20 03:20:36'),
(9, 'dfdgf', 'sdfvfb', '2021-01-20 03:21:35', '2021-01-20 03:21:35'),
(10, 'Al', '123456789', '2021-01-20 03:26:17', '2021-01-20 03:26:17'),
(11, 'edfg', 'sdfgh', '2021-01-24 21:59:18', '2021-01-24 21:59:18'),
(12, 'dfvb', 'dfgh', '2021-01-24 22:13:11', '2021-01-24 22:13:11'),
(13, 'dsfgh', 'dsfgh', '2021-01-24 22:13:33', '2021-01-24 22:13:33'),
(14, 'dfgh', 'edreftgyhjh', '2021-01-24 22:15:33', '2021-01-24 22:15:33'),
(15, 'werdfg', 'sdfg', '2021-01-24 22:17:23', '2021-01-24 22:17:23'),
(16, 'dfgh', 'efgfh', '2021-01-24 22:18:00', '2021-01-24 22:18:00'),
(17, 'sadfgh', 'sadfghjk', '2021-01-24 22:18:15', '2021-01-24 22:18:15');

-- --------------------------------------------------------

--
-- Структура таблицы `community_blocks`
--

CREATE TABLE `community_blocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `community_blocks`
--

INSERT INTO `community_blocks` (`id`, `title`, `image`, `body`, `footer`, `created_at`, `updated_at`) VALUES
(1, 'Палаты предпринимателей города Алматы', 'community-blocks\\January2021\\WEyPQwpe08PSgClllOHf.png', 'Палаты предпринимателей города Алматы выражаю Вам благодарсность за активную работу по проведению обучающих семинаров по безопасности и охраны труда сотрудников предприятий города Алматы.', 'Участники: руководящий состав', '2021-01-08 05:34:18', '2021-01-20 00:50:19'),
(2, 'Управление Делами Президента Республики Казахстан', 'community-blocks\\January2021\\3l4XoeBbA3nW6M4l2gNH.png', 'Управление Делами Президента Республики Казахстанвыражает благодарность за семинар от 13 мая 2016 года проведенный по Вашей инициативе для работников подведомственных организаций Управления по вопросам обеспечения безопасности и охраны труда и разъяснений положений нового трудового законодательства.', 'Участники: 50 подведомственных организаций', '2021-01-20 00:51:20', '2021-01-20 00:51:20'),
(3, 'ТОО “ХУАВЕЙ”', 'community-blocks\\January2021\\zeUnxt3YdrG4MJ8JD6JL.png', 'выражает глубокую признательность всему коллективу Республиканского центра подготовки и повышения квалификации за прекрасную организацию и проведения научно – педагогического семинара.', 'Участники: 16 работников', '2021-01-20 00:52:01', '2021-01-20 00:52:01'),
(4, 'МЕЛОМАН HOME VIDEO', 'community-blocks\\January2021\\GCkew1XmpCVTU8SpIi4l.png', 'считает, что семинар был полезен и актуален, обеспечивающий безопасность и охраны труда в организации. Желаем плодотворной работы Республиканского центра подготовки и повышения квалификации.', 'Участники: 68 работников', '2021-01-20 00:53:30', '2021-01-20 00:53:30');

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Антитеррор - каз', NULL, '2021-01-08 11:44:26', '2021-01-21 05:05:16'),
(2, 'Главная', NULL, '2021-01-11 02:42:00', '2021-01-20 23:57:13'),
(3, 'Антитеррор - рус', NULL, '2021-01-21 16:43:07', '2021-01-21 16:43:08'),
(4, 'БиОТ - рус', NULL, NULL, NULL),
(5, 'БиОТ - каз', NULL, NULL, NULL),
(6, 'Парамедика - рус', NULL, NULL, NULL),
(7, 'Парамедика - каз', NULL, NULL, NULL),
(8, 'ПТМ - рус', NULL, NULL, NULL),
(9, 'ПТМ - каз', NULL, NULL, NULL),
(10, 'СЭЗ - каз', NULL, NULL, NULL),
(11, 'СЭЗ - рус', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `course_codes`
--

CREATE TABLE `course_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `result` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `course_codes`
--

INSERT INTO `course_codes` (`id`, `course_id`, `code`, `is_activated`, `user_id`, `created_at`, `updated_at`, `result`) VALUES
(1, 1, '618225', 1, 3, '2021-01-11 02:19:02', '2021-01-12 00:59:11', '3 из 3'),
(2, 1, '581031', 1, 2, '2021-01-18 09:51:14', '2021-01-18 10:09:45', '1 из 3');

-- --------------------------------------------------------

--
-- Структура таблицы `data_rows`
--

CREATE TABLE `data_rows` (
  `id` int(10) UNSIGNED NOT NULL,
  `data_type_id` int(10) UNSIGNED NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `browse` tinyint(1) NOT NULL DEFAULT 1,
  `read` tinyint(1) NOT NULL DEFAULT 1,
  `edit` tinyint(1) NOT NULL DEFAULT 1,
  `add` tinyint(1) NOT NULL DEFAULT 1,
  `delete` tinyint(1) NOT NULL DEFAULT 1,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`) VALUES
(1, 1, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, '{}', 1),
(3, 1, 'email', 'text', 'Email', 1, 1, 1, 1, 1, 1, '{}', 3),
(4, 1, 'password', 'password', 'Password', 1, 0, 0, 1, 1, 0, '{}', 4),
(5, 1, 'remember_token', 'text', 'Remember Token', 0, 0, 0, 0, 0, 0, '{}', 5),
(6, 1, 'created_at', 'timestamp', 'Создан', 0, 1, 1, 0, 0, 0, '{}', 6),
(7, 1, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(8, 1, 'avatar', 'image', 'Аватар', 0, 0, 0, 0, 0, 0, '{}', 8),
(9, 1, 'user_belongsto_role_relationship', 'relationship', 'Роль', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10),
(10, 1, 'user_belongstomany_role_relationship', 'relationship', 'Roles', 0, 0, 0, 0, 0, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}', 11),
(11, 1, 'settings', 'hidden', 'Settings', 0, 0, 0, 0, 0, 0, '{}', 12),
(12, 2, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(13, 2, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(14, 2, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(15, 2, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(16, 3, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(17, 3, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(18, 3, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(19, 3, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(20, 3, 'display_name', 'text', 'Display Name', 1, 1, 1, 1, 1, 1, NULL, 5),
(21, 1, 'role_id', 'text', 'Role', 0, 0, 0, 0, 0, 0, '{}', 9),
(22, 1, 'company_name', 'text', 'Компания', 0, 1, 1, 1, 1, 1, '{}', 3),
(23, 1, 'fullname', 'text', 'ФИО', 0, 1, 1, 1, 1, 1, '{}', 4),
(24, 1, 'position', 'text', 'Должность', 0, 1, 1, 1, 1, 1, '{}', 5),
(25, 1, 'phone', 'text', 'Телефон', 0, 1, 1, 1, 1, 1, '{}', 6),
(26, 1, 'email_verified_at', 'timestamp', 'Email Verified At', 0, 0, 0, 0, 0, 0, '{}', 9),
(27, 5, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(28, 5, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(29, 5, 'image', 'image', 'Картинка', 0, 1, 1, 1, 1, 1, '{}', 3),
(30, 5, 'body', 'text_area', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 4),
(31, 5, 'footer', 'text', 'Футер', 0, 1, 1, 1, 1, 1, '{}', 5),
(32, 5, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 6),
(33, 5, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(34, 6, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(35, 6, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(36, 6, 'image', 'image', 'Картинка', 0, 1, 1, 1, 1, 1, '{}', 3),
(37, 6, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 4),
(38, 6, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 5),
(39, 7, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(40, 7, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(41, 7, 'image', 'image', 'Картинка', 0, 1, 1, 1, 1, 1, '{}', 3),
(42, 7, 'percent', 'number', 'Процент', 0, 1, 1, 1, 1, 1, '{}', 4),
(43, 7, 'info1', 'text', 'Инфо 1', 0, 1, 1, 1, 1, 1, '{}', 5),
(44, 7, 'info2', 'text', 'Инфо 2', 0, 1, 1, 1, 1, 1, '{}', 6),
(45, 7, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 7),
(46, 7, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(47, 8, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(48, 8, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(49, 8, 'image', 'image', 'Картинка', 0, 1, 1, 1, 1, 1, '{}', 3),
(50, 8, 'paragraph1', 'text_area', 'Параграф 1', 0, 1, 1, 1, 1, 1, '{}', 4),
(51, 8, 'paragraph2', 'text_area', 'Параграф 2', 0, 1, 1, 1, 1, 1, '{}', 5),
(52, 8, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 6),
(53, 8, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(54, 9, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(55, 9, 'title', 'text_area', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(56, 9, 'body', 'text_area', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 3),
(57, 9, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 4),
(58, 9, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 5),
(59, 10, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(60, 10, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 3),
(61, 10, 'video', 'text', 'Видео', 0, 1, 1, 1, 1, 1, '{}', 4),
(62, 10, 'course_id', 'text', 'Course Id', 0, 0, 0, 1, 1, 0, '{}', 2),
(63, 10, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 5),
(64, 10, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(65, 10, 'material_belongsto_course_relationship', 'relationship', 'Курс', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Course\",\"table\":\"courses\",\"type\":\"belongsTo\",\"column\":\"course_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 7),
(66, 11, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(67, 11, 'body', 'text_area', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 3),
(68, 11, 'isTrue', 'checkbox', 'Верный', 0, 1, 1, 1, 1, 1, '{}', 4),
(69, 11, 'question_id', 'text', 'Question Id', 0, 0, 0, 1, 1, 0, '{}', 2),
(70, 11, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 5),
(71, 11, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(72, 11, 'option_belongsto_question_relationship', 'relationship', 'Вопрос', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Question\",\"table\":\"questions\",\"type\":\"belongsTo\",\"column\":\"question_id\",\"key\":\"id\",\"label\":\"body\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 7),
(73, 12, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(74, 12, 'body', 'text_area', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 3),
(75, 12, 'test_id', 'text', 'Test Id', 0, 0, 0, 1, 1, 0, '{}', 2),
(76, 12, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 4),
(77, 12, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 5),
(78, 12, 'question_belongsto_test_relationship', 'relationship', 'Тест', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Test\",\"table\":\"tests\",\"type\":\"belongsTo\",\"column\":\"test_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(79, 13, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(80, 13, 'title', 'text', 'Название', 0, 1, 1, 1, 1, 1, '{}', 3),
(81, 13, 'course_id', 'text', 'Course Id', 0, 0, 0, 1, 1, 0, '{}', 2),
(82, 13, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 4),
(83, 13, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 5),
(84, 13, 'test_belongsto_course_relationship', 'relationship', 'Курс', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Course\",\"table\":\"courses\",\"type\":\"belongsTo\",\"column\":\"course_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(85, 14, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(86, 14, 'title', 'text_area', 'Название', 0, 1, 1, 1, 1, 1, '{}', 2),
(87, 14, 'salary', 'text_area', 'Зарплата', 0, 1, 1, 1, 1, 1, '{}', 3),
(88, 14, 'body', 'text_area', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 4),
(89, 14, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 5),
(90, 14, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(91, 9, 'course_hasmany_material_relationship', 'relationship', 'Материалы', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Material\",\"table\":\"materials\",\"type\":\"hasMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(92, 9, 'course_hasmany_test_relationship', 'relationship', 'Тесты', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Test\",\"table\":\"tests\",\"type\":\"hasMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 7),
(93, 15, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(94, 15, 'image', 'image', 'Картинка', 0, 1, 1, 1, 1, 1, '{}', 2),
(95, 15, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 3),
(96, 15, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 4),
(97, 16, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(98, 16, 'course_id', 'text', 'Course Id', 0, 1, 1, 1, 1, 1, '{}', 2),
(99, 16, 'code', 'text', 'Код', 0, 1, 1, 0, 0, 0, '{}', 4),
(100, 16, 'is_activated', 'checkbox', 'Активирован', 1, 1, 1, 1, 0, 0, '{}', 5),
(101, 16, 'user_id', 'text', 'User Id', 0, 1, 1, 1, 1, 1, '{}', 3),
(102, 16, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 6),
(103, 16, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(104, 16, 'course_code_belongsto_course_relationship', 'relationship', 'Курс', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Course\",\"table\":\"courses\",\"type\":\"belongsTo\",\"column\":\"course_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(105, 16, 'course_code_belongsto_user_relationship', 'relationship', 'Пользователь', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"user_id\",\"key\":\"id\",\"label\":\"email\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(106, 17, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(107, 17, 'name', 'text', 'Имя', 0, 1, 1, 1, 1, 1, '{}', 2),
(108, 17, 'phone', 'text', 'Телефон', 0, 1, 1, 1, 1, 1, '{}', 3),
(109, 17, 'created_at', 'timestamp', 'Создано', 0, 1, 1, 1, 0, 1, '{}', 4),
(110, 17, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 5),
(111, 16, 'result', 'text', 'Результат', 0, 1, 1, 1, 1, 1, '{}', 8),
(112, 18, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(113, 18, 'name', 'text', 'Имя', 0, 1, 1, 1, 1, 1, '{}', 3),
(114, 18, 'phone', 'text', 'Телефон', 0, 1, 1, 1, 1, 1, '{}', 4),
(115, 18, 'text', 'text_area', 'Сообщение', 0, 1, 1, 1, 1, 1, '{}', 5),
(116, 18, 'vacancy_id', 'text', 'Vacancy Id', 0, 1, 1, 1, 1, 1, '{}', 2),
(117, 18, 'created_at', 'timestamp', 'Создано', 0, 1, 1, 1, 0, 1, '{}', 6),
(118, 18, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(119, 18, 'vacancy_bid_belongsto_vacancy_relationship', 'relationship', 'Вакансия', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\Vacancy\",\"table\":\"vacancies\",\"type\":\"belongsTo\",\"column\":\"vacancy_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"articles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(120, 6, 'body', 'text', 'Содержание', 0, 1, 1, 1, 1, 1, '{}', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `data_types`
--

CREATE TABLE `data_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT 0,
  `server_side` tinyint(4) NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `data_types`
--

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `policy_name`, `controller`, `description`, `generate_permissions`, `server_side`, `details`, `created_at`, `updated_at`) VALUES
(1, 'users', 'clients', 'Пользователи', 'Пользователи', 'voyager-person', 'App\\Models\\User', 'TCG\\Voyager\\Policies\\UserPolicy', 'TCG\\Voyager\\Http\\Controllers\\VoyagerUserController', NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"desc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 01:58:16', '2021-01-08 03:26:22'),
(2, 'menus', 'menus', 'Menu', 'Menus', 'voyager-list', 'TCG\\Voyager\\Models\\Menu', NULL, '', '', 1, 0, NULL, '2021-01-08 01:58:16', '2021-01-08 01:58:16'),
(3, 'roles', 'roles', 'Role', 'Roles', 'voyager-lock', 'TCG\\Voyager\\Models\\Role', NULL, 'TCG\\Voyager\\Http\\Controllers\\VoyagerRoleController', '', 1, 0, NULL, '2021-01-08 01:58:16', '2021-01-08 01:58:16'),
(5, 'community_blocks', 'community-blocks', 'Блок Сообщества', 'Блок Сообщества', NULL, 'App\\Models\\CommunityBlock', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 04:29:00', '2021-01-08 04:29:40'),
(6, 'header_slides', 'header-slides', 'Главный Слайдер', 'Главный Слайдер', NULL, 'App\\Models\\HeaderSlide', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 04:30:58', '2021-01-21 00:23:57'),
(7, 'organization_blocks', 'organization-blocks', 'Блок Организаций', 'Блок Организаций', NULL, 'App\\Models\\OrganizationBlock', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(8, 'articles', 'articles', 'Статья', 'Статья', NULL, 'App\\Models\\Article', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:19:12', '2021-01-18 09:37:47'),
(9, 'courses', 'courses', 'Курс', 'Курсы', NULL, 'App\\Models\\Course', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:20:11', '2021-01-08 13:20:39'),
(10, 'materials', 'materials', 'Материал', 'Материалы', NULL, 'App\\Models\\Material', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:21:35', '2021-01-08 14:05:39'),
(11, 'options', 'options', 'Вариант', 'Варианты', NULL, 'App\\Models\\Option', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:34:13', '2021-01-11 03:36:26'),
(12, 'questions', 'questions', 'Вопрос', 'Вопросы', NULL, 'App\\Models\\Question', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:36:38', '2021-01-12 01:08:41'),
(13, 'tests', 'tests', 'Тест', 'Тесты', NULL, 'App\\Models\\Test', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:38:01', '2021-01-08 13:56:27'),
(14, 'vacancies', 'vacancies', 'Вакансия', 'Вакансии', NULL, 'App\\Models\\Vacancy', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-08 11:40:11', '2021-01-08 12:55:47'),
(15, 'org_sliders', 'org-sliders', 'Слайдер Организации', 'Слайдер Организации', NULL, 'App\\Models\\OrgSlider', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(16, 'course_codes', 'course-codes', 'Код для Курса', 'Код для Курса', NULL, 'App\\Models\\CourseCode', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-11 02:00:34', '2021-01-18 10:12:32'),
(17, 'bids', 'bids', 'Заявки', 'Заявки', NULL, 'App\\Models\\Bid', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(18, 'vacancy_bids', 'vacancy-bids', 'Заявки на вакансии', 'Заявки на вакансии', NULL, 'App\\Models\\VacancyBid', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-01-20 04:59:14', '2021-01-20 04:59:52');

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `header_slides`
--

CREATE TABLE `header_slides` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `header_slides`
--

INSERT INTO `header_slides` (`id`, `title`, `body`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Технические услуги', NULL, 'header-slides\\January2021\\L1AAxQINsbI21oXhJche.jpg', '2021-01-08 05:25:58', '2021-01-18 06:21:35'),
(2, 'Обучение', 'по вопросам пожарной безопасности и охраны труда', 'header-slides\\January2021\\WRkEmZdQYQY8bbXZBnFH.jpg', '2021-01-08 05:32:01', '2021-01-21 00:24:26'),
(3, 'Составление документации', NULL, 'header-slides\\January2021\\0wuPvhOHq1hBsna03BAQ.jpg', '2021-01-18 06:22:16', '2021-01-18 06:22:16'),
(4, 'Аутсорсинг', NULL, 'header-slides\\January2021\\j4cgL7hpbJlE8CKV4YwO.jpg', '2021-01-18 06:23:03', '2021-01-18 06:23:03');

-- --------------------------------------------------------

--
-- Структура таблицы `materials`
--

CREATE TABLE `materials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `materials`
--

INSERT INTO `materials` (`id`, `title`, `video`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 'Material 1', 'https://www.youtube.com/embed/kXYiU_JCYtU', 1, '2021-01-08 11:45:05', '2021-01-08 11:45:05');

-- --------------------------------------------------------

--
-- Структура таблицы `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `menus`
--

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2021-01-08 01:58:16', '2021-01-08 01:58:16');

-- --------------------------------------------------------

--
-- Структура таблицы `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`) VALUES
(1, 1, 'Dashboard', '', '_self', 'voyager-boat', NULL, NULL, 1, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.dashboard', NULL),
(2, 1, 'Media', '', '_self', 'voyager-images', NULL, NULL, 5, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.media.index', NULL),
(3, 1, 'Users', '', '_self', 'voyager-person', '#000000', NULL, 3, '2021-01-08 01:58:16', '2021-01-08 03:30:43', 'voyager.clients.index', 'null'),
(4, 1, 'Roles', '', '_self', 'voyager-lock', NULL, NULL, 2, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.roles.index', NULL),
(5, 1, 'Tools', '', '_self', 'voyager-tools', NULL, NULL, 9, '2021-01-08 01:58:16', '2021-01-08 01:58:16', NULL, NULL),
(6, 1, 'Menu Builder', '', '_self', 'voyager-list', NULL, 5, 10, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.menus.index', NULL),
(7, 1, 'Database', '', '_self', 'voyager-data', NULL, 5, 11, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.database.index', NULL),
(8, 1, 'Compass', '', '_self', 'voyager-compass', NULL, 5, 12, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.compass.index', NULL),
(9, 1, 'BREAD', '', '_self', 'voyager-bread', NULL, 5, 13, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.bread.index', NULL),
(10, 1, 'Settings', '', '_self', 'voyager-settings', NULL, NULL, 14, '2021-01-08 01:58:16', '2021-01-08 01:58:16', 'voyager.settings.index', NULL),
(11, 1, 'Hooks', '', '_self', 'voyager-hook', NULL, 5, 13, '2021-01-08 01:58:17', '2021-01-08 01:58:17', 'voyager.hooks', NULL),
(12, 1, 'Community Blocks', '', '_self', NULL, NULL, NULL, 15, '2021-01-08 04:29:00', '2021-01-08 04:29:00', 'voyager.community-blocks.index', NULL),
(13, 1, 'Главный Слайдер', '', '_self', NULL, NULL, NULL, 16, '2021-01-08 04:30:58', '2021-01-08 04:30:58', 'voyager.header-slides.index', NULL),
(14, 1, 'Блок Организаций', '', '_self', NULL, NULL, NULL, 17, '2021-01-08 04:32:31', '2021-01-08 04:32:31', 'voyager.organization-blocks.index', NULL),
(15, 1, 'Статья', '', '_self', NULL, NULL, NULL, 18, '2021-01-08 11:19:12', '2021-01-08 11:19:12', 'voyager.articles.index', NULL),
(16, 1, 'Курсы', '', '_self', NULL, NULL, NULL, 19, '2021-01-08 11:20:11', '2021-01-08 11:20:11', 'voyager.courses.index', NULL),
(17, 1, 'Материалы', '', '_self', NULL, NULL, NULL, 20, '2021-01-08 11:21:35', '2021-01-08 11:21:35', 'voyager.materials.index', NULL),
(18, 1, 'Варианты', '', '_self', NULL, NULL, NULL, 21, '2021-01-08 11:34:13', '2021-01-08 11:34:13', 'voyager.options.index', NULL),
(19, 1, 'Вопросы', '', '_self', NULL, NULL, NULL, 22, '2021-01-08 11:36:38', '2021-01-08 11:36:38', 'voyager.questions.index', NULL),
(20, 1, 'Тесты', '', '_self', NULL, NULL, NULL, 23, '2021-01-08 11:38:01', '2021-01-08 11:38:01', 'voyager.tests.index', NULL),
(21, 1, 'Вакансии', '', '_self', NULL, NULL, NULL, 24, '2021-01-08 11:40:11', '2021-01-08 11:40:11', 'voyager.vacancies.index', NULL),
(22, 1, 'Слайдер Организации', '', '_self', NULL, NULL, NULL, 25, '2021-01-11 00:34:03', '2021-01-11 00:34:03', 'voyager.org-sliders.index', NULL),
(23, 1, 'Код для Курса', '', '_self', NULL, NULL, NULL, 26, '2021-01-11 02:00:34', '2021-01-11 02:00:34', 'voyager.course-codes.index', NULL),
(24, 1, 'Заявки', '', '_self', NULL, NULL, NULL, 27, '2021-01-18 06:40:24', '2021-01-18 06:40:24', 'voyager.bids.index', NULL),
(25, 1, 'Заявки на вакансии', '', '_self', NULL, NULL, NULL, 28, '2021-01-20 04:59:14', '2021-01-20 04:59:14', 'voyager.vacancy-bids.index', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `metas`
--

CREATE TABLE `metas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `metas`
--

INSERT INTO `metas` (`id`, `url`, `title`, `description`, `keywords`) VALUES
(1, 'index', 'Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(2, 'vacancy', 'Вакансии - Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(3, 'news', 'Новости - Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(4, 'about', 'О нас - Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(5, 'contacts', 'Контакты - Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(6, 'faq', 'Часто задаваемые вопросы - Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(7, 'login', 'Центр подготовки и повышения квалификации по г. Алматы', 'Центр подготовки и повышения квалификации по г. Алматы', 'Центр подготовки и повышения квалификации по г. Алматы'),
(8, 'register', 'Центр подготовки и повышения квалификации по г. Алматы', 'Центр подготовки и повышения квалификации по г. Алматы', 'Центр подготовки и повышения квалификации по г. Алматы'),
(9, 'index', 'Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации'),
(10, 'index', 'Республиканский центр подготовки и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации', 'Республиканский центр подготовки  и повышения квалификации');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2019_08_19_000000_create_failed_jobs_table', 1),
(7, '2016_01_01_000000_add_voyager_user_fields', 2),
(8, '2016_01_01_000000_create_data_types_table', 2),
(9, '2016_05_19_173453_create_menu_table', 2),
(10, '2016_10_21_190000_create_roles_table', 2),
(11, '2016_10_21_190000_create_settings_table', 2),
(12, '2016_11_30_135954_create_permission_table', 2),
(13, '2016_11_30_141208_create_permission_role_table', 2),
(14, '2016_12_26_201236_data_types__add__server_side', 2),
(15, '2017_01_13_000000_add_route_to_menu_items_table', 2),
(16, '2017_01_14_005015_create_translations_table', 2),
(17, '2017_01_15_000000_make_table_name_nullable_in_permissions_table', 2),
(18, '2017_03_06_000000_add_controller_to_data_types_table', 2),
(19, '2017_04_21_000000_add_order_to_data_rows_table', 2),
(20, '2017_07_05_210000_add_policyname_to_data_types_table', 2),
(21, '2017_08_05_000000_add_group_to_settings_table', 2),
(22, '2017_11_26_013050_add_user_role_relationship', 2),
(23, '2017_11_26_015000_create_user_roles_table', 2),
(24, '2018_03_11_000000_add_user_settings', 2),
(25, '2018_03_14_000000_add_details_to_data_types_table', 2),
(26, '2018_03_16_000000_make_settings_value_nullable', 2),
(27, '2021_01_08_085303_create_header_slides_table', 3),
(28, '2021_01_08_085336_create_community_blocks_table', 3),
(29, '2021_01_08_085400_create_organization_blocks_table', 3),
(30, '2021_01_08_130126_create_vacancies_table', 4),
(31, '2021_01_08_130530_create_courses_table', 4),
(32, '2021_01_08_130657_create_articles_table', 4),
(33, '2021_01_08_130909_create_tests_table', 4),
(34, '2021_01_08_133544_create_questions_table', 4),
(35, '2021_01_08_133609_create_options_table', 4),
(36, '2021_01_08_133645_create_materials_table', 4),
(37, '2021_01_08_162449_add_correct_options', 5),
(38, '2021_01_11_043325_create_org_sliders_table', 6),
(39, '2021_01_11_050236_create_course_codes_table', 7),
(40, '2021_01_11_171420_add_column_course_codes', 8),
(41, '2021_01_18_085239_create_metas_table', 9),
(42, '2021_01_18_113542_create_bids_table', 10),
(43, '2021_01_20_092943_create_vacancy_bids_table', 11),
(44, '2021_01_21_051601_add_body_column_to_header_sliders', 12);

-- --------------------------------------------------------

--
-- Структура таблицы `options`
--

CREATE TABLE `options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isTrue` tinyint(1) DEFAULT 0,
  `question_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `options`
--

INSERT INTO `options` (`id`, `body`, `isTrue`, `question_id`, `created_at`, `updated_at`) VALUES
(7, 'При введении в действие новых или изменении ранее разработанных правил, норм, инструкций по пожарной безопасности, иных документов, содержащих требования пожарной безопасности', 0, 4, '2021-01-12 01:10:43', '2021-01-12 01:10:43'),
(8, 'При изменении технологического процесса производства, замене или модернизации оборудования, инструментов, исходного сырья, материалов, а также изменении других факторов, влияющих на противопожарное состояние.', 0, 4, '2021-01-12 01:11:06', '2021-01-12 01:11:06'),
(9, 'При приеме в отдел (рабочую группу) нового работника', 0, 4, '2021-01-12 01:11:19', '2021-01-12 01:11:19'),
(10, 'При нарушении работниками организации требований пожарной безопасности, которые могли привести или привели к пожару', 0, 4, '2021-01-12 01:11:37', '2021-01-12 01:11:37'),
(11, 'За счет средств государства', 0, 5, '2021-01-12 01:12:02', '2021-01-12 01:12:02'),
(12, 'За счет средств работодателя', 0, 5, '2021-01-12 01:12:14', '2021-01-12 01:12:14'),
(13, 'За счет собственных средств работника', 0, 5, '2021-01-12 01:12:34', '2021-01-12 01:12:34'),
(14, 'За иной счет', 0, 5, '2021-01-12 01:15:47', '2021-01-12 01:15:47'),
(15, 'Не реже одного раза в месяц', 0, 6, '2021-01-12 01:16:03', '2021-01-12 01:16:03'),
(16, 'Не реже одного раза в квартал', 0, 6, '2021-01-12 01:16:42', '2021-01-12 01:16:42'),
(17, 'Не реже одного раза в полугодие', 0, 6, '2021-01-12 01:17:05', '2021-01-12 01:17:05'),
(18, 'Не реже одного раза в два года', 0, 6, '2021-01-12 01:17:20', '2021-01-12 01:17:20'),
(19, 'Не реже одного раза в полугодие', 0, 7, '2021-01-12 01:17:49', '2021-01-12 01:17:49'),
(20, 'Не реже одного раза в год', 0, 7, '2021-01-12 01:18:06', '2021-01-12 01:18:06'),
(21, 'Не реже одного раза в три года', 0, 7, '2021-01-12 01:18:19', '2021-01-12 01:18:19'),
(22, 'По мере необходимости', 0, 7, '2021-01-12 01:18:31', '2021-01-12 01:18:31'),
(23, 'Служба охраны труда', 0, 8, '2021-01-12 01:18:45', '2021-01-12 01:18:45'),
(24, 'Руководитель организации', 0, 8, '2021-01-12 01:19:00', '2021-01-12 01:19:00'),
(25, 'Работники пожарного надзора по закрепленным за ними объектам', 0, 8, '2021-01-12 01:19:18', '2021-01-12 01:19:18'),
(26, 'Руководители структурных подразделений организации, отделов', 1, 8, '2021-01-12 01:19:31', '2021-01-12 03:04:31'),
(27, '1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейінгі мерзімге\r\nқоғамдық қызметке қатысу, немесе бір жылға дейінгі мерзімге бас бостандығын шектеу немесе дәл сол мерзімге\r\nбас бостандығынан айыру', 1, 23, '2021-01-21 02:12:46', '2021-01-21 02:12:46'),
(28, '1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейін\r\nқоғамдық қызметпен айналысу, немесе үш жылға дейінгі мерзімге бас бостандығын шектеу немесе\r\nсол мерзімге бас бостандығынан айыру', 0, 23, '2021-01-21 02:13:38', '2021-01-21 02:13:38'),
(29, '1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейін\r\nқоғамдық қызметпен айналысу, немесе екі жылға дейінгі бас бостандығын шектеу немесе дәл сол\r\nмерзімге бас бостандығынан айыру', 0, 23, '2021-01-21 02:21:39', '2021-01-21 02:21:39'),
(30, 'барлық жауап дұрыс', 0, 23, '2021-01-21 02:22:07', '2021-01-21 02:22:07'),
(31, 'ҚР ҚК 273-бабы', 0, 22, '2021-01-21 02:22:27', '2021-01-21 02:22:27'),
(32, 'ҚР ҚК 274-бабы', 1, 22, '2021-01-21 02:23:05', '2021-01-21 02:23:05'),
(33, 'ҚР ҚК 275-бабы', 0, 22, '2021-01-21 02:23:18', '2021-01-21 02:23:18'),
(34, 'барлық жауап дұрыс', 0, 22, '2021-01-21 02:23:33', '2021-01-21 02:23:33'),
(35, '«ҚР Қарулы Күштерінің әскери бөлімдер»;', 0, 21, '2021-01-21 02:26:41', '2021-01-21 02:26:41'),
(36, '«Өмірді қамтамасыз ету объектілері»;', 0, 21, '2021-01-21 02:26:59', '2021-01-21 02:26:59'),
(37, '«ҚР Президенті бекіткен тізімге енгізілген ҚР Мемлекеттік күзет қызметі ІІБ бөлімдерімен бірге\r\nқорғайтын объектілер, сондай-ақ мемлекеттік маңызы бар объектілер»;', 0, 21, '2021-01-21 02:27:28', '2021-01-21 02:27:28'),
(38, 'барлық жауап дұрыс', 1, 21, '2021-01-21 02:27:41', '2021-01-21 02:27:41'),
(39, '«Аса маңызды мемлекеттік нысандар»;', 0, 20, '2021-01-21 02:28:53', '2021-01-21 02:28:53'),
(40, '«Стратегиялық нысандар»;', 0, 20, '2021-01-21 02:29:15', '2021-01-21 02:29:15'),
(41, '«Қауіпті өндірістік нысандар»;', 0, 20, '2021-01-21 02:29:29', '2021-01-21 02:29:29'),
(42, 'барлық жауап дұрыс', 1, 20, '2021-01-21 02:29:42', '2021-01-21 02:29:42'),
(43, '«ҚР террористік тұрғыдан осал ұйымдарының тізімін бекіту туралы»;', 0, 19, '2021-01-21 02:30:04', '2021-01-21 02:30:04'),
(44, '«ҚР терроризмге қарсы осал нысандардың тізімін бекіту туралы»;', 0, 19, '2021-01-21 02:30:17', '2021-01-21 02:30:17'),
(45, '«ҚР террористік тұрғыдан осал нысандардың тізімін бекіту туралы»;', 1, 19, '2021-01-21 02:31:08', '2021-01-21 02:31:08'),
(46, 'барлық жауап дұрыс', 0, 19, '2021-01-21 02:31:30', '2021-01-21 02:31:30'),
(47, 'ҚР Парламентімен;', 0, 18, '2021-01-21 02:32:00', '2021-01-21 02:32:00'),
(48, 'ҚР Президентімен;', 1, 18, '2021-01-21 02:32:24', '2021-01-21 02:32:24'),
(49, 'облыстық маслихатпен.', 0, 18, '2021-01-21 02:32:38', '2021-01-21 02:32:38'),
(50, 'барлық жауап дұрыс', 0, 18, '2021-01-21 02:32:50', '2021-01-21 02:32:50'),
(51, 'Сөйлесуді жазу', 0, 17, '2021-01-21 02:33:39', '2021-01-21 02:33:39'),
(52, 'Нөмірді анықтау үшін автоматты телефон станциясына қоңырау шалу', 0, 17, '2021-01-21 02:33:58', '2021-01-21 02:33:58'),
(53, 'Сөйлесу уақыты мен ұзақтығын жазу', 0, 17, '2021-01-21 02:34:43', '2021-01-21 02:34:43'),
(54, 'барлық жауап дұрыс', 1, 17, '2021-01-21 02:35:06', '2021-01-21 02:35:06'),
(55, 'барлық жауап дұрыс', 0, 16, '2021-01-21 02:41:42', '2021-01-21 02:41:42'),
(56, 'Терроризм актісінің күтілетін теріс салдары, қоғамдық қауіптіліктің ауқымы мен дәрежесіне байланысты,\r\nтерроризмге қарсы операцияны басқаруды республикалық немесе облыстық, республикалық маңызы бар қаланың,\r\nастананың, ауданның және әскери-жедел штабтың басшысы жүзеге асырады', 1, 16, '2021-01-21 02:42:05', '2021-01-21 02:42:05'),
(57, 'Терроризм актісінің күтілетін теріс салдарлары, қоғамдық қауіптіліктің дәрежесі мен дәрежесіне\r\nбайланысты республикалық немесе облыстық, республикалық маңызы бар қала, астана, аудан және әскери-теңіз\r\nштабы бастығының орынбасары басқарады', 0, 16, '2021-01-21 02:42:24', '2021-01-21 02:42:24'),
(58, 'Терроризм актісінің күтілетін теріс салдары, қоғамдық қауіптіліктің ауқымы мен дәрежесіне байланысты,\r\nтерроризмге қарсы операцияны республикалық немесе аймақтық жедел штабтың басшысы басқарады;', 0, 16, '2021-01-21 02:42:49', '2021-01-21 02:42:49'),
(59, 'Терроризмге қарсы іс-қимыл мақсатында уақытша жұмыс істейтін республикалық және облыстық,\r\nреспубликалық маңызы бар қалалар, астана, аудан және теңіз жедел штабы құрылады', 0, 15, '2021-01-21 03:28:10', '2021-01-21 03:28:10'),
(60, 'терроризмге қарсы іс-қимыл мақсатында тұрақты республикалық және облыстық, республикалық маңызы\r\nбар қала, астана, аудандық жедел штабтар құрылады', 0, 15, '2021-01-21 03:28:24', '2021-01-21 03:28:24'),
(61, 'Терроризмге қарсы іс-қимыл мақсатында тұрақты республикалық және облыстық, республикалық маңызы бар\r\nқала, астана, аудан және әскери-теңіз штабтары құрылады', 1, 15, '2021-01-21 03:28:43', '2021-01-21 03:28:43'),
(62, 'барлық жауап дұрыс', 0, 15, '2021-01-21 03:28:59', '2021-01-21 03:28:59'),
(63, 'үй-жайларды тексеру техникасына, жарылғыш құрылғыларды орналастыруға болатын орындарды\r\nанықтауға арналған алдын-алу және тәрбиелік шараларды жүргізу;', 0, 14, '2021-01-21 04:05:21', '2021-01-21 04:05:21'),
(64, 'терроризм актісі нәтижесінде туындаған антропогендік сипаттағы қатерлерді жою бойынша мүдделі\r\nмемлекеттік органдармен және ұйымдармен бірлескен іс-шараларды жоспарлау және әзірлеу;', 0, 14, '2021-01-21 04:05:46', '2021-01-21 04:05:46'),
(65, 'стандартты төлқұжат негізінде оларға сеніп тапсырылған нысандардың терроризмге қарсы қорғау\r\nпаспортын жасау;', 0, 14, '2021-01-21 04:18:28', '2021-01-21 04:18:28'),
(66, 'барлық жауап дұрыс', 1, 14, '2021-01-21 04:18:50', '2021-01-21 04:18:50'),
(67, 'терроризм актісінің нақты мүмкіндігінің расталуын талап ететін ақпарат болған кезде;', 0, 13, '2021-01-21 04:48:15', '2021-01-21 04:48:15'),
(68, 'терроризм актісін жасаудың нақты мүмкіндігі туралы расталған ақпарат болған кезде;', 0, 13, '2021-01-21 04:48:47', '2021-01-21 04:48:47'),
(69, 'жасалған терроризм актісі туралы мәліметтер болса, сондай-ақ терроризмнің екінші актісінің жасалу\r\nықтималдығы туралы немесе терроризмдік тұрғыдан осал нысандарға бір уақытта террористік шабуыл жасау\r\nтуралыа расталған мәліметтер болған кезде.', 1, 13, '2021-01-21 04:49:13', '2021-01-21 04:49:13'),
(70, 'барлық жауап дұрыс', 0, 13, '2021-01-21 04:49:35', '2021-01-21 04:49:35'),
(71, 'жекебасына немесе лауазымды тұлғаға 100 АЕК, шағын кәсіп және коммерциялық емес ұйым иелеріне 200,\r\nорта шағын кәсіп иелеріне – 300, ірі шағын кәсіп иелеріне – 500 АЕК көлемінде айыппұл салынады', 1, 12, '2021-01-21 04:50:04', '2021-01-21 04:50:04'),
(72, '5000 АЕК дейін және қоғамдық түзеу жұмыстарына жіберу, немесе 5 жылға дейін бас бостандығынан айыру', 0, 12, '2021-01-21 04:50:34', '2021-01-21 04:50:34'),
(73, '120 АЕК көлемінде айыппұл салу, немесе 120 сағатқа дейін қоғамдық түзету жұмыстарын жасату, не 30\r\nкүнге дейін қамауға алу', 0, 12, '2021-01-21 04:50:54', '2021-01-21 04:50:54'),
(74, 'барлық жауап дұрыс', 0, 12, '2021-01-21 04:51:12', '2021-01-21 04:51:12'),
(75, 'лаңкестермен кепілдегі адамдарды босату туралы келісімшарт жасау', 0, 11, '2021-01-21 04:51:39', '2021-01-21 04:51:39'),
(76, 'қарсы әркет жасап, лаңкесті заласыздандыру', 0, 11, '2021-01-21 04:51:53', '2021-01-21 04:51:53'),
(77, 'барлық талаптарды орындау', 1, 11, '2021-01-21 04:52:08', '2021-01-21 04:52:08'),
(78, 'барлық жауап дұрыс', 0, 11, '2021-01-21 04:52:50', '2021-01-21 04:52:50'),
(79, 'ұстауға, үстіне су құюға', 1, 10, '2021-01-21 04:53:11', '2021-01-21 04:53:11'),
(80, 'елеусіз қалдырмау, өзге адамдарды көмекке шақыру', 0, 10, '2021-01-21 04:53:24', '2021-01-21 04:53:24'),
(81, 'ұялы телефонды қолдану, дереу құқық қорғау органдарына хабарлама беру', 0, 10, '2021-01-21 04:53:36', '2021-01-21 04:53:36'),
(82, 'барлық жауап дұрыс', 0, 10, '2021-01-21 04:53:48', '2021-01-21 04:53:48'),
(83, 'Күш көрсету арқылы мемелекеттік ұжымдарды шешім қабылдауға мәжбүрлеу, немесе халықаралық\r\nмекемелерді бопсалау арқылы шешім қабылдауға және өзге де қылмыстық жолмен қоғамда үрей тудыру арқылы\r\nөз мақсатын жүзеге асыруды талап ету, сондай - ақ жеке тұлға, қоғам мүшелері, мемлекетке нұқсан келтіру\r\nидеологиясын ұстану арқылы бопсалау, мәжбүрлеу, талап қою.', 0, 9, '2021-01-21 04:54:08', '2021-01-21 04:54:08'),
(84, 'Лаңкестік жасау немесе жасалу қаупін тудыру, өрт қою және адамдардың өміріне қауіп төндіру, зиян келтіру\r\nсондай - ақ дүние - мүлкіне нұқсан келтіру, өзге де қоғамға зияны тиетін іс- әрекеттер жасау', 0, 9, '2021-01-21 04:54:19', '2021-01-21 04:54:19'),
(85, 'Қоғамдық жүйенің теориясы мен көзқарас ұстанымдарына сай лаңкестік әдіс амалдарды қолдану арқылы\r\nсаяси, діни, идеологиялық жүйеге өзгерістер енгізу және өзге де мақсаттарды жүзеге асыру', 1, 9, '2021-01-21 04:54:32', '2021-01-21 04:54:32'),
(86, 'Барлық жауап дұрыс', 0, 9, '2021-01-21 04:54:42', '2021-01-21 04:54:42'),
(87, 'идеология насилия и практика воздействия на принятие решения государственными органами, органами\nместного самоуправления или международными организациями путем совершения либо угрозы совершения\nнасильственных и иных преступных действий;', 0, 24, NULL, NULL),
(88, 'совершение или угроза совершения взрыва, поджога или иных действий, создающих опасность гибели людей,\nпричинения значительного имущественного ущерба либо наступления иных общественно опасных последствий,\nесли эти действия совершены в целях нарушения общественной безопасности;', 0, 24, NULL, NULL),
(89, 'идеология насилия и практика воздействия на принятие решения государственными органами, органами\nместного самоуправления или международными организациями путем совершения либо угрозы совершения\nнасильственных и (или) иных преступных действий, связанных с устрашением населения и направленных на\nпричинение ущерба личности, обществу и государству;', 0, 24, NULL, NULL),
(90, 'Все варианты', 0, 24, NULL, NULL),
(91, 'прикасаться, вскрывать, заливать водой', 0, 25, NULL, NULL),
(92, 'не оставлять без присмотра, звать людей на помощь;', 0, 25, NULL, NULL),
(93, 'пользоваться телефоном, сообщать в правоохранительные органы.', 0, 25, NULL, NULL),
(94, 'Все варианты', 0, 25, NULL, NULL),
(95, 'договориться с террористами об освобождении заложников;', 0, 26, NULL, NULL),
(96, 'напасть и обезоружить террористов;', 0, 26, NULL, NULL),
(97, 'выполнять все требования беспрекословно.', 0, 26, NULL, NULL),
(98, 'Все варианты', 0, 26, NULL, NULL),
(99, 'штрафа на физических или должностных лиц в размере ста, на субъектов малого предпринимательства или\nнекоммерческие организации - в размере двухсот, на субъектов среднего предпринимательства - в размере\nтрехсот, на субъектов крупного предпринимательства – в размере пятисот месячных расчетных показателей.', 0, 27, NULL, NULL),
(100, 'штрафа в размере до пяти тысяч месячных расчетных показателей либо исправительными работами в том\nже размере, либо ограничением свободы на срок до пяти лет, либо лишением свободы на тот же срок.', 0, 27, NULL, NULL),
(101, 'штрафа в размере до ста двадцати месячных расчетных показателей либо исправительными работами в том\nже размере, либо привлечением к общественным работам на срок до ста двадцати часов, либо арестом на срок\nдо тридцати суток.', 0, 27, NULL, NULL),
(102, 'Все варианты', 0, 27, NULL, NULL),
(103, 'при наличии требующей подтверждения информации о реальной возможности совершения акта (актов)\nтерроризма;', 0, 28, NULL, NULL),
(104, 'при наличии подтвержденной информации о реальной возможности совершения акта (актов) терроризма;', 0, 28, NULL, NULL),
(105, 'при наличии информации о совершенном акте терроризма, а также подтвержденной информации о\nвозможном совершении повторного акта (актов) терроризма или одновременных террористических атак на\nобъекты, уязвимые в террористическом отношении.', 0, 28, NULL, NULL),
(106, 'Все варианты', 0, 28, NULL, NULL),
(107, 'проведению профилактических и учебных мероприятий по обучению персонала технике осмотра помещений,\nвыявлению возможных мест закладки взрывных устройств;', 0, 29, NULL, NULL),
(108, 'планированию и отработке совместных действий с заинтересованными государственными органами и\nорганизациями по ликвидации угроз техногенного характера, возникших в результате совершенного акта\nтерроризма;', 0, 29, NULL, NULL),
(109, 'разработке на основе типового паспорта – паспорта антитеррористической защищенности вверенных им\nобъектов.', 0, 29, NULL, NULL),
(110, 'Все варианты', 0, 29, NULL, NULL),
(111, 'В целях противодействия терроризму создаются временно действующие республиканский и областной, города\nреспубликанского значения, столицы, района и морской оперативные штабы;', 0, 30, NULL, NULL),
(112, 'В целях противодействия терроризму создаются постоянно действующие республиканский и областной,\nгорода республиканского значения, столицы, района оперативные штабы;', 0, 30, NULL, NULL),
(113, 'В целях противодействия терроризму создаются постоянно действующие республиканский и областной,\nгорода республиканского значения, столицы, района и морской оперативные штабы.', 0, 30, NULL, NULL),
(114, 'Все варианты', 0, 30, NULL, NULL),
(115, 'В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта\nтерроризма руководство антитеррористической операцией осуществляет руководитель республиканского или\nобластного оперативного штаба;', 0, 31, NULL, NULL),
(116, 'В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта\nтерроризма руководство антитеррористической операцией осуществляет заместитель руководителя\nреспубликанского или областного, города республиканского значения, столицы, района и морского оперативного\nштаба;', 0, 31, NULL, NULL),
(117, 'В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта\nтерроризма руководство антитеррористической операцией осуществляет руководитель республиканского или\nобластного, города республиканского значения, столицы, района и морского оперативного штаба.', 0, 31, NULL, NULL),
(118, 'Все варианты', 0, 31, NULL, NULL),
(119, 'Записать Разговор;', 0, 32, NULL, NULL),
(120, 'Звонок на атс для определения номера;', 0, 32, NULL, NULL),
(121, 'Зафиксировать время разговора и продолжительность.', 0, 32, NULL, NULL),
(122, 'Все варианты', 0, 32, NULL, NULL),
(123, 'Парламентом РК;', 0, 33, NULL, NULL),
(124, 'Президентом РК;', 0, 33, NULL, NULL),
(125, 'Областным маслихатом.', 0, 33, NULL, NULL),
(126, 'Все варианты', 0, 33, NULL, NULL),
(127, '«Об утверждении перечня организаций РК, уязвимых в террористическом отношении»;', 0, 34, NULL, NULL),
(128, '«Об утверждении перечня объектов РК, уязвимых в антитеррористическом отношении»;', 0, 34, NULL, NULL),
(129, '«Об утверждении перечня объектов РК, уязвимых в террористическом отношении»;', 0, 34, NULL, NULL),
(130, 'Все варианты', 0, 34, NULL, NULL),
(131, '«Особо важные государственные объекты»;', 0, 35, NULL, NULL),
(132, '«Стратегические объекты»;', 0, 35, NULL, NULL),
(133, '«Опасные производственные объекты»;', 0, 35, NULL, NULL),
(134, 'Все варианты', 0, 35, NULL, NULL),
(135, '«Воинские части ВС РК, других войск и воинских формирований»;', 0, 36, NULL, NULL),
(136, '«Объекты жизнеобеспечения»;', 0, 36, NULL, NULL),
(137, '«Объекты, охраняемые СГО РК совместно с подразделениями ОВД, включенные в перечень, утверждаемый\nПрезидентом РК, а также объекты, имеющие важное государственное значение»;', 0, 36, NULL, NULL),
(138, 'Все варианты', 0, 36, NULL, NULL),
(139, '«Статья 273 УК РК»;', 0, 37, NULL, NULL),
(140, '«Статья 274 УК РК»;', 0, 37, NULL, NULL),
(141, '«Статья 275 УК РК»;', 0, 37, NULL, NULL),
(142, 'Все варианты', 0, 37, NULL, NULL),
(143, '«одной тысячи месячных расчетных показателей либо исправительными работами в том же размере,\nлибо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок\nдо одного года, либо лишением свободы на тот же срок»;', 0, 38, NULL, NULL),
(144, '«одной тысячи месячных расчетных показателей либо исправительными работами в том же размере,\nлибо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок\nдо трех лет, либо лишением свободы на тот же срок»;', 0, 38, NULL, NULL),
(145, '«одной тысячи месячных расчетных показателей либо исправительными работами в том же размере,\nлибо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок\nдо двух лет, либо лишением свободы на тот же срок»;', 0, 38, NULL, NULL),
(146, 'Все варианты', 0, 38, NULL, NULL),
(147, 'система законодательных актов, направленных на сохранение здоровья и работоспособности человека в процессе\nтруда', 0, 39, NULL, NULL),
(148, 'система социально-экономичных, организационных, технических, гигиенических и лечебно-профи\nпрофилактических мероприятий и средств', 0, 39, NULL, NULL),
(149, 'система законодательных актов, социально-экономичных, организационных, технических, гигиенических и\nлечебно-профи профилактических мероприятий и средств, направленных на сохранение здоровья и\nработоспособности человека в процессе труда', 0, 39, NULL, NULL),
(150, 'система организационных мероприятий и технических способов, предотвращающих или уменьшающих\nвоздействие на работающих вредных производственных факторов', 0, 39, NULL, NULL),
(151, 'Совокупность ранений, которые повторяются в тех или иных контингентов населения', 0, 40, NULL, NULL),
(152, 'Случай воздействия на работающего вредного фактора', 0, 40, NULL, NULL),
(153, 'Всякое нарушение анатомической целостности организма или нарушение его функций вследствие внезапной\nдействия на него любого опасного производственного фактора', 0, 40, NULL, NULL),
(154, 'Несчастный случай на производстве', 0, 40, NULL, NULL),
(155, 'Пестициды', 0, 41, NULL, NULL),
(156, 'Повышенная или пониженная влажность воздуха, изделия, заготовки, материалы', 0, 41, NULL, NULL),
(157, 'Физические перегрузки', 0, 41, NULL, NULL),
(158, 'Микроорганизмы', 0, 41, NULL, NULL),
(159, 'Повышенное или пониженное движение воздуха на рабочем месте', 0, 42, NULL, NULL),
(160, 'Нервно-психические перегрузки, физические перегрузки', 0, 42, NULL, NULL),
(161, 'Дезинфекционные средства', 0, 42, NULL, NULL),
(162, 'Повышенный уровень вибрации', 0, 42, NULL, NULL),
(163, 'Это количество несчастных случаев со смертельным исходом', 0, 43, NULL, NULL),
(164, 'Это количество несчастных случаев со смертельным исходом, что приходится на 1 работающего', 0, 43, NULL, NULL),
(165, 'Это количество дней нетрудоспособности, приходящееся на 1 работающего', 0, 43, NULL, NULL),
(166, 'Это количество дней нетрудоспособности, приходящееся на 1 несчастный случай', 0, 43, NULL, NULL),
(167, 'Представитель Госнадзорохрантруда труда', 0, 44, NULL, NULL),
(168, 'Инженер по охране труда', 0, 44, NULL, NULL),
(169, 'Кабинет Министров Украины', 0, 44, NULL, NULL),
(170, 'Представитель местных госадминистраций', 0, 44, NULL, NULL),
(171, 'Подготовку, принятие и реализацию мероприятий по обеспечению охраны труда', 0, 45, NULL, NULL),
(172, 'Обеспечение безопасности', 0, 45, NULL, NULL),
(173, 'Реализацию политики Украины в области охраны труда', 0, 45, NULL, NULL),
(174, 'Контроль за состоянием охраны труда', 0, 45, NULL, NULL),
(175, 'Для решения задач управления охраны труда', 0, 46, NULL, NULL),
(176, 'Для обеспечения работающих средствами индивидуальной и коллективной защиты', 0, 46, NULL, NULL),
(177, 'Для обеспечения предприятия и работающих нормативными актами по вопросам охраны труда', 0, 46, NULL, NULL),
(178, 'все ответы', 0, 46, NULL, NULL),
(179, '20 человек и более', 0, 47, NULL, NULL),
(180, '40 человек и более', 0, 47, NULL, NULL),
(181, '50 человек и более', 0, 47, NULL, NULL),
(182, '100 человек и более', 0, 47, NULL, NULL),
(183, 'Специалистами, имеющими высшее образование и стаж работы по профилю производства не менее 3-х лет', 0, 48, NULL, NULL),
(184, 'Специалистами, которые имеют высшее образование и стаж работы по профилю производства не менее 1-го года', 0, 48, NULL, NULL),
(185, 'Специалистами, которые имеют высшее образование и стаж работы по профилю производства не менее 5-ти лет', 0, 48, NULL, NULL),
(186, 'Специалистами, которые имеют средне-технич в образование и стаж работы по профилю производства не менее 5-\nти лет', 0, 48, NULL, NULL),
(187, 'Особый режим рабочего времени, установленный законодательством для определенной категории работников,\nпродолжительность труда которых не поддается четкому учету и не может быть ограничена рамками нормального\nрабочего времени', 0, 49, NULL, NULL),
(188, 'Нахождение работника на предприятии после окончания рабочего дня для выполнения задач, которые не входят в\nежедневных обязанностей работника – Отдых, для определенной категории работников, продолжительность труда\nкоторых не может быть ограничена рамками нормального рабочего времени', 0, 49, NULL, NULL),
(189, 'Это время, установленное законом, в которой рабочие и служащие обязаны находиться на территории предприятия,\nвыполнять порученную им работу и действовать в соответствии с Правилами внутреннего распорядка Безопасность\nтруда на предприятии вообще обеспечивает и несет за это ответственность – Инженер по охране труда предприятия', 0, 49, NULL, NULL),
(190, 'Председатель профсоюзного комитета', 0, 50, NULL, NULL),
(191, 'Руководитель предприятия', 0, 50, NULL, NULL),
(192, 'Госнадзорохрантруда труда', 0, 50, NULL, NULL),
(193, 'Руководитель предприятия', 0, 51, NULL, NULL),
(194, 'Юрисконсульт', 0, 51, NULL, NULL),
(195, 'Руководитель отрасли', 0, 51, NULL, NULL),
(196, 'Инженер по охране труда', 0, 51, NULL, NULL),
(197, 'Инженер по охране труда', 0, 52, NULL, NULL),
(198, 'Руководитель предприятия', 0, 52, NULL, NULL),
(199, 'Председатель профкома', 0, 52, NULL, NULL),
(200, 'Непосредственный руководитель работ', 0, 52, NULL, NULL),
(201, 'Инженер по охране труда', 0, 53, NULL, NULL),
(202, 'Представитель профкома', 0, 53, NULL, NULL),
(203, 'Руководитель области, где произошел несчастный случай', 0, 53, NULL, NULL),
(204, 'все ответы', 0, 53, NULL, NULL),
(233, 'еңбек процесінде адамның денсаулығы мен еңбек қабілеттілігін сақтауға бағытталған заңнамалық актілер\nжүйесі', 0, 54, NULL, NULL),
(234, 'әлеуметтік-экономикалық, ұйымдастырушылық, техникалық, гигиеналық және сауықтыру-профилактикалық іс-\nшаралар мен құралдар жүйесі', 0, 54, NULL, NULL),
(235, 'еңбек процесінде адамның денсаулығы мен еңбек қабілетін сақтауға бағытталған заңнамалық актілер,\nәлеуметтік-экономикалық, ұйымдастырушылық, техникалық, гигиеналық және сауықтыру -профилактикалық іс-\nшаралар мен құралдар жүйесі', 0, 54, NULL, NULL),
(236, 'зиянды өндірістік факторлардың жұмысшыларына әсерін болдырмайтын немесе төмендететін\nұйымдастырушылық шаралар мен техникалық әдістер жүйесі', 0, 54, NULL, NULL),
(237, 'Халықтың сол немесе басқа контингентінде қайталанатын жаралар жиынтығы', 0, 55, NULL, NULL),
(238, 'Жұмысшыға зиянды фактордың әсер ету жағдайы', 0, 55, NULL, NULL),
(239, 'Дененің анатомиялық тұтастығының кез-келген бұзылуы немесе оған қауіпті өндірістік фактордың кенеттен\nәсер етуі салдарынан оның функциялары бұзылуы', 0, 55, NULL, NULL),
(240, 'Өндірістегі қайғылы оқиға', 0, 55, NULL, NULL),
(241, 'Пестицидтер', 0, 56, NULL, NULL),
(242, 'Жоғары немесе төмен ылғалдылық, өнімдер, бланкілер, материалдар', 0, 56, NULL, NULL),
(243, 'Физикалық шамадан тыс жүктеме', 0, 56, NULL, NULL),
(244, 'Микроорганизмдер', 0, 56, NULL, NULL),
(245, 'Жұмыс орнындағы ауа қозғалысының жоғарылауы немесе азаюы', 0, 57, NULL, NULL),
(246, 'Нейропсихикалық жүктеме, физикалық шамадан тыс жүктеме', 0, 57, NULL, NULL),
(247, 'Дезинфекциялық құралдар\\', 0, 57, NULL, NULL),
(248, 'Дірілдің жоғарғы деңгейі', 0, 57, NULL, NULL),
(249, 'Бұл өлімге әкеліп соғатын қайғылы оқиғалардың саны.', 0, 58, NULL, NULL),
(250, 'Бұл бір жұмысшыға келетін өлімге әкеліп соғатын қайғылы оқиғалардың сан', 0, 58, NULL, NULL),
(251, 'Бұл бір жұмысшыға келетін жұмысқа жарамсыз күндер саны', 0, 58, NULL, NULL),
(252, 'Бұл бір қайғылы оқиғаға келетін жұмысқа жарамсыз күндер саны', 0, 58, NULL, NULL),
(253, 'Мемлекеттік еңбек инспекциясының өкілі', 0, 59, NULL, NULL),
(254, 'Еңбекті қорғау бойынша инженер', 0, 59, NULL, NULL),
(255, 'Министрлер Кабинеті', 0, 59, NULL, NULL),
(256, 'Жергілікті мемлекеттік әкімшіліктердің өкілі', 0, 59, NULL, NULL),
(257, 'Еңбекті қорғауды қамтамасыз ету бойынша шараларды дайындау, қабылдау және іске асыру', 0, 60, NULL, NULL),
(258, 'Қауіпсіздікті камтамасыз ету', 0, 60, NULL, NULL),
(259, 'Еңбек қорғау саясатын жүзеге асыру', 0, 60, NULL, NULL),
(260, 'Еңбек қауіпсіздігі мониторингі', 0, 60, NULL, NULL),
(261, 'Еңбекті қорғауды басқару мәселелерін шешу үшін', 0, 61, NULL, NULL),
(262, 'Жұмысшыларды жеке және ұжымдық қорғаныс құралдарымен қамтамасыз ету үшін', 0, 61, NULL, NULL),
(263, 'Кәсіпорындар мен жұмысшыларды еңбекті қорғау бойынша нормативтік актілермен қамтамасыз ету', 0, 61, NULL, NULL),
(264, 'барлық жауап дұрыс', 0, 61, NULL, NULL),
(265, '20 және одан көп адам', 0, 62, NULL, NULL),
(266, '40 және одан көп адам', 0, 62, NULL, NULL),
(267, '50 және одан көп адам', 0, 62, NULL, NULL),
(268, '100 және одан көп адам', 0, 62, NULL, NULL),
(269, 'Жоғары білімі бар және өндіріс профилінде кемінде 3 жыл жұмыс тәжірибесі бар мамандар', 0, 63, NULL, NULL),
(270, 'Жоғары білімі бар және өндіріс профилінде кемінде 1 жыл жұмыс тәжірибесі бар мамандар', 0, 63, NULL, NULL),
(271, 'Жоғары білімі бар және өндіріс профилінде кемінде 3 жыл жұмыс тәжірибесі бар мамандар', 0, 63, NULL, NULL),
(272, 'Орта техникалық білімі бар және өндіріс профилінде кемінде 5 жыл жұмыс тәжірибесі бар мамандар', 0, 63, NULL, NULL),
(273, 'Жұмыс уақытының нақты есептелмейтін және қалыпты жұмыс уақытымен шектелмейтін жұмысшылардың\nбелгілі бір санаты үшін заңмен белгіленген жұмыс уақытының арнайы режимі', 0, 64, NULL, NULL),
(274, 'Қызметкердің күнделікті міндеттеріне кірмейтін міндеттерді орындау үшін жұмыс күні аяқталғаннан кейін\nкәсіпорында жұмыскердің болуы - демалысы, жұмыс уақыты қалыпты жұмыс уақытымен шектелмейтін\nжұмысшылардың белгілі бір санаты үшін.', 0, 64, NULL, NULL),
(275, 'Бұл заңмен белгіленген уақыт, бұл уақытта жұмысшылар мен қызметкерлердің кәсіпорынның аумағында болуы,\nөзіне жүктелген жұмыстарды орындауға және ішкі ережелерге сәйкес әрекет етуге міндетті.Кәсіпорындағы еңбек\nқауіпсіздігі жалпы жауапкершілікті қамтамасыз етеді және жауапкершілік алады - кәсіпорынның инженері', 0, 64, NULL, NULL),
(276, 'барлық жауап дұрыс', 0, 64, NULL, NULL),
(277, 'Кәсіподақ комитетінің төрағасы', 0, 65, NULL, NULL),
(278, 'Кәсіпорын басшысы', 0, 65, NULL, NULL),
(279, 'Еңбекті мемлекеттік қадағалау', 0, 65, NULL, NULL),
(280, 'барлық жауап дұрыс', 0, 65, NULL, NULL),
(281, 'Кәсіпорын басшысы', 0, 66, NULL, NULL),
(282, 'Заңгер кеңесшісі', 0, 66, NULL, NULL),
(283, 'Сала жетекшісі', 0, 66, NULL, NULL),
(284, 'Еңбекті қорғау бойынша инженер', 0, 66, NULL, NULL),
(285, 'Еңбекті қорғау бойынша инженер', 0, 67, NULL, NULL),
(286, 'Кәсіпорын басшысы', 0, 67, NULL, NULL),
(287, 'Кәсіподақ комитетінің төрағасы', 0, 67, NULL, NULL),
(288, 'Жұмыстардың тікелей басшысы', 0, 67, NULL, NULL),
(289, 'Еңбекті қорғау бойынша инженер', 0, 68, NULL, NULL),
(290, 'Кәсіподақ комитетінің төрағасы', 0, 68, NULL, NULL),
(291, 'Апат болған аумақтың басшысы', 0, 68, NULL, NULL),
(292, 'барлық жауап дұрыс', 0, 68, NULL, NULL),
(293, '18 сентября 2008 года;', 0, 69, NULL, NULL),
(294, '18 сентября 2007 года;', 0, 69, NULL, NULL),
(295, '18 сентября 2006 года;', 0, 69, NULL, NULL),
(296, '18 сентября 2009 года.', 0, 69, NULL, NULL),
(297, 'комплекс срочных базовых мероприятий для предупреждения осложнений при экстренных состояниях,\nпроводимых на месте происшествия самим пострадавшим (самопомощь) или другим лицом, находящимся\nпоблизости (взаимопомощь)', 0, 70, NULL, NULL),
(298, 'комплекс срочных базовых мероприятий для спасения жизни человека и предупреждения осложнений при\nэкстренных состояниях, проводимых на месте происшествия самим пострадавшим (самопомощь) или другим\nлицом, находящимся поблизости (взаимопомощь);', 0, 70, NULL, NULL),
(299, 'комплекс срочных базовых мероприятий для спасения жизни человека, проводимых на месте происшествия\nсамим пострадавшим (самопомощь) или другим лицом, находящимся поблизости (взаимопомощь).', 0, 70, NULL, NULL),
(300, 'Все варианты', 0, 70, NULL, NULL),
(301, 'должен лежать на спине, на твердой поверхности;', 0, 71, NULL, NULL),
(302, 'должен лежать на боку, на твердой поверхности;', 0, 71, NULL, NULL),
(303, 'должен лежать на животе, на твердой поверхности.', 0, 71, NULL, NULL),
(304, 'Все варианты', 0, 71, NULL, NULL),
(305, 'очистить ротовую полость, запрокинуть голову пострадавшего, сделать три искусственных вдоха в рот или\nнос;', 0, 72, NULL, NULL),
(306, 'очистить ротовую полость, запрокинуть голову пострадавшего, сделать один искусственный вдох в рот или\nнос;', 0, 72, NULL, NULL),
(307, 'очистить ротовую полость, запрокинуть голову пострадавшего, сделать два искусственных вдоха в рот или\nнос;', 0, 72, NULL, NULL),
(308, 'Все варианты', 0, 72, NULL, NULL),
(309, 'когда без сознания, нет дыхания, есть пульс на сонной артерии;', 0, 73, NULL, NULL),
(310, 'когда без сознания, нет дыхания, нет пульса на сонной артерии;', 0, 73, NULL, NULL),
(311, 'когда без сознания, есть дыхание, нет пульса на сонной артерии;', 0, 73, NULL, NULL),
(312, 'Все варианты', 0, 73, NULL, NULL),
(313, '40;', 0, 74, NULL, NULL),
(314, '35;', 0, 74, NULL, NULL),
(315, '30;', 0, 74, NULL, NULL),
(316, 'Все варианты', 0, 74, NULL, NULL),
(317, 'прижать плечевую артерию к кости со стороны плеча;', 0, 75, NULL, NULL),
(318, 'затянуть жгутом;', 0, 75, NULL, NULL),
(319, 'обработать йодом;', 0, 75, NULL, NULL),
(320, 'Все варианты', 0, 75, NULL, NULL),
(321, 'рану закрывают несколькими слоями бинта, туго фиксируют все с помощью бинта;', 0, 76, NULL, NULL),
(322, 'сверху кладут стерильную вату, туго фиксируют все с помощью бинта;', 0, 76, NULL, NULL),
(323, 'рану закрывают несколькими слоями бинта, сверху кладут стерильную вату, туго фиксируют все с помощью\nбинта;', 0, 76, NULL, NULL),
(324, 'Все варианты', 0, 76, NULL, NULL),
(325, 'приложить холод через ткань в течении 10-15 минут;', 0, 77, NULL, NULL),
(326, 'приложить холод через ткань в течении 5-10 минут;', 0, 77, NULL, NULL),
(327, 'приложить холод через ткань в течении 15-20 минут;', 0, 77, NULL, NULL),
(328, 'Все варианты', 0, 77, NULL, NULL),
(329, 'при кровотечении промыть рану водой;', 0, 78, NULL, NULL),
(330, 'при кровотечении промыть рану антисептиком;', 0, 78, NULL, NULL),
(331, 'при кровотечении промыть рану йодом;', 0, 78, NULL, NULL),
(332, 'Все варианты', 0, 78, NULL, NULL),
(333, 'транспортировка проводится в восстановительном положении;', 0, 79, NULL, NULL),
(334, 'на спине с валиком под коленями и слегка разведенными ногами;', 0, 79, NULL, NULL),
(335, 'на твердых носилках на спине с валиками под шеей;', 0, 79, NULL, NULL),
(336, 'Все варианты', 0, 79, NULL, NULL),
(337, 'на твердых носилках на спине с валиками под шеей, поясницей и под коленями или на мягких носилках – на\nживоте;', 0, 80, NULL, NULL),
(338, 'на спине с валиком под коленями и слегка разведенными ногами;', 0, 80, NULL, NULL),
(339, 'транспортировка проводится в восстановительном положении;', 0, 80, NULL, NULL),
(340, 'Все варианты', 0, 80, NULL, NULL),
(341, 'охладить холодной водой не менее 15 минут;', 0, 81, NULL, NULL),
(342, 'наложить гипс;', 0, 81, NULL, NULL),
(343, 'обработать перекисью водорода;', 0, 81, NULL, NULL),
(344, 'Все варианты', 0, 81, NULL, NULL),
(345, 'придать удобное положение для пострадавшего;', 0, 82, NULL, NULL),
(346, 'для сохранения влаги повязки использовать полиэтиленовый пакет;', 0, 82, NULL, NULL),
(347, 'охладить холодной водой не менее 15 минут;', 0, 82, NULL, NULL),
(348, 'Все варианты', 0, 82, NULL, NULL),
(349, 'дать теплое питье;', 0, 83, NULL, NULL),
(350, 'обработать антисептиком;', 0, 83, NULL, NULL),
(351, 'растирать пораженные участки тела, втирать мази, масла, спирт;', 0, 83, NULL, NULL),
(352, 'Все варианты', 0, 83, NULL, NULL),
(353, '18.09.2008 ж;', 0, 84, NULL, NULL),
(354, '18.09.2007 ж;', 0, 84, NULL, NULL),
(355, '18.09.2006 ж;', 0, 84, NULL, NULL),
(356, '18.09.2009 ж.', 0, 84, NULL, NULL),
(357, 'қатты бетке арқасымен жату керек;', 0, 86, NULL, NULL),
(358, 'оң немесе сол жағында, қатты жерде жатуы керек;', 0, 86, NULL, NULL),
(359, 'қатты бетке ішімен жату керек;', 0, 86, NULL, NULL),
(360, 'барлық жауап дұрыс', 0, 86, NULL, NULL),
(361, 'ауыз қуысын тазалау, зардап шегушінің басын артқа тастау, ауызға немесе мұрынға үш рет жасанды дем\nалыңыз;', 0, 87, NULL, NULL),
(362, 'ауыз қуысын тазалау, зардап шегушінің басын артқа тастаңыз, ауызға немесе мұрынға бір жасанды тыныс\nалыңыз;', 0, 87, NULL, NULL),
(363, 'ауыз қуысын тазалау, зардап шегушінің басын артқа тастау, ауызға немесе мұрынға екі рет жасанды дем\nберу;', 0, 87, NULL, NULL),
(364, 'барлық жауап дұрыс', 0, 87, NULL, NULL),
(365, 'естен танған кезде, тыныс алу жоқ, ұйқы артериясында пульс бар;', 0, 88, NULL, NULL),
(366, 'ес-түссіз кезде, тыныс алу жоқ, ұйқы артериясында пульс жоқ;', 0, 88, NULL, NULL),
(367, 'ес-түссіз кезде тыныс алу бар, ұйқы артериясында пульс жоқ;', 0, 88, NULL, NULL),
(368, 'барлық жауап дұрыс', 0, 88, NULL, NULL),
(369, '40;', 0, 89, NULL, NULL),
(370, '35;', 0, 89, NULL, NULL),
(371, '30;', 0, 89, NULL, NULL),
(372, 'барлық жауап дұрыс', 0, 89, NULL, NULL),
(373, 'иық артериясын иық жағынан сүйекке қарсы басыңыз;', 0, 90, NULL, NULL),
(374, 'оқиға орнында жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адаммен жүзеге\nасырылатын төтенше жағдайлардағы асқынулардың алдын алу бойынша жедел негізгі шаралар кешені (өзара\nкөмек);', 0, 85, NULL, NULL),
(375, 'оқиға болған жерде жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адам жүзеге\nасыратын адамның өмірін сақтап қалу және төтенше жағдайлар кезінде асқынулардың алдын алу жөніндегі\nшұғыл негізгі шаралар кешені (өзара көмек);', 0, 85, NULL, NULL),
(376, 'жгутпен қатайтыңыз;', 0, 90, NULL, NULL),
(377, 'йод жағыңыз;', 0, 90, NULL, NULL),
(378, 'оқиға болған жерде жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адам жүзеге\nасыратын (өзара көмек) адамның өмірін сақтауға арналған шұғыл негізгі шаралар жиынтығы;', 0, 85, NULL, NULL),
(379, 'барлық жауап дұрыс', 0, 90, NULL, NULL),
(380, 'барлық жауап дұрыс', 0, 85, NULL, NULL),
(381, 'жара бірнеше қабатты таңғышпен жабылады, бәрі бинтпен тығыз бекітілген;', 0, 91, NULL, NULL),
(382, 'үстіне стерильді мақта салыңыз, барлығын бинтпен мықтап бекітіңіз;', 0, 91, NULL, NULL),
(383, 'жара бірнеше қабат таңғышпен жабылады, үстіне зарарсыздандырылған мақта мата қойылады, бәрі\nтаңғышпен мықтап бекітілген;', 0, 91, NULL, NULL),
(384, 'барлық жауап дұрыс', 0, 91, NULL, NULL),
(385, '10-15 минут ішінде мата арқылы салқын басыңыз;', 0, 92, NULL, NULL),
(386, '5-10 минут ішінде мата арқылы салқын басыңыз;', 0, 92, NULL, NULL),
(387, '15-20 минут ішінде мата арқылы салқын басыңыз.', 0, 92, NULL, NULL),
(388, 'барлық жауап дұрыс', 0, 92, NULL, NULL),
(389, 'жараны сумен шайыңыз;', 0, 93, NULL, NULL),
(390, 'жараны антисептикпен тазалаңыз;', 0, 93, NULL, NULL),
(391, 'жараны йодпен шайыңыз;', 0, 93, NULL, NULL),
(392, 'барлық жауап дұрыс', 0, 93, NULL, NULL),
(393, 'жараны сумен шайыңыз;', 0, 94, NULL, NULL),
(394, 'жараны антисептикпен тазалаңыз;', 0, 94, NULL, NULL),
(395, 'жараны йодпен шайыңыз;', 0, 94, NULL, NULL),
(396, 'барлық жауап дұрыс', 0, 94, NULL, NULL),
(397, 'артындағы қатты зембілде мойын астындағы тіректермен, төменгі артқы жағымен және тізе астында\nнемесе жұмсақ зембілмен - ішінде;', 0, 95, NULL, NULL),
(398, 'артқы жағында тізе астындағы тіреуішпен және сәл жайылған аяқтармен;', 0, 95, NULL, NULL),
(399, 'тасымалдау қалпына келтіру жағдайында жүзеге асырылады;', 0, 95, NULL, NULL),
(400, 'барлық жауап дұрыс', 0, 95, NULL, NULL),
(401, 'салқын сумен кем дегенде 15 минут салқындатыңыз;', 0, 96, NULL, NULL),
(402, 'гипс орнату;', 0, 96, NULL, NULL),
(403, 'сутегі асқын тотығымен өңдеңіз;', 0, 96, NULL, NULL),
(404, 'барлық жауап дұрыс', 0, 96, NULL, NULL),
(405, 'зардап шегушіге ыңғайлы жағдай беріңіз;', 0, 97, NULL, NULL),
(406, 'таңғыштың ылғалдылығын сақтау үшін полиэтилен пакетін қолданыңыз;', 0, 97, NULL, NULL),
(407, 'салқын сумен кем дегенде 15 минут салқындатыңыз;', 0, 97, NULL, NULL),
(408, 'барлық жауап дұрыс', 0, 97, NULL, NULL),
(409, 'жылы су беріңіз;', 0, 98, NULL, NULL),
(410, 'антисептикпен шаю;', 0, 98, NULL, NULL),
(411, 'дененің зардап шеккен аймақтарын сүрту, майлармен, майлармен, алкогольмен сүрту;', 0, 98, NULL, NULL),
(412, 'барлық жауап дұрыс', 0, 98, NULL, NULL),
(413, 'а) уполномоченным органом.', 0, 99, NULL, NULL),
(414, 'б) Правительством Республики Казахстан.', 0, 99, NULL, NULL),
(415, 'в) территориальным подразделением уполномоченного органа.', 0, 99, NULL, NULL),
(416, 'а) охрана жизни и здоровья людей, национального богатства и окружающей среды.', 0, 100, NULL, NULL),
(417, 'б) центральные и местные исполнительные органы, обеспечивающие пожарную безопасность, пожарно-технические научно-исследовательские учреждения, пожарно-технические учебные заведения. предприятия пожарно-технической продукции.', 0, 100, NULL, NULL),
(418, 'в) службы жизнеобеспечения.', 0, 100, NULL, NULL),
(419, 'а) горение легковоспламеняющихся предметов и жидкостей.', 0, 101, NULL, NULL),
(420, 'б) неконтролируемое горение, уничтожающее материальные ценности и загрязняющее окружающую среду.', 0, 101, NULL, NULL),
(421, 'в) неконтролируемое горение, причиняющее материальный ущерб, вред жизни и здоровью людей, интересам общества и государства.', 0, 101, NULL, NULL),
(422, 'а) гражданин, непосредственно участвующий на добровольной основе в деятельности по предупреждению и (или) тушению пожаров, зарегистрированный в реестре добровольных пожарных.', 0, 102, NULL, NULL),
(423, 'б) гражданин, непосредственно участвующий на добровольной основе (с заключением трудового договора) в деятельности по предупреждению пожаров.', 0, 102, NULL, NULL),
(424, 'в) гражданин Республики Казахстан, достигший 18 - летнего возраста, участвующий на добровольной основе (без заключения трудового договора) в деятельности по предупреждению и (или) тушению пожаров.', 0, 102, NULL, NULL),
(425, 'а) часть территории населенного пункта, которая предназначена для размещения коммунальных и промышленных объектов.', 0, 103, NULL, NULL),
(426, 'б) часть территории населенного пункта, которая предназначена для размещения жилищного фонда, общественных зданий и сооружений, а также отдельных коммунальных и промышленных объектов.', 0, 103, NULL, NULL),
(427, 'в) часть территории населенного пункта, которая предназначена для размещения жилищного фонда.', 0, 103, NULL, NULL),
(428, 'а) орган при местном исполнительном органе, создаваемый для осуществления мероприятий по тушению пожаров в организациях, населенных пунктах, в которых не созданы органы государственной противопожарной службы.', 0, 104, NULL, NULL),
(429, 'б) общественные объединения, создаваемые руководителями организаций для осуществления мероприятий по профилактике и тушению пожаров в организациях, в которых не созданы органы государственной противопожарной службы.', 0, 104, NULL, NULL),
(430, 'в) общественные объединения, создаваемые для осуществления мероприятий по профилактике и тушению степных пожаров, а также пожаров в организациях, населенных пунктах, в которых не созданы органы государственной противопожарной службы.', 0, 104, NULL, NULL),
(431, 'а) совокупность созданных в порядке, установленном законодательством Республики Казахстан, органов управления. сил и средств органов государственной противопожарной службы в областях, городе республиканского значения, столице, городах областного значения, районах, а также негосударственных противопожарных служб, предназначенных для организации предупреждения пожаров и их тушения, проведения первоочередных аварийно-спасательных работ, связанных с тушением пожаров.', 0, 105, NULL, NULL),
(432, 'б) личный состав оперативных служб гарнизона противопожарной службы, служб жизнеобеспечения, формирования ГО и ЧС, автотехника, средства связи и управления иные технические средства, находящиеся на их вооружении,', 0, 105, NULL, NULL),
(433, 'в) органы управления, личный состав противопожарной службы, ведомственных пожарных команд, добровольных противопожарных формирований.', 0, 105, NULL, NULL),
(434, 'а) обстоятельства и условия, влияющие на определение задач н характер их выполнения.', 0, 106, NULL, NULL),
(435, 'б) действия по спасению и эвакуации людей, имущества, оказанию первой доврачебной помощи пострадавшим при пожарах.', 0, 106, NULL, NULL),
(436, 'в) действия личного состава, первым прибывшим на место пожара.', 0, 106, NULL, NULL),
(437, 'а) деятельность физических или юридических лиц по предупреждению и тушению пожаров, обеспечению пожарной безопасности и проведению первоочередных аварийно-спасательных работ, связанных с пожарами в организациях и на объектах, на которых отсутствуют подразделения государственной противопожарной службы.', 0, 107, NULL, NULL),
(438, 'б) противопожарная служба, созданная по решению руководителя организации или объекта, которые расположены за радиусом обслуживания государственной противопожарной службы.', 0, 107, NULL, NULL),
(439, 'в) обязательная форма создания противопожарной службы в организациях, в которых отсутствуют подразделения государственной противопожарной службы.', 0, 107, NULL, NULL),
(440, 'а) Министерством по чрезвычайным ситуациям Республики Казахстан.', 0, 108, NULL, NULL),
(441, 'б) Правительством Республики Казахстан.', 0, 108, NULL, NULL),
(442, 'в) местным исполнительным органом.', 0, 108, NULL, NULL),
(443, 'а) граждане Республики Казахстан, достигшие совершеннолетия и прошедшие специальную подготовку и курсы обучения.', 0, 109, NULL, NULL),
(444, 'б) граждане Республики Казахстан, имеющие специальное образование.', 0, 109, NULL, NULL),
(445, 'в) граждане Республики Казахстан, имеющие специальное образование и стаж работы в государственной противопожарной службе.', 0, 109, NULL, NULL),
(446, 'а) ликвидация возникшего пожара всеми доступными способами и средствами. ', 0, 110, NULL, NULL),
(447, 'б) объединенные усилия людей и техники, предпринимаемые для ликвидации пожаров. ', 0, 110, NULL, NULL),
(448, 'в) действия, направленные на спасение граждан, имущества и ликвидацию пожаров.', 0, 110, NULL, NULL),
(449, 'а) охрана жизни и здоровья людей, собственности, национального богатства и окружающей среды в области пожарной безопасности.', 0, 111, NULL, NULL),
(450, 'б) конфиденциальность в деятельности по обеспечению пожарной безопасности.', 0, 111, NULL, NULL),
(451, 'в) заблаговременное определение степени риска в деятельности организаций и граждан, обучение мерам предупреждения и осуществление профилактических мероприятий в области пожарной безопасности.', 0, 111, NULL, NULL),
(452, 'а) производится в порядке, определяемом Правительством Республики Казахстан.', 0, 112, NULL, NULL),
(453, 'б) производится в порядке, определяемом уполномоченным органом.', 0, 112, NULL, NULL),
(454, 'в) не производится.', 0, 112, NULL, NULL),
(455, 'а) по согласованно с уполномоченным органом в области пожарной безопасности.', 0, 113, NULL, NULL),
(456, 'б) в безусловном порядке.', 0, 113, NULL, NULL),
(457, 'в) на основе заключённых договоров.', 0, 113, NULL, NULL),
(458, 'а) уәкілетті орган', 0, 114, NULL, NULL),
(459, 'б) Қазақстан Республикасының Үкіметі', 0, 114, NULL, NULL),
(460, 'в) уәкілетті органның аумақтық бөлімшесі', 0, 114, NULL, NULL),
(461, 'а) адамдардың өмірі мен денсаулығын, ұлттық байлық пен қоршаған ортаны қорғау', 0, 115, NULL, NULL),
(462, 'б) өрт қауіпсіздігін қамтамасыз ететін орталық және жергілікті атқарушы органдар, өрт-техникалық зерттеу мекемелері, өрт-техникалық оқу орындары. өртке қарсы кәсіпорындар', 0, 115, NULL, NULL),
(463, 'в) өмірді қолдау қызметтері', 0, 115, NULL, NULL),
(464, 'а) жанғыш заттар мен сұйықтықтардың жануы', 0, 116, NULL, NULL),
(465, 'б) материалдық құндылықтарды жоятын және қоршаған ортаны ластайтын бақылаусыз жану', 0, 116, NULL, NULL),
(466, 'в) материалдық залал, адамдардың өмірі мен денсаулығына, қоғам мен мемлекеттің мүдделеріне зиян келтіретін бақылаусыз жану', 0, 116, NULL, NULL),
(467, 'а) өрттің алдын алу немесе сөндіру жөніндегі іс-шараларға ерікті түрде өрт сөндірушілер тізілімінде тіркелген азамат', 0, 117, NULL, NULL),
(468, 'б) өрттің алдын-алу шараларына ерікті негізде (еңбек шартын жасасумен) тікелей қатысатын азамат', 0, 117, NULL, NULL),
(469, 'в) өрттің алдын алуға және (немесе) сөндіруге ерікті негізде (еңбек шартын жасамай) қатысатын 18 жасқа толған ҚР азаматы', 0, 117, NULL, NULL),
(470, 'а) елді мекен аумағының коммуналдық және өндірістік объектілерді орналастыруға арналған бөлігі', 0, 118, NULL, NULL),
(471, 'б) тұрғын үйге, қоғамдық ғимараттар мен құрылыстарға, сондай-ақ жеке коммуналдық және өндірістік объектілерге арналған елді мекен аумағының бөлігі', 0, 118, NULL, NULL),
(472, 'в) елді мекен аумағының тұрғын үй салуға арналған бөлігі', 0, 118, NULL, NULL),
(473, 'а) мемлекеттік өртке қарсы қызмет органдары құрылмайтын ұйымдарда, елді мекендерде өрт сөндіру шараларын жүргізу үшін құрылған жергілікті атқарушы органның жанындағы орган', 0, 119, NULL, NULL),
(474, 'б) мемлекеттік өртке қарсы қызмет органдары құрылмайтын ұйымдарда өрттің алдын алу және сөндіру жөніндегі шараларды іске асыру үшін ұйымдардың басшылары құрған қоғамдық бірлестіктер', 0, 119, NULL, NULL),
(475, 'в) мемлекеттік өртке қарсы қызмет органдары құрылмайтын ұйымдардағы, елді мекендердегі өрттің алдын алу және сөндіру жөніндегі іс-шараларды жүзеге асыру үшін құрылған қоғамдық бірлестіктер', 0, 119, NULL, NULL),
(476, 'а) ҚР заңнамасына сәйкес құрылған басқару органдарының жиынтығы. өрттің алдын алуды ұйымдастыруға және оларды сөндіруге, өртті сөндіруге байланысты авариялық-құтқару жұмыстарын жүргізуге арналған облыстардағы, республикалық маңызы бар қаладағы, астананың, облыстық маңызы бар қалалардың, аудандардың, сондай-ақ мемлекеттік емес өртке қарсы қызмет органдарының күштері мен құралдарының', 0, 120, NULL, NULL),
(477, 'б) өртке қарсы қызмет гарнизонының жедел қызметтері, тіршілікті қамтамасыз ету, азаматтық қорғаныс және төтенше жағдайды қалыптастыру, автомобиль жабдықтары, байланыс және басқару жабдықтары және олардың арсеналындағы басқа да техникалық жабдықтар', 0, 120, NULL, NULL),
(478, 'в) басқару органдары, өрт сөндіру қызметінің жеке құрамы, ведомстволық өрт бригадалары, ерікті өрт сөндіру топтары', 0, 120, NULL, NULL),
(479, 'а) міндеттерді анықтауға әсер ететін жағдайлар мен жағдайлар, оларды орындау сипаты', 0, 121, NULL, NULL),
(480, 'б) адамдарды, мүлікті сақтау және эвакуациялау, өрттен зардап шеккендерге алғашқы көмек көрсету бойынша іс-шаралар', 0, 121, NULL, NULL),
(481, 'в) өрт болған жерге бірінші болып келген қызметкерлердің әрекеттері', 0, 121, NULL, NULL),
(482, 'а) жеке және заңды тұлғалардың өрттің алдын-алу және сөндіру, өрт қауіпсіздігін қамтамасыз ету және мемлекеттік өртке қарсы қызмет бөлімшелері жоқ ұйымдар мен ұйымдардағы өртке байланысты авариялық-құтқару жұмыстарын жүргізу жөніндегі қызметі', 0, 122, NULL, NULL),
(483, 'б) мемлекеттік өртке қарсы қызметтің қызмет радиусынан тыс орналасқан ұйым немесе объект басшысының шешімі бойынша құрылған өртке қарсы қызмет', 0, 122, NULL, NULL),
(484, 'в) мемлекеттік өртке қарсы қызмет бөлімшелері жоқ ұйымдарда өртке қарсы қызмет құрудың міндетті нысаны', 0, 122, NULL, NULL),
(485, 'а) Қазақстан Республикасы Төтенше жағдайларымен', 0, 123, NULL, NULL),
(486, 'б) Қазақстан Республикасының Үкіметі', 0, 123, NULL, NULL),
(487, 'в) жергілікті атқарушы орган', 0, 123, NULL, NULL),
(488, 'а) кәмелетке толған және арнайы оқыту мен даярлау курстарынан өткен ҚР азаматтары', 0, 124, NULL, NULL),
(489, 'б) арнайы білімі бар ҚР азаматтары', 0, 124, NULL, NULL),
(490, 'в) мемлекеттік өртке қарсы қызметте жұмыс тәжірибесі және арнайы білімі бар ҚР азаматтары', 0, 124, NULL, NULL),
(491, 'а) өртті барлық қол жетімді құралдармен және құралдармен жою', 0, 125, NULL, NULL),
(492, 'б) өртті сөндіру үшін адамдар мен техниканың бірлескен күш-жігері', 0, 125, NULL, NULL),
(493, 'в) азаматтарды, мүлікті үнемдеуге және өртті сөндіруге бағытталған іс-шаралар', 0, 125, NULL, NULL),
(494, 'а) өрт қауіпсіздігі саласындағы адамдардың өмірі мен денсаулығын, меншікті, ұлттық байлықты және қоршаған ортаны қорғау', 0, 126, NULL, NULL),
(495, 'б) өрт қауіпсіздігі саласындағы құпиялылық', 0, 126, NULL, NULL);
INSERT INTO `options` (`id`, `body`, `isTrue`, `question_id`, `created_at`, `updated_at`) VALUES
(496, 'в) ұйымдар мен азаматтардың қызметіндегі қауіптің дәрежесін ертерек анықтау, алдын-алу шараларын үйрету және өрт қауіпсіздігі саласында алдын-алу шараларын орындау', 0, 126, NULL, NULL),
(497, 'а) Қазақстан Республикасының Үкіметі белгілеген тәртіппен жасалады', 0, 127, NULL, NULL),
(498, 'б) уәкілетті орган айқындайтын тәртіппен жасалады', 0, 127, NULL, NULL),
(499, 'в) өндірілмейді', 0, 127, NULL, NULL),
(500, 'а) өрт қауіпсіздігі саласындағы уәкілетті органмен келісу бойынша', 0, 128, NULL, NULL),
(501, 'б) сөзсіз', 0, 128, NULL, NULL),
(502, 'в) жасалған келісімдер негізінде', 0, 128, NULL, NULL),
(503, '1) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді күтіп ұстауға, пайдалануға және орналастыруға қойылатын гигиеналық және санитариялық-эпидемиологиялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 129, NULL, NULL),
(504, '2) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді пайдалануға қойылатын гигиеналық және санитариялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 129, NULL, NULL),
(505, '3) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді күтіп ұстауға және орналастыруға қойылатын гигиеналық және эпидемиологиялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 129, NULL, NULL),
(506, '4) барлық жауап дұрыс', 0, 129, NULL, NULL),
(507, '1) ҚР 19.09.2009 ж «Халық денсаулығы және денсаулық сақтау жүйесі туралы» Кодексінің 148б 5т', 0, 130, NULL, NULL),
(508, '2) ҚР 18.08.2009 ж «Халық денсаулығы және денсаулық сақтау жүйесі туралы» Кодексінің 148б 5т', 0, 130, NULL, NULL),
(509, '3) ҚР 18.09.2009 ж «Халық денсаулығы және денсаулық сақтау жүйесі туралы» Кодексінің 148б 5т', 0, 130, NULL, NULL),
(510, '4) ҚР 18.09.2008 ж «Халық денсаулығы және денсаулық сақтау жүйесі туралы» Кодексінің 148б 5т', 0, 130, NULL, NULL),
(511, '1) «Декреттелген топтағы адамдарды гигиеналық оқытудың ережелері мен қағидаларын бекіту туралы» ', 0, 131, NULL, NULL),
(512, '2) «Декреттелген топтағы адамдарды гигиеналық оқытудың қағидалары мен бағдарламаларын бекіту туралы» ', 0, 131, NULL, NULL),
(513, '3) «Декреттелген топтағы адамдарды гигиеналық оқытудың ережелері мен бағдарламаларын бекіту туралы» ', 0, 131, NULL, NULL),
(514, '4) «Декреттелген топтағы адамдарды гигиеналық оқытудың ережелері мен талаптарын бекіту туралы» ', 0, 131, NULL, NULL),
(515, '1) халыққа қызмет көрсету саласында жұмыс істейтін және айналасындағы адамдарға инфекциялық аурулар жұқтырудың анағұрлым ықтимал қаупін төндіретін адамдар', 0, 132, NULL, NULL),
(516, '2) халыққа қызмет көрсету саласында жұмыс істейтін және айналасындағы адамдарға инфекциялық және паразиттік аурулар жұқтырудың анағұрлым ықтимал қаупін төндіретін адамдар', 0, 132, NULL, NULL),
(517, '3) халыққа қызмет көрсету саласында жұмыс істейтін және айналасындағы адамдарға паразиттік аурулар жұқтырудың анағұрлым ықтимал қаупін төндіретін адамдар', 0, 132, NULL, NULL),
(518, '4) айналасындағы адамдарға инфекциялық және паразиттік аурулар жұқтырудың анағұрлым ықтимал қаупін төндіретін адамдар', 0, 132, NULL, NULL),
(519, '1) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі жылына екі рет кезеңділігімен жүргізіледі', 0, 133, NULL, NULL),
(520, '2) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі екі жылда бір рет кезеңділігімен жүргізіледі', 0, 133, NULL, NULL),
(521, '3) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі жылына бір рет кезеңділігімен жүргізіледі', 0, 133, NULL, NULL),
(522, '4) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі үш жылда бір рет кезеңділігімен жүргізіледі', 0, 133, NULL, NULL),
(523, '1) халықтың декреттелген тобы дербес көтереді немесе объектінің басшысы', 0, 134, NULL, NULL),
(524, '2) халықтың декреттелген тобы дербес көтереді немесе тараптардың келісімі бойынша гигиеналық оқыту шығыстарын объектінің басшысы', 0, 134, NULL, NULL),
(525, '3) тараптардың келісімі бойынша гигиеналық оқыту шығыстарын объектінің басшысы', 0, 134, NULL, NULL),
(526, '4) барлық жауап дұрыс', 0, 134, NULL, NULL),
(527, '1) міндетті медициналық қарап-тексерудің нәтижелері енгізілетін жеке құжат', 0, 135, NULL, NULL),
(528, '2) жұмысқа жіберілу туралы белгі қойылып, міндетті медициналық қарап-тексерудің нәтижелері енгізілетін жеке құжат', 0, 135, NULL, NULL),
(529, '3) жұмысқа жіберілу туралы, міндетті медициналық қарап-тексерудің нәтижелері енгізілетін жеке құжат', 0, 135, NULL, NULL),
(530, '4) жұмысқа жіберілу туралы белгі қойылып, нәтижелер енгізілетін жеке құжат', 0, 135, NULL, NULL),
(531, '1) тесттік бақылау түрінде аттестаттау (емтихан) жүргізіледі', 0, 136, NULL, NULL),
(532, '2) тесттік бақылау түрінде аттестаттау жүргізіледі', 0, 136, NULL, NULL),
(533, '3) ауызша сұрақ түрінде аттестаттау (емтихан) жүргізіледі', 0, 136, NULL, NULL),
(534, '4) жазбаша сұрақ түрінде аттестаттау (емтихан) жүргізіледі', 0, 136, NULL, NULL),
(535, '1) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 137, NULL, NULL),
(536, '2) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 137, NULL, NULL),
(537, '3) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 137, NULL, NULL),
(538, '4) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 137, NULL, NULL),
(539, '1) 425-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 138, NULL, NULL),
(540, '2) 423-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 138, NULL, NULL),
(541, '3) 424-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 138, NULL, NULL),
(542, '4) 426-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 138, NULL, NULL),
(543, '1) 1600', 0, 139, NULL, NULL),
(544, '2) 30', 0, 139, NULL, NULL),
(545, '3) 230', 0, 139, NULL, NULL),
(546, '4) 310', 0, 139, NULL, NULL),
(547, '1) 310', 0, 140, NULL, NULL),
(548, '2) 230', 0, 140, NULL, NULL),
(549, '3) 460', 0, 140, NULL, NULL),
(550, '4) 320', 0, 140, NULL, NULL),
(551, '1) «Білім беру объектілеріне қойылатын санитариялық талаптар санитариялық қағидаларын бекіту туралы»', 0, 141, NULL, NULL),
(552, '2) «Білім беру объектілеріне қойылатын эпидемиологиялық талаптар санитариялық қағидаларын бекіту туралы»', 0, 141, NULL, NULL),
(553, '3) «Білім беру объектілеріне қойылатын санитариялық-эпидемиологиялық талаптар санитариялық қағидаларын бекіту туралы»', 0, 141, NULL, NULL),
(554, '4) барлық жауап дұрыс', 0, 141, NULL, NULL),
(555, '1) 1,4 м биіктікте', 0, 142, NULL, NULL),
(556, '2) 1,5 м биіктікте', 0, 142, NULL, NULL),
(557, '3) 1,3 м биіктікте', 0, 142, NULL, NULL),
(558, '4) 1,6 м биіктікте', 0, 142, NULL, NULL),
(559, '1) кемінде 5 минутты құрайды', 0, 143, NULL, NULL),
(560, '2) кемінде 15 минутты құрайды', 0, 143, NULL, NULL),
(561, '3) кемінде 25 минутты құрайды', 0, 143, NULL, NULL),
(562, '4) кемінде 30 минутты құрайды', 0, 143, NULL, NULL),
(563, '1) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению личной гигиены в соответствии с профессиями обучающихся;', 0, 144, NULL, NULL),
(564, '2) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению личной и общественной гигиены в соответствии с профессиями обучающихся;', 0, 144, NULL, NULL),
(565, '3) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению общественной гигиены;', 0, 144, NULL, NULL),
(566, '4) все ответы верны', 0, 144, NULL, NULL),
(567, '1) п.5 ст.148 Кодекса РК от 18.08.2009 г \"О здоровье народа и системе здравоохранения\"', 0, 145, NULL, NULL),
(568, '2) п.5 ст.148 Кодекса РК от 18.09.2008 г \"О здоровье народа и системе здравоохранения\"', 0, 145, NULL, NULL),
(569, '3) п.5 ст.148 Кодекса РК от 18.09.2009 г \"О здоровье народа и системе здравоохранения\"', 0, 145, NULL, NULL),
(570, '4) все ответы верны', 0, 145, NULL, NULL),
(571, '1) Об утверждении Правил гигиенического обучения лиц декретированной группы населения ', 0, 146, NULL, NULL),
(572, '2) Об утверждении Программ гигиенического обучения лиц декретированной группы населения', 0, 146, NULL, NULL),
(573, '3) Об утверждении Правил гигиенического обучения лиц декретированной группы населения и Программ гигиенического обучения лиц декретированной группы населения', 0, 146, NULL, NULL),
(574, '4) все ответы верны', 0, 146, NULL, NULL),
(575, '1) лица, работающие в сфере обслуживания населения и представляющие наибольшую опасность для заражения окружающих людей паразитарными заболеваниями;', 0, 147, NULL, NULL),
(576, '2) лица, работающие в сфере обслуживания населения и представляющие наибольшую опасность для заражения окружающих людей инфекционными заболеваниями;', 0, 147, NULL, NULL),
(577, '3) лица, работающие в сфере обслуживания населения и представляющие наибольшую опасность для заражения людей инфекционными и паразитарными заболеваниями;', 0, 147, NULL, NULL),
(578, '4) лица, работающие в сфере обслуживания населения и представляющие наибольшую опасность для заражения окружающих людей инфекционными и паразитарными заболеваниями;', 0, 147, NULL, NULL),
(579, '1) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в два года', 0, 148, NULL, NULL),
(580, '2) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в три года', 0, 148, NULL, NULL),
(581, '3) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в год', 0, 148, NULL, NULL),
(582, '4) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в пол года.', 0, 148, NULL, NULL),
(583, '1) самостоятельно, либо по соглашению сторон расходы на гигиеническое обучение могут быть понесены руководителем объекта.', 0, 149, NULL, NULL),
(584, '2) самостоятельно, либо без соглашения сторон расходы на гигиеническое обучение могут быть понесены руководителем объекта.', 0, 149, NULL, NULL),
(585, '3) самостоятельно, либо по соглашению сторон расходы на гигиеническое обучение не могут быть понесены руководителем объекта.', 0, 149, NULL, NULL),
(586, '4) все ответы верны', 0, 149, NULL, NULL),
(587, '1) индивидуальный документ, в который заносятся результаты обязательных медицинских осмотров с отметкой о допуске к работе', 0, 150, NULL, NULL),
(588, '2) персональный документ, в который заносятся результаты медицинских осмотров с отметкой о допуске к работе', 0, 150, NULL, NULL),
(589, '3) персональный документ, в который заносятся результаты обязательных медицинских осмотров с отметкой о допуске к работе', 0, 150, NULL, NULL),
(590, '4) все ответы верны', 0, 150, NULL, NULL),
(591, '1) экзамен в виде тестового контроля', 0, 151, NULL, NULL),
(592, '2) аттестация в виде тестового контроля', 0, 151, NULL, NULL),
(593, '3) аттестация (экзамен) в виде тестового контроля', 0, 151, NULL, NULL),
(594, '4) все ответы верны', 0, 151, NULL, NULL),
(595, '1) должностными лицами территориального подразделения ведомства государственного органа в сфере эпидемиологического контроля населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 152, NULL, NULL),
(596, '2) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарного благополучия населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 152, NULL, NULL),
(597, '3) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарно-эпидемиологического благополучия населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 152, NULL, NULL),
(598, '4) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарно-эпидемиологического контроля населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 152, NULL, NULL),
(599, '1) Статья 425 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 153, NULL, NULL),
(600, '2) Статья 424 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 153, NULL, NULL),
(601, '3) Статья 423 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 153, NULL, NULL),
(602, '4) все ответы верны', 0, 153, NULL, NULL),
(603, '1) 230 МРП', 0, 154, NULL, NULL),
(604, '2) 30 МРП', 0, 154, NULL, NULL),
(605, '3) 310 МРП', 0, 154, NULL, NULL),
(606, '4) 1600 МРП', 0, 154, NULL, NULL),
(607, '1) 30 МРП', 0, 155, NULL, NULL),
(608, '2) 230 МРП', 0, 155, NULL, NULL),
(609, '3) 1600 МРП', 0, 155, NULL, NULL),
(610, '4) 310 МРП', 0, 155, NULL, NULL),
(611, '1) «Об утверждении Санитарных правил \"Санитарно-гигиенические требования к объектам образования»', 0, 156, NULL, NULL),
(612, '2) «Об утверждении Санитарных правил \"Эпидемиологические требования к объектам образования»', 0, 156, NULL, NULL),
(613, '3) «Об утверждении Санитарных правил \"Санитарно-эпидемиологические требования к объектам образования»', 0, 156, NULL, NULL),
(614, '4) все ответы верны', 0, 156, NULL, NULL),
(615, '1) менее 1,5 м', 0, 157, NULL, NULL),
(616, '2) не менее 1,5 м', 0, 157, NULL, NULL),
(617, '3) более 1,8 м', 0, 157, NULL, NULL),
(618, '4) не менее 1,8 м', 0, 157, NULL, NULL),
(619, '1) не менее 5 минут', 0, 158, NULL, NULL),
(620, '2) не менее 30 минут', 0, 158, NULL, NULL),
(621, '3) не менее 15 минут', 0, 158, NULL, NULL),
(622, '4) все ответы верны', 0, 158, NULL, NULL),
(623, 'А) ұстауға, ашуға, су құюға', 1, 159, NULL, NULL),
(624, 'Б) адамдарды көмекке шақыруға', 0, 159, NULL, NULL),
(625, 'В) құқық қорғау органдарына хабарласуға', 0, 159, NULL, NULL),
(626, 'Г) барлық жауап дұрыс', 0, 159, NULL, NULL),
(627, 'А) жеке тұлғаларға немесе лауазымды адамдарға жүз мөлшерінде айыппұл, шағын бизнес немесе коммерциялық емес ұйымдар үшін - екі жүз, орта бизнес үшін - үш жүз, ірі кәсіпкерлік субъектілері үшін - бес жүз айлық есептік көрсеткіш мөлшерінде айыппұл ', 1, 160, NULL, NULL),
(628, 'Б) 5000 АЕК дейiнгi мөлшерiнде айыппұл салуға немесе сол мөлшерде түзеу жұмыстарына, немесе бес жылға дейiнгi мерзiмге бас бостандығын шектеуге немесе дәл сол мерзiмге бас бостандығынан айыруға', 0, 160, NULL, NULL),
(629, 'В) 120 АЕК дейінгі мөлшерінде айыппұл, дәл сол мөлшердегі түзету жұмыстары немесе жүз жиырма сағатқа дейінгі мерзімге қоғамдық қызметпен айналысу немесе отыз тәулікке дейін қамауға алу.', 0, 160, NULL, NULL),
(630, 'Г) барлық жауап дұрыс', 0, 160, NULL, NULL),
(631, 'А) Сөйлесуді жазу', 0, 161, NULL, NULL),
(632, 'Б) Нөмірді анықтау үшін автоматты телефон станциясына қоңырау шалу', 0, 161, NULL, NULL),
(633, 'В) Сөйлесу уақыты мен ұзақтығын жазу', 0, 161, NULL, NULL),
(634, 'Г) барлық жауап дұрыс', 1, 161, NULL, NULL),
(635, 'А) 1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейінгі мерзімге қоғамдық қызметке қатысу, немесе бір жылға дейінгі мерзімге бас бостандығын шектеу немесе дәл сол мерзімге бас бостандығынан айыру ', 1, 162, NULL, NULL),
(636, 'Б) 1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейін қоғамдық қызметпен айналысу, немесе үш жылға дейінгі мерзімге бас бостандығын шектеу немесе сол мерзімге бас бостандығынан айыру ', 0, 162, NULL, NULL),
(637, 'В) 1000 АЕК немесе дәл осындай мөлшердегі түзету жұмыстары немесе төрт жүз сағатқа дейін қоғамдық қызметпен айналысу, немесе екі жылға дейінгі бас бостандығын шектеу немесе дәл сол мерзімге бас бостандығынан айыру ', 0, 162, NULL, NULL),
(638, 'Г) барлық жауап дұрыс', 0, 162, NULL, NULL),
(639, 'А) 112;', 0, 163, NULL, NULL),
(640, 'Б) 110;', 1, 163, NULL, NULL),
(641, 'В 111;', 0, 163, NULL, NULL),
(642, 'Г) барлық жауап дұрыс', 0, 163, NULL, NULL),
(643, 'А) Оқиға сипаты', 0, 164, NULL, NULL),
(644, 'Б) нақты мекен-жайы көрсетілген оқиға орны', 0, 164, NULL, NULL),
(645, 'В) Зардап шеккендердің саны, олардың арасында балалар бар жоғы', 0, 164, NULL, NULL),
(646, 'Г) барлық жауап дұрыс', 1, 164, NULL, NULL),
(647, 'А) орташа «жасыл»', 0, 165, NULL, NULL),
(648, 'Б) орташа «қызғылт сары»', 0, 165, NULL, NULL),
(649, 'В) сыни «қызыл»', 1, 165, NULL, NULL),
(650, 'Г) барлық жауап дұрыс', 0, 165, NULL, NULL),
(651, 'А) орташа «жасыл»', 0, 166, NULL, NULL),
(652, 'Б) орташа «сары»', 1, 166, NULL, NULL),
(653, 'В) орташа «қызғылт сары»', 0, 166, NULL, NULL),
(654, 'Г) барлық жауап дұрыс', 0, 166, NULL, NULL),
(655, 'А) 24.06.2014 жылғы № 589;', 0, 167, NULL, NULL),
(656, 'Б) 24.06.2015 жылғы № 589;', 0, 167, NULL, NULL),
(657, 'В) 24.06.2013 жылғы № 589;', 1, 167, NULL, NULL),
(658, 'Г) барлық жауап дұрыс', 0, 167, NULL, NULL),
(659, 'А) 08.07.2016 жылғы;', 0, 168, NULL, NULL),
(660, 'Б) 08.06.2015 жылғы;', 0, 168, NULL, NULL),
(661, 'В) 08.07.2015 жылғы;', 1, 168, NULL, NULL),
(662, 'Г) барлық жауап дұрыс', 0, 168, NULL, NULL),
(663, 'А) Терроризмге қарсы осал объектілердің терроризмге қарсы қауіпсіздігінің терроризмге қарсы паспортын бекіту туралы', 0, 169, NULL, NULL),
(664, 'Б) Терроризмге қарсы осал объектілерді терроризмге қарсы қорғаудың үлгілік паспортын бекіту туралы', 0, 169, NULL, NULL),
(665, 'В) Террористік тұрғыдан осал нысандарды терроризмге қарсы қорғаудың үлгілік паспортын бекіту туралы', 1, 169, NULL, NULL),
(666, 'Г) барлық жауап дұрыс', 0, 169, NULL, NULL),
(667, 'А) терроризм актісін жасаудың нақты мүмкіндігі туралы расталған ақпарат болған кезде;', 1, 170, NULL, NULL),
(668, 'Б) терроризм актісін жасаудың шынайы мүмкіндігін растауды талап ететін ақпарат болған кезде;', 0, 170, NULL, NULL),
(669, 'В) егер терроризм актісі туралы ақпарат болса, сондай-ақ терроризмнің екінші актісі болуы немесе терроризмге осал объектілерге бір мезгілде террористік шабуыл жасалуы мүмкін екендігі туралы расталған ақпарат болған жағдайда;', 0, 170, NULL, NULL),
(670, 'Г) барлық жауап дұрыс', 0, 170, NULL, NULL),
(671, 'А) мүлкін тәркілеумен 6 жылдан 9 жылға дейін бас бостандығынан айыру', 0, 171, NULL, NULL),
(672, 'Б) мүлкін тәркілеумен 5 жылдан 9 жылға дейін бас бостандығынан айыру', 1, 171, NULL, NULL),
(673, 'В) мүлкін тәркілеумен 5 жылдан 8 жылға дейін бас бостандығынан айыру', 0, 171, NULL, NULL),
(674, 'Г) барлық жауап дұрыс', 0, 171, NULL, NULL),
(675, 'А) күш қолдану идеологиясы;', 1, 172, NULL, NULL),
(676, 'Б) терроризм;', 0, 172, NULL, NULL),
(677, 'В) терроризма актісі;', 0, 172, NULL, NULL),
(678, 'Г) барлық жауап дұрыс', 0, 172, NULL, NULL),
(679, 'А) 13 маусым 1999 ж;', 0, 173, NULL, NULL),
(680, 'Б) 13 шілде 1998 ж;', 0, 173, NULL, NULL),
(681, 'В) 13 шілде 1999 ж;', 1, 173, NULL, NULL),
(682, 'Г) 13 шілде 1997 ж', 0, 173, NULL, NULL),
(683, 'А) тұтқындарды босату туралы террористермен келісіңіз', 0, 174, NULL, NULL),
(684, 'Б) террористерге шабуыл жасау және қарусыздандыру', 0, 174, NULL, NULL),
(685, 'В) барлық талаптарды орындау', 1, 174, NULL, NULL),
(686, 'Г) барлық жауап дұрыс', 0, 174, NULL, NULL),
(687, 'А) үй-жайларды тексеру техникасына, жарылғыш құрылғыларды орналастыруға болатын орындарды анықтауға арналған алдын алу және тәрбиелік шараларды жүргізу', 0, 175, NULL, NULL),
(688, 'Б) терроризм актісі нәтижесінде туындаған қатерлерді жою бойынша мүдделі мемлекеттік органдармен және ұйымдармен бірлескен іс-шараларды жоспарлау және әзірлеу', 0, 175, NULL, NULL),
(689, 'В) стандартты төлқұжат негізінде - оларға сеніп тапсырылған объектілерді терроризмге қарсы қорғау паспорты негізінде әзірлеу.', 0, 175, NULL, NULL),
(690, 'Г) барлық жауап дұрыс', 1, 175, NULL, NULL),
(691, 'А) Терроризм актісінің күтілетін теріс салдары, қоғамдық қауіптіліктің ауқымы мен дәрежесіне байланысты, терроризмге қарсы операцияны республикалық немесе аймақтық жедел штабтың басшысы басқарады.', 0, 176, NULL, NULL),
(692, 'Б) Терроризм актісінің күтілетін теріс салдарлары, қоғамдық қауіптіліктің дәрежесі мен дәрежесіне байланысты республикалық немесе облыстық, республикалық маңызы бар қала, астана, аудан және әскери-теңіз штабы бастығының орынбасары басқарады', 0, 176, NULL, NULL),
(693, 'В) Терроризм актісінің күтілетін теріс салдары, қоғамдық қауіптіліктің ауқымы мен дәрежесіне байланысты, терроризмге қарсы операцияны басқаруды республикалық немесе облыстық, республикалық маңызы бар қаланың, астананың, ауданның және әскери-жедел штабтың басшысы жүзеге асырады.', 1, 176, NULL, NULL),
(694, 'Г) барлық жауап дұрыс', 0, 176, NULL, NULL),
(695, 'А) «ҚР террористік тұрғыдан осал ұйымдарының тізімін бекіту туралы»;', 0, 177, NULL, NULL),
(696, 'Б) «ҚР терроризмге қарсы осал нысандардың тізімін бекіту туралы»; ', 0, 177, NULL, NULL),
(697, 'В) «ҚР террористік тұрғыдан осал нысандардың тізімін бекіту туралы»; ', 1, 177, NULL, NULL),
(698, 'Г) барлық жауап дұрыс', 0, 177, NULL, NULL),
(699, 'А) егер терроризм актісі туралы ақпарат болса, сондай-ақ терроризмнің екінші актісі (актілері) болуы немесе терроризмге осал объектілерге бір мезгілде террористік шабуыл жасалуы мүмкін екендігі туралы расталған ақпарат болған жағдайда;', 0, 178, NULL, NULL),
(700, 'Б) терроризм актісінің шынайы мүмкіндігін растауды қажет ететін ақпарат болған кезде', 1, 178, NULL, NULL),
(701, 'В) егер терроризм актісінің нақты мүмкіндігі туралы расталған ақпарат болса', 0, 178, NULL, NULL),
(702, 'Г) барлық жауап дұрыс', 0, 178, NULL, NULL),
(703, 'А) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 148-бабы.', 0, 179, NULL, NULL),
(704, 'Б) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 149 -бабы.', 1, 179, NULL, NULL),
(705, 'В) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 147 -бабы.', 0, 179, NULL, NULL),
(706, 'Г) барлық жауап дұрыс', 0, 179, NULL, NULL),
(707, 'А) Полиция қызметкерлері', 1, 180, NULL, NULL),
(708, 'Б) Прокуратура қызметкерлері;', 0, 180, NULL, NULL),
(709, 'В) Көші-қон полициясы қызметкерлері', 0, 180, NULL, NULL),
(710, 'Г) барлық жауап дұрыс', 0, 180, NULL, NULL),
(711, 'А) Орталық атқарушы мемлекеттік органдардың, арнаулы, құқық қорғау органдарының, олардың құрылымдық және аумақтық бөлімшелерінің, жергілікті өкілді және атқарушы органдардың әкімшілік ғимараттары мен құрылыстары', 1, 181, NULL, NULL),
(712, 'Б) ҚР Президенті бекіткен тізімге енгізілген ҚР Мемлекеттік күзет қызметі ІІБ бөлімдерімен бірге қорғайтын объектілер, сондай-ақ мемлекеттік маңызы бар объектілер', 0, 181, NULL, NULL),
(713, 'В) Аса қауіпті, бактериологиялық, биологиялық, химиялық, есірткі мен прекурсорларды әзірлеу, өндіру, сынау, зерттеу және сақтау жөніндегі мемлекеттік ұйымдар мен мекемелердің нысандары', 0, 181, NULL, NULL),
(714, 'Г) барлық жауап дұрыс', 0, 181, NULL, NULL),
(715, 'А) Стратегиялық нысандар', 0, 182, NULL, NULL),
(716, 'Б) Қауіпті өндірістік нысандар', 1, 182, NULL, NULL),
(717, 'В) Аса маңызды мемлекеттік нысандар', 0, 182, NULL, NULL),
(718, 'Г) барлық жауап дұрыс', 0, 182, NULL, NULL),
(719, 'А) Ақпаратты бақылау және терроризм актісінің қаупі туралы халықты хабардар етудің мемлекеттік жүйесін ұйымдастыру және жұмыс істеу ережесін бекіту туралы', 1, 183, NULL, NULL),
(720, 'Б) Террористік тұрғыдан осал нысандардың терроризмге қарсы қорғау жүйесіне қойылатын талаптарды бекіту туралы', 0, 183, NULL, NULL),
(721, 'В) ҚР Террористік тұрғыдан осал нысандардың тізімін бекіту туралы', 0, 183, NULL, NULL),
(722, 'Г) барлық жауап дұрыс', 0, 183, NULL, NULL),
(723, 'А) терроризмге қарсы жедел штаб', 1, 184, NULL, NULL),
(724, 'Б) терроризмге қарсы комиссия', 0, 184, NULL, NULL),
(725, 'В) терроризмге қарсы штаб', 0, 184, NULL, NULL),
(726, 'Г) барлық жауап дұрыс', 0, 184, NULL, NULL),
(727, 'А) 16 жастан;', 0, 185, NULL, NULL),
(728, 'Б) 14 жастан;', 1, 185, NULL, NULL),
(729, 'В) 18 жастан;', 0, 185, NULL, NULL),
(730, 'Г) барлық жауап дұрыс', 0, 185, NULL, NULL),
(731, 'А) қауіпсіз қалыпты қабылдаңыз', 0, 186, NULL, NULL),
(732, 'Б) бөлмеден шығыңыз', 0, 186, NULL, NULL),
(733, 'В) өзіңді тексер', 0, 186, NULL, NULL),
(734, 'Г) барлық жауап дұрыс', 1, 186, NULL, NULL),
(735, 'А) қауіпсіз қалыпты қабылдау басыңызды қолыңызбен жауып еденге жату', 1, 187, NULL, NULL),
(736, 'Б) бөлмеден қалуға тырысу', 0, 187, NULL, NULL),
(737, 'В) жедел штабтың қызметкерлеріне жүгіру', 0, 187, NULL, NULL),
(738, 'Г) барлық жауап дұрыс', 0, 187, NULL, NULL),
(739, 'А) сауда алаңы 400 шаршы метрден асатын сауда орындары, 100 немесе одан көп орындық тамақтану орындары; концерт залдары, спорт, ойын-сауық, көлік және басқа да қоғамдық нысандар, білім беру және денсаулық сақтау ұйымдары, туристік тұрақ, соның ішінде көршілес ашық аумақ, адамдардың жаппай болуына арналған немесе бір уақытта 200 немесе одан да көп адамды табу мүмкіндігі бар адамдар үшін дайындалған;', 0, 188, NULL, NULL),
(740, 'Б) сауда алаңы 500 шаршы метрден асатын сауда орындары, 150 немесе одан көп орындық тамақтану орындары; концерт залдары, спорт, ойын-сауық, көлік және басқа да қоғамдық нысандар, білім беру және денсаулық сақтау ұйымдары, туристік тұрақ, соның ішінде көршілес ашық аумақ, адамдардың жаппай болуына арналған немесе бір уақытта 200 немесе одан да көп адамды табу мүмкіндігі бар адамдар үшін дайындалған;', 0, 188, NULL, NULL),
(741, 'В) сауда алаңы 500 шаршы метрден асатын сауда орындары, 100 немесе одан көп орындық тамақтану орындары; концерт залдары, спорт, ойын-сауық, көлік және басқа да қоғамдық нысандар, білім беру және денсаулық сақтау ұйымдары, туристік тұрақ, соның ішінде көршілес ашық аумақ, адамдардың жаппай болуына арналған немесе бір уақытта 200 немесе одан да көп адамды табу мүмкіндігі бар адамдар үшін дайындалған;', 1, 188, NULL, NULL),
(742, 'Г) барлық жауап дұрыс', 0, 188, NULL, NULL),
(743, 'А) Күш көрсету арқылы мемелекеттік ұжымдарды шешім қабылдауға мәжбүрлеу, немесе халықаралық мекемелерді бопсалау арқылы шешім қабылдауға және өзге де қылмыстық жолмен қоғамда үрей тудыру арқылы өз мақсатын жүзеге асыруды талап ету, сондай - ақ жеке тұлға, қоғам мүшелері, мемлекетке нұқсан келтіру идеологиясын ұстану арқылы бопсалау, мәжбүрлеу, талап қою. ', 0, 189, NULL, NULL),
(744, 'Б) Лаңкестік жасау немесе жасалу қаупін тудыру, өрт қою және адамдардың өміріне қауіп төндіру, зиян келтіру сондай - ақ дүние - мүлкіне нұқсан келтіру, өзге де қоғамға зияны тиетін іс- әрекеттер жасау ', 0, 189, NULL, NULL),
(745, 'В) Қоғамдық жүйенің теориясы мен көзқарас ұстанымдарына сай лаңкестік әдіс амалдарды қолдану арқылы саяси, діни, идеологиялық жүйеге өзгерістер енгізу және өзге де мақсаттарды жүзеге асыру ', 1, 189, NULL, NULL),
(746, 'Г) Барлық жауап дұрыс ', 0, 189, NULL, NULL),
(747, 'А) терроризм актісінің нақты мүмкіндігінің расталуын талап ететін ақпарат болған кезде;', 0, 190, NULL, NULL),
(748, 'Б) терроризм актісін жасаудың нақты мүмкіндігі туралы расталған ақпарат болған кезде;', 0, 190, NULL, NULL),
(749, 'В) жасалған терроризм актісі туралы мәліметтер болса, сондай-ақ жасалған терроризм актісі туралы мәліметтер болса, сондай-ақ терроризмнің екінші актісінің (актілерінің) жасалу ықтималдығы туралы немесе терроризмдік тұрғыдан осал нысандарға бір уақытта террористік шабуыл жасау туралыа расталған мәліметтер болған кезде.', 1, 190, NULL, NULL),
(750, 'Г) барлық жауап дұрыс', 0, 190, NULL, NULL),
(751, 'А) ұлттық қауіпсіздік органдарына дереу хабарлау;', 1, 191, NULL, NULL),
(752, 'Б) дереу прокуратура органдарына хабарлаңыз; ', 0, 191, NULL, NULL),
(753, 'В); дереу ұлттық ұланға хабарлаңыз;', 0, 191, NULL, NULL),
(754, 'Г) барлық жауап дұрыс', 0, 191, NULL, NULL),
(755, 'А) қажетті қаржыландыруды қамтамасыз ету', 1, 192, NULL, NULL),
(756, 'Б) Қаржы министрлігіне сұраныс жіберу', 0, 192, NULL, NULL),
(757, 'В) кейінге қалдыру', 0, 192, NULL, NULL),
(758, 'Г) барлық жауап дұрыс', 0, 192, NULL, NULL),
(759, 'А) 13 маусым 1999 ж;', 0, 193, NULL, NULL),
(760, 'Б) 13 шілде 1998 ж;', 0, 193, NULL, NULL),
(761, 'В) 13 шілде 1999 ж;', 1, 193, NULL, NULL),
(762, 'Г) 13 шілде 1997 ж', 0, 193, NULL, NULL),
(763, 'А) Жоғары «қызғылт сары»', 1, 194, NULL, NULL),
(764, 'Б) Орташа «қызғылт сары»', 0, 194, NULL, NULL),
(765, 'В) Сыни «қызғылт сары»', 0, 194, NULL, NULL),
(766, 'Г) барлық жауап дұрыс', 0, 194, NULL, NULL),
(767, 'А) Стратегиялық нысандар', 1, 195, NULL, NULL),
(768, 'Б) Аса маңызды мемлекеттік нысандар', 0, 195, NULL, NULL),
(769, 'В) Қауіпті өндірістік нысандар', 0, 195, NULL, NULL),
(770, 'Г) барлық жауап дұрыс', 0, 195, NULL, NULL),
(771, 'А) орталық мемлекеттік органдардың және жергілікті билік органдарының аумақтық бөлімшелерінің қызметін үйлестіреді', 1, 196, NULL, NULL),
(772, 'Б) терроризм актілерін, террористік қауіптерді жою мәселелерімен айналысады', 0, 196, NULL, NULL),
(773, 'В) террористік тұрғыдан осал нысандардың терроризмге қарсы қорғалуының жай-күйін тексереді', 0, 196, NULL, NULL),
(774, 'Г) барлық жауап дұрыс', 0, 196, NULL, NULL),
(775, 'А) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 148-бабы.', 1, 197, NULL, NULL),
(776, 'Б) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 149 -бабы.', 0, 197, NULL, NULL),
(777, 'В) «Әкімшілік құқық бұзушылық туралы» ҚР 2014 жылғы 5 шілдедегі № 235-V ЗРК Кодексінің 147 -бабы.', 0, 197, NULL, NULL),
(778, 'Г) барлық жауап дұрыс', 0, 197, NULL, NULL),
(779, 'А) терроризм актісінің шынайы мүмкіндігін растауды қажет ететін ақпарат болған кезде;', 1, 198, NULL, NULL),
(780, 'Б) егер терроризм актісінің нақты мүмкіндігі туралы расталған ақпарат болса', 0, 198, NULL, NULL),
(781, 'В) егер терроризм актісі туралы ақпарат болса, сондай-ақ терроризмнің екінші актісі (актілері) болуы немесе терроризмге осал объектілерге бір мезгілде террористік шабуыл жасалуы мүмкін екендігі туралы расталған ақпарат болған жағдайда;', 0, 198, NULL, NULL),
(782, 'Г) барлық жауап дұрыс', 0, 198, NULL, NULL),
(783, 'А) балалардан далаға шығармау ', 1, 199, NULL, NULL),
(784, 'Б) эвакуацияға дайын болыңыз, теледидар, радио, телефон қосулы ұстаңыз', 0, 199, NULL, NULL),
(785, 'В) террористік қауіпті аймақтарға бармаңыз', 0, 199, NULL, NULL),
(786, 'Г) барлық жауап дұрыс', 0, 199, NULL, NULL),
(787, 'А) егер сіз террористерге жақын болсаңыз, есте сақтауға тырысыңыз', 0, 200, NULL, NULL),
(788, 'Б) қазіргі жағдай туралы жаңалықтарды қараңыз', 0, 200, NULL, NULL),
(789, 'В) жүкпен қозғалмаңыз', 1, 200, NULL, NULL),
(790, 'Г) барлық жауап дұрыс', 0, 200, NULL, NULL),
(791, 'А) қоңырау шалушы идентификаторын және дыбыстық жазғышты орнатыңыз', 0, 201, NULL, NULL),
(792, 'Б) ІІБ және ТЖ хабарлау', 0, 201, NULL, NULL),
(793, 'В) ІІБ рұқсат еткен болса, жұмысты жалғастырыңыз', 0, 201, NULL, NULL),
(794, 'Г) барлық жауап дұрыс', 1, 201, NULL, NULL),
(795, 'А) прикасаться, вскрывать, заливать водой', 1, 202, NULL, NULL),
(796, 'Б) не оставлять без присмотра, звать людей на помощь;', 0, 202, NULL, NULL),
(797, 'В) пользоваться телефоном, сообщать в правоохранительные органы.', 0, 202, NULL, NULL),
(798, 'Г) Все варианты', 0, 202, NULL, NULL),
(799, 'А) штрафа на физических или должностных лиц в размере ста, на субъектов малого предпринимательства или некоммерческие организации - в размере двухсот, на субъектов среднего предпринимательства - в размере трехсот, на субъектов крупного предпринимательства – в размере пятисот месячных расчетных показателей.', 1, 203, NULL, NULL),
(800, 'Б) штрафа в размере до пяти тысяч месячных расчетных показателей либо исправительными работами в том же размере, либо ограничением свободы на срок до пяти лет, либо лишением свободы на тот же срок.', 0, 203, NULL, NULL),
(801, 'В) штрафа в размере до ста двадцати месячных расчетных показателей либо исправительными работами в том же размере, либо привлечением к общественным работам на срок до ста двадцати часов, либо арестом на срок до тридцати суток.', 0, 203, NULL, NULL),
(802, 'Г) Все варианты', 0, 203, NULL, NULL),
(803, 'А) Звонок на атс для определения номера;', 0, 204, NULL, NULL),
(804, 'Б) Зафиксировать время разговора и продолжительность.', 0, 204, NULL, NULL),
(805, 'В) Записать разговор;', 0, 204, NULL, NULL),
(806, 'Г) все варианты', 1, 204, NULL, NULL),
(807, 'А) «одной тысячи месячных расчетных показателей либо исправительными работами в том же размере, либо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок до одного года, либо лишением свободы на тот же срок»;', 1, 205, NULL, NULL),
(808, 'Б) «одной тысячи месячных расчетных показателей либо исправительными работами в том же размере, либо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок до трех лет, либо лишением свободы на тот же срок»;', 0, 205, NULL, NULL),
(809, 'В) «одной тысячи месячных расчетных показателей либо исправительными работами в том же размере, либо привлечением к общественным работам на срок до четырехсот часов, либо ограничением свободы на срок до двух лет, либо лишением свободы на тот же срок»;', 0, 205, NULL, NULL),
(810, 'Г) Все варианты', 0, 205, NULL, NULL),
(811, 'А) 112;', 0, 206, NULL, NULL),
(812, 'Б) 110;', 1, 206, NULL, NULL),
(813, 'В 111;', 0, 206, NULL, NULL),
(814, 'Г) Все варианты', 0, 206, NULL, NULL),
(815, 'А) Характер происшествия (ДТП, пожар, акт терроризма и т.д.);', 0, 207, NULL, NULL),
(816, 'Б) Место происшествия с обязательным указанием точного адреса.', 0, 207, NULL, NULL),
(817, 'В) Количество пострадавших, особенно важно есть ли среди них дети;', 0, 207, NULL, NULL),
(818, 'Г) все варианты', 1, 207, NULL, NULL),
(819, 'А) умеренный («зеленый»);', 0, 208, NULL, NULL),
(820, 'Б) средний («оранжевый»).', 0, 208, NULL, NULL),
(821, 'В) критический («красный»);', 1, 208, NULL, NULL),
(822, 'Г) все варианты', 0, 208, NULL, NULL),
(823, 'А) умеренный («зеленый»);', 0, 209, NULL, NULL),
(824, 'Б) умеренный («желтый»);', 1, 209, NULL, NULL),
(825, 'В) средний («оранжевый»);', 0, 209, NULL, NULL),
(826, 'Г) Все варианты', 0, 209, NULL, NULL),
(827, 'А) от 24 июня 2014 года № 589;', 0, 210, NULL, NULL),
(828, 'Б) от 24 июня 2015 года № 589;', 0, 210, NULL, NULL),
(829, 'В) от 24 июня 2013 года № 589;', 1, 210, NULL, NULL),
(830, 'Г) Все варианты', 0, 210, NULL, NULL),
(831, 'А) от 8 июля 2016 года;', 0, 211, NULL, NULL),
(832, 'Б) от 8 июня 2015 года;', 0, 211, NULL, NULL),
(833, 'В) от 8 июля 2015 года;', 1, 211, NULL, NULL),
(834, 'Г) Все варианты', 0, 211, NULL, NULL),
(835, 'А) Об утверждении антитеррористического паспорта антитеррористической защищенности объектов, уязвимых в террористическом отношении;', 0, 212, NULL, NULL),
(836, 'Б) Об утверждении типового паспорта антитеррористической защищенности объектов, уязвимых в антитеррористическом отношении;', 0, 212, NULL, NULL),
(837, 'В) Об утверждении типового паспорта антитеррористической защищенности объектов, уязвимых в террористическом отношении;', 1, 212, NULL, NULL),
(838, 'Г) Все варианты', 0, 212, NULL, NULL),
(839, 'А) при наличии подтвержденной информации о реальной возможности совершения акта (актов) терроризма;', 1, 213, NULL, NULL),
(840, 'Б) при наличии требующей подтверждения информации о реальной возможности совершения акта (актов) терроризма;', 0, 213, NULL, NULL),
(841, 'В) при наличии информации о совершенном акте терроризма, а также подтвержденной информации о возможном совершении повторного акта (актов) терроризма или одновременных террористических атак на объекты, уязвимые в террористическом отношении;', 0, 213, NULL, NULL),
(842, 'Г) Все варианты', 0, 213, NULL, NULL),
(843, 'А) лишением свободы на срок от 6 до 9 лет с конфискацией имущества;', 0, 214, NULL, NULL),
(844, 'Б) лишением свободы на срок от 5 до 9 лет с конфискацией имущества;', 1, 214, NULL, NULL),
(845, 'В) лишением свободы на срок от 5 до 8 лет с конфискацией имущества;', 0, 214, NULL, NULL),
(846, 'Г) Все варианты', 0, 214, NULL, NULL),
(847, 'А) идеология насилия;', 1, 215, NULL, NULL),
(848, 'Б) терроризм;', 0, 215, NULL, NULL),
(849, 'В) акт терроризма;', 0, 215, NULL, NULL),
(850, 'Г) Все варианты', 0, 215, NULL, NULL),
(851, 'А) от 13 июня 1999 года;', 0, 216, NULL, NULL),
(852, 'Б) от 13 июля 1998 года;', 0, 216, NULL, NULL),
(853, 'В) от 13 июля 1999 года;', 1, 216, NULL, NULL),
(854, 'Г) Все варианты', 0, 216, NULL, NULL),
(855, 'А) договориться с террористами об освобождении заложников;', 0, 217, NULL, NULL),
(856, 'Б) напасть и обезоружить террористов;', 0, 217, NULL, NULL),
(857, 'В) выполнять все требования беспрекословно.', 1, 217, NULL, NULL),
(858, 'Г) Все варианты', 0, 217, NULL, NULL),
(859, 'А) проведению профилактических и учебных мероприятий по обучению персонала технике осмотра помещений, выявлению возможных мест закладки взрывных устройств;', 0, 218, NULL, NULL),
(860, 'Б) планированию и отработке совместных действий с заинтересованными государственными органами и организациями по ликвидации угроз техногенного характера, возникших в результате совершенного акта терроризма;', 0, 218, NULL, NULL),
(861, 'В) разработке на основе типового паспорта – паспорта антитеррористической защищенности вверенных им объектов.', 0, 218, NULL, NULL),
(862, 'Г) Все варианты', 1, 218, NULL, NULL),
(863, 'А) В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта терроризма руководство антитеррористической операцией осуществляет руководитель республиканского или областного оперативного штаба;', 0, 219, NULL, NULL),
(864, 'Б) В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта терроризма руководство антитеррористической операцией осуществляет заместитель руководителя республиканского или областного, города республиканского значения, столицы, района и морского оперативного штаба;', 0, 219, NULL, NULL),
(865, 'В) В зависимости от масштабов и степени общественной опасности, ожидаемых негативных последствий акта терроризма руководство антитеррористической операцией осуществляет руководитель республиканского или областного, города республиканского значения, столицы, района и морского оперативного штаба.', 1, 219, NULL, NULL),
(866, 'Г) Все варианты', 0, 219, NULL, NULL),
(867, 'А) «Об утверждении перечня организаций РК, уязвимых в террористическом отношении»;', 0, 220, NULL, NULL),
(868, 'Б) «Об утверждении перечня объектов РК, уязвимых в антитеррористическом отношении»;', 0, 220, NULL, NULL),
(869, 'В) «Об утверждении перечня объектов РК, уязвимых в террористическом отношении»;', 1, 220, NULL, NULL),
(870, 'Г) Все варианты', 0, 220, NULL, NULL),
(871, 'А) при наличии информации о совершенном акте терроризма, а также подтвержденной информации о возможном совершении повторного акта (актов) терроризма или одновременных террористических атак на объекты, уязвимые в террористическом отношении;', 0, 221, NULL, NULL),
(872, 'Б) при наличии требующей подтверждения информации о реальной возможности совершения акта терроризма;', 1, 221, NULL, NULL),
(873, 'В) при наличии подтвержденной информации о реальной возможности совершения акта терроризма;', 0, 221, NULL, NULL),
(874, 'Г) Все варианты', 0, 221, NULL, NULL),
(875, 'А) Статья 148 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 0, 222, NULL, NULL),
(876, 'Б) Статья 149 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 1, 222, NULL, NULL),
(877, 'В) Статья 147 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 0, 222, NULL, NULL),
(878, 'Г) Все варианты', 0, 222, NULL, NULL),
(879, 'А) Сотрудники полиции;', 1, 223, NULL, NULL),
(880, 'Б) Сотрудники прокуратуры;', 0, 223, NULL, NULL),
(881, 'В) Сотрудники миграционной полиции;', 0, 223, NULL, NULL),
(882, 'Г) Все варианты', 0, 223, NULL, NULL),
(883, 'А) Административные здания и объекты центральных исполнительных государственных органов, специальных, правоохранительных органов, их структурных и территориальных подразделений, местных представительных и исполнительных органов;', 1, 224, NULL, NULL),
(884, 'Б) Объекты, охраняемые СГО РК совместно с подразделениями ОВД, включенные в перечень, утверждаемый Президентом РК, а также объекты, имеющие важное государственное значение;', 0, 224, NULL, NULL),
(885, 'В) Объекты государственных организаций и учреждений по разработке, производству, испытанию, исследованию и хранению особо опасных, бактериологических, биологических, химических, наркотических средств и прекурсоров;', 0, 224, NULL, NULL),
(886, 'Г) Все варианты', 0, 224, NULL, NULL),
(887, 'А) Стратегические объекты;', 0, 225, NULL, NULL),
(888, 'Б) Опасные производственные объекты;', 1, 225, NULL, NULL),
(889, 'В) Особо важные государственные объекты;', 0, 225, NULL, NULL),
(890, 'Г) Все варианты', 0, 225, NULL, NULL),
(891, 'А) Об утверждении Правил организации и функционирования государственной системы мониторинга информации и оповещения населения о возникновении угрозы акта терроризма;', 1, 226, NULL, NULL),
(892, 'Б) Об утверждении требований к системе антитеррористической защиты объектов, уязвимых в террористическом отношении;', 0, 226, NULL, NULL),
(893, 'В) Об утверждении перечня объектов РК, уязвимых в террористическом отношении;', 0, 226, NULL, NULL),
(894, 'Г) Все варианты', 0, 226, NULL, NULL),
(895, 'А) оперативный штаб по борьбе с терроризмом;', 1, 227, NULL, NULL),
(896, 'Б) антитеррористическая комиссия по борьбе с терроризмом;', 0, 227, NULL, NULL),
(897, 'В) антитеррористический штаб по борьбе с терроризмом;', 0, 227, NULL, NULL),
(898, 'Г) все варианты', 0, 227, NULL, NULL),
(899, 'А) с 16 лет;', 0, 228, NULL, NULL),
(900, 'Б) с 14 лет;', 1, 228, NULL, NULL),
(901, 'В) с 18 лет;', 0, 228, NULL, NULL),
(902, 'Г) все варианты', 0, 228, NULL, NULL),
(903, 'А) занять безопасное положение;', 0, 229, NULL, NULL),
(904, 'Б) покинуть помещение;', 0, 229, NULL, NULL),
(905, 'В) осмотреть себя;', 0, 229, NULL, NULL),
(906, 'Г) все варианты', 1, 229, NULL, NULL),
(907, 'А) принять безопасное положение лечь на пол прикрыв голову руками;', 1, 230, NULL, NULL),
(908, 'Б) стараться покинуть помещение;', 0, 230, NULL, NULL),
(909, 'В) бежать к сотрудникам оперативного штаба;', 0, 230, NULL, NULL),
(910, 'Г) все варианты', 0, 230, NULL, NULL),
(911, 'А) торговые объекты торговой площадью от 400 квадратных метров и более, объекты общественного питания на 100 и более посадочных мест; концертные залы, спортивные, развлекательные, транспортные и иные публичные сооружения, организации образования и здравоохранения, места размещения туристов, включая прилегающую к ним открытую территорию, предназначенные или подготовленные для массового пребывания людей с возможностью одновременного нахождения 200 и более человек;', 0, 231, NULL, NULL),
(912, 'Б) торговые объекты торговой площадью от 500 квадратных метров и более, объекты общественного питания на 150 и более посадочных мест; концертные залы, спортивные, развлекательные, транспортные и иные публичные сооружения, организации образования и здравоохранения, места размещения туристов, включая прилегающую к ним открытую территорию, предназначенные или подготовленные для массового пребывания людей с возможностью одновременного нахождения 200 и более человек;', 0, 231, NULL, NULL),
(913, 'В) торговые объекты торговой площадью от 500 квадратных метров и более, объекты общественного питания на 100 и более посадочных мест; концертные залы, спортивные, развлекательные, транспортные и иные публичные сооружения, организации образования и здравоохранения, места размещения туристов, включая прилегающую к ним открытую территорию, предназначенные или подготовленные для массового пребывания людей с возможностью одновременного нахождения 200 и более человек;', 1, 231, NULL, NULL),
(914, 'Г) все варианты', 0, 231, NULL, NULL),
(915, 'А) идеология насилия и практика воздействия на принятие решения государственными органами, органами местного самоуправления или международными организациями путем совершения либо угрозы совершения насильственных и иных преступных действий;', 0, 232, NULL, NULL),
(916, 'Б) совершение или угроза совершения взрыва, поджога или иных действий, создающих опасность гибели людей, причинения значительного имущественного ущерба либо наступления иных общественно опасных последствий, если эти действия совершены в целях нарушения общественной безопасности;', 0, 232, NULL, NULL),
(917, 'В) идеология насилия и практика воздействия на принятие решения государственными органами, органами местного самоуправления или международными организациями путем совершения либо угрозы совершения насильственных и (или) иных преступных действий, связанных с устрашением населения и направленных на причинение ущерба личности, обществу и государству;', 1, 232, NULL, NULL),
(918, 'Г) Все варианты ', 0, 232, NULL, NULL),
(919, 'А) при наличии требующей подтверждения информации о реальной возможности совершения акта (актов) терроризма;', 0, 233, NULL, NULL),
(920, 'Б) при наличии подтвержденной информации о реальной возможности совершения акта (актов) терроризма;', 0, 233, NULL, NULL),
(921, 'В) при наличии информации о совершенном акте терроризма, а также подтвержденной информации о возможном совершении повторного акта (актов) терроризма или одновременных террористических атак на объекты, уязвимые в террористическом отношении.', 1, 233, NULL, NULL),
(922, 'Г) Все варианты', 0, 233, NULL, NULL),
(923, 'А) «Особо важные государственные объекты»;', 0, 234, NULL, NULL),
(924, 'Б) «Стратегические объекты»;', 0, 234, NULL, NULL),
(925, 'В) «Опасные производственные объекты»;', 0, 234, NULL, NULL),
(926, 'Г) Все варианты', 1, 234, NULL, NULL),
(927, 'А) «Воинские части ВС РК, других войск и воинских формирований»;', 1, 235, NULL, NULL),
(928, 'Б) «Объекты массового скопления людей»;', 0, 235, NULL, NULL),
(929, 'В) «Объекты, охраняемые МВД Р, включенные в перечень, утверждаемый Парламентом РК, а также объекты, имеющие важное национальное значение»;', 0, 235, NULL, NULL),
(930, 'Г) Все варианты', 0, 235, NULL, NULL),
(931, 'А) незамедлительно информировать органы национальной безопасности;', 1, 236, NULL, NULL),
(932, 'Б) незамедлительно информировать органы прокуратуры;', 0, 236, NULL, NULL),
(933, 'В) незамедлительно информировать органы национальной гвардии;', 0, 236, NULL, NULL),
(934, 'Г) Все варианты', 0, 236, NULL, NULL),
(935, 'А) предусматривать необходимое финансирование;', 1, 237, NULL, NULL),
(936, 'Б) подавать заявку в Министерство финансов;', 0, 237, NULL, NULL),
(937, 'В) отложить на неопределенный срок;', 0, 237, NULL, NULL),
(938, 'Г) Все варианты', 0, 237, NULL, NULL),
(939, 'А) от 13 июня 1999 года;', 0, 238, NULL, NULL),
(940, 'Б) от 13 июля 1998 года;', 0, 238, NULL, NULL),
(941, 'В) от 13 июля 1999 года;', 1, 238, NULL, NULL),
(942, 'Г) Все варианты', 0, 238, NULL, NULL),
(943, 'А) Высокий («оранжевый»);', 1, 239, NULL, NULL),
(944, 'Б) Умеренный («оранжевый»);', 0, 239, NULL, NULL),
(945, 'В) Критический («оранжевый»);', 0, 239, NULL, NULL),
(946, 'Г) Все варианты', 0, 239, NULL, NULL),
(947, 'А) Стратегические объекты;', 1, 240, NULL, NULL),
(948, 'Б) Особо важные государственные объекты;', 0, 240, NULL, NULL),
(949, 'В) Опасные производственные объекты;', 0, 240, NULL, NULL),
(950, 'Г) Все варианты', 0, 240, NULL, NULL),
(951, 'А) осуществляет координацию деятельности территориальных подразделений центральных государственных органов и органов местного самоуправления;', 1, 241, NULL, NULL),
(952, 'Б) занимается ликвидацией актов терроризма, террористических угроз;', 0, 241, NULL, NULL),
(953, 'В) проверяет состояние антитеррористической защищенности объектов, УТО;', 0, 241, NULL, NULL),
(954, 'Г) Все варианты', 0, 241, NULL, NULL),
(955, 'А) Статья 149 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 1, 242, NULL, NULL),
(956, 'Б) Статья 147 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 0, 242, NULL, NULL),
(957, 'В) Статья 148 Кодекса РК «Об административных правонарушениях» от 5 июля 2014 года № 235-V ЗРК;', 0, 242, NULL, NULL),
(958, 'Г) Все варианты', 0, 242, NULL, NULL),
(959, 'А) при наличии требующей подтверждения информации о реальной возможности совершения акта терроризма;', 1, 243, NULL, NULL),
(960, 'Б) при наличии подтвержденной информации о реальной возможности совершения акта терроризма;', 0, 243, NULL, NULL),
(961, 'В) при наличии информации о совершенном акте терроризма, а также подтвержденной информации о возможном совершении повторного акта (актов) терроризма или одновременных террористических атак на объекты, уязвимые в террористическом отношении;', 0, 243, NULL, NULL),
(962, 'Г) Все варианты', 0, 243, NULL, NULL),
(963, 'А) не пускать детей на улицу;', 1, 244, NULL, NULL);
INSERT INTO `options` (`id`, `body`, `isTrue`, `question_id`, `created_at`, `updated_at`) VALUES
(964, 'Б) приготовьтесь к эвакуации, держать включенным тв, радио, телефон;', 0, 244, NULL, NULL),
(965, 'В) не посещать зоны террористической опасности;', 0, 244, NULL, NULL),
(966, 'Г) Все варианты', 0, 244, NULL, NULL),
(967, 'А) если вы оказались рядом с террористами, постарайтесь запомнить;', 0, 245, NULL, NULL),
(968, 'Б) следите за новостями о текущей обстановке;', 0, 245, NULL, NULL),
(969, 'В) не передвигаться с грузами;', 1, 245, NULL, NULL),
(970, 'Г) Все варианты', 0, 245, NULL, NULL),
(971, 'А) установить определитель номера и диктофон;', 0, 246, NULL, NULL),
(972, 'Б) проинформируйте ОВД и ЧС о ситуации;', 0, 246, NULL, NULL),
(973, 'В) продолжайте работать, если разрешено ОВД;', 0, 246, NULL, NULL),
(974, 'Г) Все варианты', 1, 246, NULL, NULL),
(975, '1) Жылына бір рет', 0, 247, NULL, NULL),
(976, '2) Жылына екі рет', 1, 247, NULL, NULL),
(977, '3) Жылына үш рет', 0, 247, NULL, NULL),
(978, '4) Екі жылда бір рет', 0, 247, NULL, NULL),
(979, '1) Жұмыскердің жұмыс орнында жүрегі тоқтап қалса', 0, 248, NULL, NULL),
(980, '2) Жұмысшы демалыс күні кәсіпорындағы өртті сөндіру кезінде күйіп қалса', 1, 248, NULL, NULL),
(981, '3) Жұмыстан бос уақытында кәсіпорын аумағындағы асханада қызметкер уланған кезде', 0, 248, NULL, NULL),
(982, '4) Тернер (Токарь) жұмыс орнындағы үзіліс кезінде жеке қажеттіліктерге арналған бөлігін жасау барысында жарақат алған кезде', 0, 248, NULL, NULL),
(983, '1) Кіріспе', 1, 249, NULL, NULL),
(984, '2) Жоспардан тыс', 0, 249, NULL, NULL),
(985, '3) Жұмыс орнында жоспардан тыс', 0, 249, NULL, NULL),
(986, '4) Мақсаты', 0, 249, NULL, NULL),
(987, '1) 3 күнге дейін', 0, 250, NULL, NULL),
(988, '2) 5 күнге дейін', 0, 250, NULL, NULL),
(989, '3) 10 күнге дейін', 1, 250, NULL, NULL),
(990, '4) 15 күнге дейін', 0, 250, NULL, NULL),
(991, '1) Өртті жою кезінде уақытша еңбекке жарамсыз болып қалу', 0, 251, NULL, NULL),
(992, '2) Алкоголь немесе есірткімен улану кезінде', 0, 251, NULL, NULL),
(993, '3) Қызметтк міндеттемелерді орындау барысында жоғалған кезде', 0, 251, NULL, NULL),
(994, '4) Өндірісте топтық жазатайым оқиғалар', 1, 251, NULL, NULL),
(995, '1) Жәбірленушінің жоғалтқан табысының 50%-ы', 0, 252, NULL, NULL),
(996, '2) Жәбірленушінің жоғалтқан табысының 100%-ы', 0, 252, NULL, NULL),
(997, '3) Жұмысқа жарамсыз кезеңіндегі жәбірленушінің орташа айлық жалақысы', 1, 252, NULL, NULL),
(998, '4) Кәсіпорын жұмыскерлерінің еңбекке жарамсыз кезеңіндегі орташа айлық жалақысы', 0, 252, NULL, NULL),
(999, '1) Қайтыс болған отбасына екі жүз орташа айлық жалақы және әр асыраушыға екі жүз ең төменгі жалақы', 0, 253, NULL, NULL),
(1000, '2) Отбасына қайтыс болған адамның екі жылдық табысы және жаздық табыс әйелге', 0, 253, NULL, NULL),
(1001, '3) Отбасына қайтыс болған адамның бес жылдық жалақысы және әрбір асыраушыға жаздық табыс', 1, 253, NULL, NULL),
(1002, '4) Әйелге және барлық асырауындағыларға қызметкерлердің орташа жылдық жалақысы ', 0, 253, NULL, NULL),
(1003, '1) Жұмыс орнын жақсартуға бағытталған шаралар жүйесі', 0, 254, NULL, NULL),
(1004, '2) Емдік шаралар жүйесі', 0, 254, NULL, NULL),
(1005, '3) Зиянды өндірістік факторлардың әсерін болдырмайтын немесе төмендететін ұйымдастырушылық шаралар мен техникалық құралдар жүйесі', 1, 254, NULL, NULL),
(1006, '4) Ықтимал аурулардың немесе уланудың алдын-алу үшін әр қызметкер жүргізуге тиісті жеке шаралар кешені', 0, 254, NULL, NULL),
(1007, '1) Температура', 0, 255, NULL, NULL),
(1008, '2) Ылғалдылық', 0, 255, NULL, NULL),
(1009, '3) Ауа қозғалысының жылдамдығы', 0, 255, NULL, NULL),
(1010, '4) барлық жауап дұрыс', 1, 255, NULL, NULL),
(1011, '1) Сынап термометрі', 0, 256, NULL, NULL),
(1012, '2) Спирттік термометрі', 0, 256, NULL, NULL),
(1013, '3) Бу термометрі', 1, 256, NULL, NULL),
(1014, '4) Термограф', 0, 256, NULL, NULL),
(1015, '1) Градуспен', 0, 257, NULL, NULL),
(1016, '2) Мг/м куб', 0, 257, NULL, NULL),
(1017, '3) Мг/л', 0, 257, NULL, NULL),
(1018, '4) Пайызбен', 1, 257, NULL, NULL),
(1019, '1) жұмыс істейтін бөлме', 0, 258, NULL, NULL),
(1020, '2) Жыл мезгілі', 0, 258, NULL, NULL),
(1021, '3) Жұмыс санаты', 1, 258, NULL, NULL),
(1022, '4) Ауаның ылғалдылығы', 0, 258, NULL, NULL),
(1023, '1) Психрометр маркасы', 0, 259, NULL, NULL),
(1024, '2) Циферблат көрсеткіштері', 0, 259, NULL, NULL),
(1025, '3) Шкала көрсеткіштері', 0, 259, NULL, NULL),
(1026, '4) Екі термометрдің температура айырмашылығы', 1, 259, NULL, NULL),
(1027, '1) Оңтайлы', 1, 260, NULL, NULL),
(1028, '2) Жарамды', 0, 260, NULL, NULL),
(1029, '3) Максималды', 0, 260, NULL, NULL),
(1030, '4) Минималды', 0, 260, NULL, NULL),
(1031, '1) 2', 0, 261, NULL, NULL),
(1032, '2) 3', 0, 261, NULL, NULL),
(1033, '3) 4', 1, 261, NULL, NULL),
(1034, '4) 5', 0, 261, NULL, NULL),
(1035, '1) Орташа өлім дозасы бойынша', 0, 262, NULL, NULL),
(1036, '2) Орташа өлім концентрациясы бойынша', 0, 262, NULL, NULL),
(1037, '3) Адам ағзасына әсер ету сипаты бойынша', 0, 262, NULL, NULL),
(1038, '4) Шекті концентрация бойынша', 1, 262, NULL, NULL),
(1039, '1) Ең үлкен қауіп', 0, 263, NULL, NULL),
(1040, '2) Өлімнің орташа мөлшері', 0, 263, NULL, NULL),
(1041, '3) Өлімнің орташа концентрациясы', 0, 263, NULL, NULL),
(1042, '4) Шекті концентрация', 1, 263, NULL, NULL),
(1043, '1) Шөгінділер', 0, 264, NULL, NULL),
(1044, '2) Сүзу', 0, 264, NULL, NULL),
(1045, '3) Химиялық әрекеттесу', 1, 264, NULL, NULL),
(1046, '4) Булану', 0, 264, NULL, NULL),
(1047, '1) М куб/сағ', 0, 265, NULL, NULL),
(1048, '2) Г', 0, 265, NULL, NULL),
(1049, '3) Мг/м куб', 1, 265, NULL, NULL),
(1050, '4) М куб', 0, 265, NULL, NULL),
(1051, '1) ШРЕК 0,05 – 0,1 мг / м куб', 0, 266, NULL, NULL),
(1052, '2) ШРЕК 0,1 – 1,0 мг / м куб', 1, 266, NULL, NULL),
(1053, '3) ШРЕК 7 – 10 мг / м куб', 0, 266, NULL, NULL),
(1054, '4) ШРЕК 1,0 – 5 мг / м куб', 0, 266, NULL, NULL),
(1055, '1) Фиброгенді', 0, 267, NULL, NULL),
(1056, '2) Тітіркендіргіш', 0, 267, NULL, NULL),
(1057, '3) Уытты', 0, 267, NULL, NULL),
(1058, '4) барлық жауап дұрыс', 1, 267, NULL, NULL),
(1059, '1) Жануарлы', 0, 268, NULL, NULL),
(1060, '2) Өсімді', 0, 268, NULL, NULL),
(1061, '3) Ақуызды', 1, 268, NULL, NULL),
(1062, '4) Минералды', 0, 268, NULL, NULL),
(1063, '1) Vt = V * m / 1000', 0, 269, NULL, NULL),
(1064, '2) Vо = [Vt * (273 +20) * Рt] / (273 + t) * 760', 1, 269, NULL, NULL),
(1065, '3) V = S * h', 0, 269, NULL, NULL),
(1066, '4) Q = m / V', 0, 269, NULL, NULL),
(1067, '1) Дәке таңғыштары', 0, 270, NULL, NULL),
(1068, '2) Газ маскалары', 1, 270, NULL, NULL),
(1069, '3) Арнайы киімдер', 0, 270, NULL, NULL),
(1070, '4) Қорғаныс көзілдірігі', 0, 270, NULL, NULL),
(1071, '1) Жарықтандырылған беттегі сәулелендірілген ағынның тығыздығы', 1, 271, NULL, NULL),
(1072, '2) Бетте жарықтың таралуы', 0, 271, NULL, NULL),
(1073, '3) Жарық күшінің перпендикулярлық аймаққа қатынасы', 0, 271, NULL, NULL),
(1074, '4) Сәулеленудің жарық күші', 0, 271, NULL, NULL),
(1075, '1) Ватт', 0, 272, NULL, NULL),
(1076, '2) Вольт', 0, 272, NULL, NULL),
(1077, '3) Люкс', 1, 272, NULL, NULL),
(1078, '4) Люмен', 0, 272, NULL, NULL),
(1079, '1) Сүзгілерді сіңіру', 0, 273, NULL, NULL),
(1080, '2) Фотоэлемент', 0, 273, NULL, NULL),
(1081, '3) Гальванометр', 0, 273, NULL, NULL),
(1082, '4) барлық жауап дұрыс', 1, 273, NULL, NULL),
(1083, '1) Шуды азайту', 0, 274, NULL, NULL),
(1084, '2) Ауаның тазалығын қамтамасыз ету', 0, 274, NULL, NULL),
(1085, '3) Қалыпты микроклиматтық жағдайларды қамтамасыз ету', 1, 274, NULL, NULL),
(1086, '4) Жарылыс қауіпсіздігін қамтамасыз ету', 0, 274, NULL, NULL),
(1087, '1) Бөлменің көлемі', 0, 275, NULL, NULL),
(1088, '2) Бір жұмысшыға ауа шығыны', 1, 275, NULL, NULL),
(1089, '3) Ауаның айырбас бағамы', 0, 275, NULL, NULL),
(1090, '4) 2 жұмыс үшін ауа шығыны', 0, 275, NULL, NULL),
(1091, '1) Тиімділігі бойынша', 0, 276, NULL, NULL),
(1092, '2) Шығарылған шу бойынша', 0, 276, NULL, NULL),
(1093, '3) Газдың ластануы бойынша', 0, 276, NULL, NULL),
(1094, '4) Желдеткіш жасаған жалпы қысым бойынша', 0, 276, NULL, NULL),
(1095, '1) 3', 0, 277, NULL, NULL),
(1096, '2) 5', 0, 277, NULL, NULL),
(1097, '3) 9', 0, 277, NULL, NULL),
(1098, '4) 21', 0, 277, NULL, NULL),
(1099, '1) Дыбыс деңгейімен', 0, 278, NULL, NULL),
(1100, '2) Қабылдау ауқымымен', 0, 278, NULL, NULL),
(1101, '3) Адам ағзасына зиянды әсерімен', 0, 278, NULL, NULL),
(1102, '4) Дыбыс қарқындылығымен', 0, 278, NULL, NULL),
(1103, '1) 3', 0, 279, NULL, NULL),
(1104, '2) 3,5', 0, 279, NULL, NULL),
(1105, '3) 4', 0, 279, NULL, NULL),
(1106, '4) 4,5', 0, 279, NULL, NULL),
(1107, '1) Кәсіпорын басшысы', 0, 280, NULL, NULL),
(1108, '2) Құрылымдық бөлімшелердің инженерлік-техникалық қызметкері', 0, 280, NULL, NULL),
(1109, '3) Барлық инженерлік-техникалық қызметкерлер', 0, 280, NULL, NULL),
(1110, '4) барлық жауап дұрыс', 0, 280, NULL, NULL),
(1111, '1) Дененің функционалдық жағдайында белгілі бір өзгерістер туғызатын және жаңа ауысым басталғанға дейін қалпына келетін заттың мұндай мөлшері', 0, 281, NULL, NULL),
(1112, '2) Денедегі патологиялық өзгерістер пайда болатын зат мөлшері', 0, 281, NULL, NULL),
(1113, '3) Өлімге әкелетін қатты улануды тудыратын зат мөлшері', 0, 281, NULL, NULL),
(1114, '4) Бұл бүкіл жұмыс тәжірибесі кезінде жарақат алуға, ауруға немесе денсаулық жағдайындағы ауытқуларға әкелмейтін деңгей', 0, 281, NULL, NULL),
(1115, '1) 100 қызметкерден тұратын ұйымдарда', 0, 282, NULL, NULL),
(1116, '2) Қызметкерлерінің саны 50 адамнан асатын, еңбек қорғау қызметі немесе еңбек қорғау маманы лауазымы құрылады', 0, 282, NULL, NULL),
(1117, '3) Әкімшіліктің қалауы бойынша', 0, 282, NULL, NULL),
(1118, '4) Қызметкерлерінің саны 100 адамнан асатын, еңбек қорғау қызметі немесе еңбек қорғау маманы лауазымы құрылады', 0, 282, NULL, NULL),
(1119, '1) біліктілігіне қарамастан қызметкердің жазбаша келісімімен', 0, 283, NULL, NULL),
(1120, '2) орындалған жұмыс үшін сыйақы төлеумен, бірақ алдыңғы жұмысынан орташа жалақысынан төмен емес, денсаулығына байланысты қарсы көрсетілімдер болмаған жағдайда күнтізбелік жыл ішінде бір айға', 0, 283, NULL, NULL),
(1121, '3) біліктілігіне қарамастан қызметкердің ауызша келісімімен', 0, 283, NULL, NULL),
(1122, '4) барлық жауап дұрыс', 0, 283, NULL, NULL),
(1123, '1) әр баспалдақ пен баспалдақ тіркелуі керек', 0, 284, NULL, NULL),
(1124, '2) баспалдақтар мен баспалдақтардың жарамдылығы айына кемінде бір рет журнал жазбасымен тексеріледі', 0, 284, NULL, NULL),
(1125, '3) сериялық нөмірі және оның аффилиирленгендігі және келесі сынақ өткізілетін күні көрсетілген тақтайша болуы керек', 0, 284, NULL, NULL),
(1126, '4) барлық жауап дұрыс', 0, 284, NULL, NULL),
(1127, '1) барлық пайдаланушы санаттары', 0, 285, NULL, NULL),
(1128, '2) Компьютермен жұмыс, соның ішінде компьютер, жұмыс уақытының 50% -дан астамы - ДК жұмысына байланысты', 0, 285, NULL, NULL),
(1129, '3) Компьютермен жұмыс, соның ішінде компьютер, жұмыс уақытының 60% -дан астамы - ДК жұмысымен байланысты', 0, 285, NULL, NULL),
(1130, '4) барлық жауап дұрыс', 0, 285, NULL, NULL),
(1131, '1) Жұмыс ортасы мен еңбек процесінің параметрлерінің қолданыстағы гигиеналық нормалардан ауытқу дәрежесін бағалауға арналған көрсеткіштер', 0, 286, NULL, NULL),
(1132, '2) еңбек жағдайының жай-күйін бағалаудың индикативті көрсеткіштері', 0, 286, NULL, NULL),
(1133, '3) алдын-ала анықталған стандартты мәндер', 0, 286, NULL, NULL),
(1134, '4) барлық жауап дұрыс', 0, 286, NULL, NULL),
(1135, '1) Қоршаған орта мен еңбек процесінің факторы, оның белгілі бір жағдайларда қызметкерге әсер етуі (қарқындылығы, ұзақтығы және т.б.) кәсіптік ауруды тудыруы немесе ұрпағының денсаулығының нашарлауына әкелуі мүмкін.', 0, 287, NULL, NULL),
(1136, '2) Берілген функцияларды орындауға кедергі келтіретін экологиялық факторлар', 0, 287, NULL, NULL),
(1137, '3) Белгіленген тапсырманы орындауға мүмкіндік бермейтін сыртқы әсер', 0, 287, NULL, NULL),
(1138, '4) барлық жауап дұрыс', 0, 287, NULL, NULL),
(1139, '1) бұл бірдей проблемалық жағдайдың екі компоненті. Егер олар ескерілмесе, авария, оқыс оқиға немесе жарақат алу ықтималдығы артады', 0, 288, NULL, NULL),
(1140, '2) Олар бір-бірімен байланысты емес', 0, 288, NULL, NULL),
(1141, '3) кадрларды кәсіби іріктеу сізге оның жеке қасиеттеріне толық сәйкес келетін жұмыс орнын таңдауға мүмкіндік береді', 0, 288, NULL, NULL),
(1142, '4) барлық жауап дұрыс', 0, 288, NULL, NULL),
(1143, '1) 25 %', 0, 289, NULL, NULL),
(1144, '2) 50 %', 0, 289, NULL, NULL),
(1145, '3) 100 %', 0, 289, NULL, NULL),
(1146, '4) бұлардың кез келген мәні', 0, 289, NULL, NULL),
(1147, '1) 22.00-ден 06.00-ге дейін жұмыс көбейтілген мөлшерде төленеді, нақты мөлшерді жұмыс беруші еңбек ұжымының пікірін, еңбек шартын ескере отырып белгілейді', 0, 290, NULL, NULL),
(1148, '2) 22.00-ден 06.00-ге дейін жұмыс екі еселік мөлшерде төленеді', 0, 290, NULL, NULL),
(1149, '3) 00.00-ден 08.00-ге дейін жұмыс бір жарым мөлшерде төленеді', 0, 290, NULL, NULL),
(1150, '4) 00.00-ден 12.00-ге дейін жұмыс бір жарымға төленеді', 0, 290, NULL, NULL),
(1151, '1) Тегі. Қызметкердің аты, әкесінің аты және жұмыс берушінің аты', 0, 291, NULL, NULL),
(1152, '2) жұмыс орны, лауазымы, еңбек функциялары, жұмыс және тынығу режимі', 0, 291, NULL, NULL),
(1153, '3) сынақ шарттары', 0, 291, NULL, NULL),
(1154, '4) барлық жауап дұрыс', 0, 291, NULL, NULL),
(1155, '1) 1 раз в год', 0, 292, NULL, NULL),
(1156, '2) 2 раза в год', 0, 292, NULL, NULL),
(1157, '3) 3 раза в год', 0, 292, NULL, NULL),
(1158, '4) 1 раз в 2 года', 0, 292, NULL, NULL),
(1159, '1) У работника на рабочем месте остановилось сердце', 0, 293, NULL, NULL),
(1160, '2) В выходной день во время ликвидации пожара на предприятии работник получил ожоги', 0, 293, NULL, NULL),
(1161, '3) Работник в свободное от работы время в столовой на территории предприятия отравился', 0, 293, NULL, NULL),
(1162, '4) Токарь во время перерыва на рабочем месте изготовлял деталь для личных нужд и был травмирован', 0, 293, NULL, NULL),
(1163, '1) Вступительный', 0, 294, NULL, NULL),
(1164, '2) Внеплановый', 0, 294, NULL, NULL),
(1165, '3) Внеплановый на рабочем месте', 0, 294, NULL, NULL),
(1166, '4) Целевой', 0, 294, NULL, NULL),
(1167, '1) До 3', 0, 295, NULL, NULL),
(1168, '2) До 5', 0, 295, NULL, NULL),
(1169, '3) До 10', 0, 295, NULL, NULL),
(1170, '4) До 15', 0, 295, NULL, NULL),
(1171, '1) При ликвидации пожара с временной потерей трудоспособности', 0, 296, NULL, NULL),
(1172, '2) При алкогольном или наркотическом отравлении', 0, 296, NULL, NULL),
(1173, '3) При исчезновении при исполнении служебных обязанностей', 0, 296, NULL, NULL),
(1174, '4) Групповые несчастные случаи на производстве', 0, 296, NULL, NULL),
(1175, '1) 50% от утраченного заработка потерпевшего', 0, 297, NULL, NULL),
(1176, '2) 100% от утраченного заработка потерпевшего', 0, 297, NULL, NULL),
(1177, '3) Среднемесячный заработок потерпевшего за период нетрудоспособности', 0, 297, NULL, NULL),
(1178, '4) Среднемесячный заработок работников предприятия за период нетрудоспособности', 0, 297, NULL, NULL),
(1179, '1) Двести среднемесячных окладов на семью погибшего и двести минимальных окладов на каждого иждивенца', 0, 298, NULL, NULL),
(1180, '2) Два годовых заработки погибшего на семью и летний на женщину', 0, 298, NULL, NULL),
(1181, '3) Пятилетний заработок погибшего на семью и летний на каждого иждивенца', 0, 298, NULL, NULL),
(1182, '4) Среднегодовой заработок работников предприятия на женщину и всех иждивенцев', 0, 298, NULL, NULL),
(1183, '1) Система мер, направленных на совершенствование рабочего места', 0, 299, NULL, NULL),
(1184, '2) Система лечебных мероприятий', 0, 299, NULL, NULL),
(1185, '3) Система организационных мероприятий и технических средств, предотвращающих или уменьшающих воздействие вредных производственных факторов', 0, 299, NULL, NULL),
(1186, '4) Комплекс индивидуальных мероприятий, которые должны выполняться каждым работником с целью предотвращения возможных заболеваний или отравлений', 0, 299, NULL, NULL),
(1187, '1) Температура', 0, 300, NULL, NULL),
(1188, '2) Влажность', 0, 300, NULL, NULL),
(1189, '3) Скорость движения воздуха', 0, 300, NULL, NULL),
(1190, '4) все ответы', 0, 300, NULL, NULL),
(1191, '1) Ртутный термометр', 0, 301, NULL, NULL),
(1192, '2) Спиртовой термометр', 0, 301, NULL, NULL),
(1193, '3) Парный термометр', 0, 301, NULL, NULL),
(1194, '4) Термограф', 0, 301, NULL, NULL),
(1195, '1) Градусах', 0, 302, NULL, NULL),
(1196, '2) Мг / м куб', 0, 302, NULL, NULL),
(1197, '3) Мг / л', 0, 302, NULL, NULL),
(1198, '4) Процентах', 0, 302, NULL, NULL),
(1199, '1) Помещение, в котором работают', 0, 303, NULL, NULL),
(1200, '2) Период года', 0, 303, NULL, NULL),
(1201, '3) Категория работ', 0, 303, NULL, NULL),
(1202, '4) Влажность воздуха', 0, 303, NULL, NULL),
(1203, '1) Марка психрометра', 0, 304, NULL, NULL),
(1204, '2) Показатели циферблата', 0, 304, NULL, NULL),
(1205, '3) Показания шкал', 0, 304, NULL, NULL),
(1206, '4) Разница температур двух термометров', 0, 304, NULL, NULL),
(1207, '1) Оптимальные', 0, 305, NULL, NULL),
(1208, '2) Допустимые', 0, 305, NULL, NULL),
(1209, '3) Максимальные', 0, 305, NULL, NULL),
(1210, '4) Минимальные', 0, 305, NULL, NULL),
(1211, '1) 2', 0, 306, NULL, NULL),
(1212, '2) 3', 0, 306, NULL, NULL),
(1213, '3) 4', 0, 306, NULL, NULL),
(1214, '4) 5', 0, 306, NULL, NULL),
(1215, '1) По средне-смертельной дозе', 0, 307, NULL, NULL),
(1216, '2) По средне-смертельной концентрации', 0, 307, NULL, NULL),
(1217, '3) По характеру воздействия на организм человека', 0, 307, NULL, NULL),
(1218, '4) По гранично-допустимой концентрации', 0, 307, NULL, NULL),
(1219, '1) Наибольшую степень опасности', 0, 308, NULL, NULL),
(1220, '2) Средняя смертельная доза', 0, 308, NULL, NULL),
(1221, '3) Средняя смертельная концентрация', 0, 308, NULL, NULL),
(1222, '4) Гранично-допустимая концентрация', 0, 308, NULL, NULL),
(1223, '1) Осадке', 0, 309, NULL, NULL),
(1224, '2) Фильтровании', 0, 309, NULL, NULL),
(1225, '3) Химическом взаимодействии', 0, 309, NULL, NULL),
(1226, '4) Испарении', 0, 309, NULL, NULL),
(1227, '1) М куб / час', 0, 310, NULL, NULL),
(1228, '2) Г', 0, 310, NULL, NULL),
(1229, '3) Мг / м куб', 0, 310, NULL, NULL),
(1230, '4) М куб', 0, 310, NULL, NULL),
(1231, '1) ПДК 0,05 – 0,1 мг / м куб', 0, 311, NULL, NULL),
(1232, '2) ПДК 0,1 – 1,0 мг / м куб', 0, 311, NULL, NULL),
(1233, '3) ПДК 7 – 10 мг / м куб', 0, 311, NULL, NULL),
(1234, '4) ПДК 1,0 – 5 мг / м куб', 0, 311, NULL, NULL),
(1235, '1) Фиброгенное', 0, 312, NULL, NULL),
(1236, '2) Раздражающее', 0, 312, NULL, NULL),
(1237, '3) Токсическая', 0, 312, NULL, NULL),
(1238, '4) все ответы', 0, 312, NULL, NULL),
(1239, '1) Животным', 0, 313, NULL, NULL),
(1240, '2) Растительным', 0, 313, NULL, NULL),
(1241, '3) Белковым', 0, 313, NULL, NULL),
(1242, '4) Минеральным', 0, 313, NULL, NULL),
(1243, '1) Vt = V * m / 1000', 0, 314, NULL, NULL),
(1244, '2) Vо = [Vt * (273 +20) * Рt] / (273 + t) * 760', 0, 314, NULL, NULL),
(1245, '3) V = S * h', 0, 314, NULL, NULL),
(1246, '4) Q = m / V', 0, 314, NULL, NULL),
(1247, '1) Марлевые повязки', 0, 315, NULL, NULL),
(1248, '2) Противогазы', 0, 315, NULL, NULL),
(1249, '3) Спецодежда', 0, 315, NULL, NULL),
(1250, '4) Защитные очки', 0, 315, NULL, NULL),
(1251, '1) Плотность светового потока на освещаемой поверхности', 0, 316, NULL, NULL),
(1252, '2) Распределение света на поверхности', 0, 316, NULL, NULL),
(1253, '3) Отношение силы света к перпендикулярной площадке', 0, 316, NULL, NULL),
(1254, '4) Световая мощность излучения', 0, 316, NULL, NULL),
(1255, '1) Ваттах', 0, 317, NULL, NULL),
(1256, '2) Вольтах', 0, 317, NULL, NULL),
(1257, '3) Люксах', 0, 317, NULL, NULL),
(1258, '4) Люменах', 0, 317, NULL, NULL),
(1259, '1) Поглощающих фильтров', 0, 318, NULL, NULL),
(1260, '2) Фотоэлемента', 0, 318, NULL, NULL),
(1261, '3) Гальванометра', 0, 318, NULL, NULL),
(1262, '4) все ответы', 0, 318, NULL, NULL),
(1263, '1) Уменьшение шума', 0, 319, NULL, NULL),
(1264, '2) Обеспечение чистоты воздуха', 0, 319, NULL, NULL),
(1265, '3) Обеспечения нормальных микроклиматических условий', 0, 319, NULL, NULL),
(1266, '4) Обеспечение взрывобезопасности', 0, 319, NULL, NULL),
(1267, '1) Объем помещения', 0, 320, NULL, NULL),
(1268, '2) Расхода воздуха на одного работающего', 0, 320, NULL, NULL),
(1269, '3) Кратность воздухообмена', 0, 320, NULL, NULL),
(1270, '4) Расхода воздуха на 2 работающих', 0, 320, NULL, NULL),
(1271, '1) По коэффициенту полезного действия', 0, 321, NULL, NULL),
(1272, '2) По создаваемому шумовые', 0, 321, NULL, NULL),
(1273, '3) По загазованности воздуха', 0, 321, NULL, NULL),
(1274, '4) По полному давлению, созданному вентилятором', 0, 321, NULL, NULL),
(1275, '1) 3', 0, 322, NULL, NULL),
(1276, '2) 5', 0, 322, NULL, NULL),
(1277, '3) 9', 0, 322, NULL, NULL),
(1278, '4) 21', 0, 322, NULL, NULL),
(1279, '1) Уровнем звука', 0, 323, NULL, NULL),
(1280, '2) Диапазоном восприятия', 0, 323, NULL, NULL),
(1281, '3) Вредным воздействием на организм человека', 0, 323, NULL, NULL),
(1282, '4) Интенсивностью звука', 0, 323, NULL, NULL),
(1283, '1) 3', 0, 324, NULL, NULL),
(1284, '2) 3,5', 0, 324, NULL, NULL),
(1285, '3) 4', 0, 324, NULL, NULL),
(1286, '4) 4,5', 0, 324, NULL, NULL),
(1287, '1) Руководитель предприятия', 0, 325, NULL, NULL),
(1288, '2) Инженерно-технический сотрудник структурных подразделений', 0, 325, NULL, NULL),
(1289, '3) Весь инженерно-технический персонал', 0, 325, NULL, NULL),
(1290, '4) все ответы', 0, 325, NULL, NULL),
(1291, '1) Такое количество вещества, которое вызывает определенные изменения в функциональном состоянии организма, и восстанавливается до начала новой смены', 0, 326, NULL, NULL),
(1292, '2) Такое количество вещества, при воздействии которой появляются патологические изменения в организме', 0, 326, NULL, NULL),
(1293, '3) Количество вещества, которое вызывает тяжелые отравления, заканчивающийся гибелью', 0, 326, NULL, NULL),
(1294, '4) Это уровень, который в течение всего трудового стажа не приводит к травме, заболевания или отклонений в состоянии здоровья в процессе работы', 0, 326, NULL, NULL),
(1295, '1) в организациях численностью 100 работников', 0, 327, NULL, NULL),
(1296, '2) численность работников которого превышает 50 человек, создается служба ОТ или вводиться должность специалиста по ОТ', 0, 327, NULL, NULL),
(1297, '3) по усмотрению администрации', 0, 327, NULL, NULL),
(1298, '4) численность работников которого превышает 100 человек, создается служба ОТ или вводиться должность специалиста по ОТ', 0, 327, NULL, NULL),
(1299, '1) с письменного согласия работника, независимо от квалификации работ', 0, 328, NULL, NULL),
(1300, '2) на срок от одного месяца в течении календарного года с оплатой труда по выполняемой работе, но не ниже среднего заработка по прежней работе, и при отсутствии противопоказаний по состоянию здоровья.', 0, 328, NULL, NULL),
(1301, '3) с устного согласия работника, независимо от квалификации работ', 0, 328, NULL, NULL),
(1302, '4) все ответы', 0, 328, NULL, NULL),
(1303, '1) каждая лестница и стремянка должна быть на учете, ', 0, 329, NULL, NULL),
(1304, '2) исправность лестниц и стремянок проверяется не реже одного раза в месяц с записью в журнале', 0, 329, NULL, NULL),
(1305, '3) иметь порядковый номер и табличку с указанием её принадлежности и даты очередного испытания', 0, 329, NULL, NULL),
(1306, '4) все ответы', 0, 329, NULL, NULL),
(1307, '1) все категории пользователей', 0, 330, NULL, NULL),
(1308, '2) Работающие с ПЭВМ, в т.ч. компьютером, более 50% рабочего времени – профессионально связанные с эксплуатацией ПЭВМ', 0, 330, NULL, NULL),
(1309, '3) Операторы. Программисты, инженеры и техники ПЭВМ', 0, 330, NULL, NULL),
(1310, '4) Работающие с ПЭВМ, в т.ч. компьютером, более 60% рабочего времени – профессионально связанные с эксплуатацией ПЭВМ', 0, 330, NULL, NULL),
(1311, '1) Показатели, позволяющие оценить степень отклонений параметров производственной среды и трудового процесса от действующих гигиенических нормативов', 0, 331, NULL, NULL),
(1312, '2) ориентировочные показатели оценки состояния условий труда', 0, 331, NULL, NULL),
(1313, '3) заранее обусловленные нормативные величины', 0, 331, NULL, NULL),
(1314, '12234567', 0, 331, NULL, NULL),
(1315, '1) Фактор среды и трудового процесса, воздействие которого на работника при определенных условиях (интенсивность, длительность и т.д.) может вызвать профессиональное заболевание или привести к нарушению здоровья потомства', 0, 332, NULL, NULL),
(1316, '2) Факторы производственной среды, затрудняющие выполнение возложенных функций', 0, 332, NULL, NULL),
(1317, '3) Внешнее воздействие, не позволяющее выполнять установленное задание', 0, 332, NULL, NULL),
(1318, '4) все ответы', 0, 332, NULL, NULL),
(1319, '1) это два составляющих элемента одной и той же проблемной ситуации. Если их не учитывать, то вероятность аварии, инцидента или травмы возрастет', 0, 333, NULL, NULL),
(1320, '2) Они между собой никак не связаны', 0, 333, NULL, NULL),
(1321, '3) профессиональный отбор персонала позволяет подобрать человека на рабочее место, которое полностью соответствует его личностным качествам', 0, 333, NULL, NULL),
(1322, '4) все ответы', 0, 333, NULL, NULL),
(1323, '1) 25 %', 0, 334, NULL, NULL),
(1324, '2) 50 %', 0, 334, NULL, NULL),
(1325, '3) 100 %', 0, 334, NULL, NULL),
(1326, '4) любое значение из названных', 0, 334, NULL, NULL),
(1327, '1) Работа с 22.00 до 06. 00 оплачивается в повышенном размере, конкретные размеры устанавливаются работодателем с учетом мнения трудового коллектива, трудовым договором', 0, 335, NULL, NULL),
(1328, '2) работа с 22.00 до 06. 00 оплачивается в двойном размере', 0, 335, NULL, NULL),
(1329, '3) работа с 00.00 до 08.00 оплачивается в полуторном размере', 0, 335, NULL, NULL),
(1330, '4) работа с 00.00 до 12.00 оплачивается в полуторном размере', 0, 335, NULL, NULL),
(1331, '1) Фамилия. Имя, отчество работника и наименование работодателя', 0, 336, NULL, NULL),
(1332, '2) место работы, должность, трудовые функции, режим труда и отдыха', 0, 336, NULL, NULL),
(1333, '3) условия об испытании', 0, 336, NULL, NULL),
(1334, '4) все ответы', 0, 336, NULL, NULL),
(1335, 'А) 10-15 минут ішінде мата арқылы салқын басыңыз;', 0, 337, NULL, NULL),
(1336, 'Б) 5-10 минут ішінде мата арқылы салқын басыңыз;', 0, 337, NULL, NULL),
(1337, 'В) 15-20 минут ішінде мата арқылы салқын басыңыз.', 0, 337, NULL, NULL),
(1338, 'Г) барлық жауап дұрыс', 0, 337, NULL, NULL),
(1339, 'А) салқын сумен кем дегенде 15 минут салқындатыңыз;', 0, 338, NULL, NULL),
(1340, 'Б) гипс орнату;', 0, 338, NULL, NULL),
(1341, 'В) сутегі асқын тотығымен өңдеңіз;', 0, 338, NULL, NULL),
(1342, 'Г) барлық жауап дұрыс', 0, 338, NULL, NULL),
(1343, 'А) естен танған кезде, тыныс алу жоқ, ұйқы артериясында пульс бар;', 0, 339, NULL, NULL),
(1344, 'Б) естен танған кезде, тыныс алу жоқ, ұйқы артериясында пульс жоқ;', 0, 339, NULL, NULL),
(1345, 'В) естен танған кезде, тыны алус бар, ұйқы артериясында пульс жоқ;', 0, 339, NULL, NULL),
(1346, 'Г) барлық жауап дұрыс', 0, 339, NULL, NULL),
(1347, 'А) жылы бөлмеге көшіру;', 0, 340, NULL, NULL),
(1348, 'Б) сутегі асқын тотығымен өңдеу;', 0, 340, NULL, NULL),
(1349, 'В) алкоголь ішу;', 0, 340, NULL, NULL),
(1350, 'Г) барлық жауап дұрыс', 0, 340, NULL, NULL),
(1351, 'А) дене массажын жасау;', 0, 341, NULL, NULL),
(1352, 'Б) көп су ішкізу;', 0, 341, NULL, NULL),
(1353, 'В) іш жүргізетін дәрілер беру;', 0, 341, NULL, NULL),
(1354, 'Г) барлық жауап дұрыс', 0, 341, NULL, NULL),
(1355, 'А) қатты бетке арқасымен жату керек;', 0, 342, NULL, NULL),
(1356, 'Б) оң немесе сол жағында, қатты жерде жатуы керек;', 0, 342, NULL, NULL),
(1357, 'В) қатты бетке ішімен жату керек;', 0, 342, NULL, NULL),
(1358, 'Г) барлық жауап дұрыс', 0, 342, NULL, NULL),
(1359, 'А) зардап шегушіні қауіпсіз жерге таза ауаға жеткізу;', 0, 343, NULL, NULL),
(1360, 'Б) көп су ішкізу;', 0, 343, NULL, NULL),
(1361, 'В) құсу шақырту;', 0, 343, NULL, NULL),
(1362, 'Г) барлық жауап дұрыс', 0, 343, NULL, NULL),
(1363, 'А) көп су ішкізу;', 0, 344, NULL, NULL),
(1364, 'Б) дене массажын жасау;', 0, 344, NULL, NULL),
(1365, 'В) құсу шақыру, іш жүргізетін дәрілер беру;', 0, 344, NULL, NULL),
(1366, 'Г) барлық жауап дұрыс', 0, 344, NULL, NULL),
(1367, 'А) қатты зембілде мойын, бел және тізе астындағы тіректермен немесе жұмсақ зембілмен – ет бетімен;', 0, 345, NULL, NULL),
(1368, 'Б) арқасымен, тізе астындағы тіреуішпен және сәл жайылған аяқтармен;', 0, 345, NULL, NULL),
(1369, 'В) тасымалдау қалпына келтіру жағдайында жүзеге асырылады;', 0, 345, NULL, NULL),
(1370, 'Г) барлық жауап дұрыс', 0, 345, NULL, NULL),
(1371, 'А) жараны сумен шайыңыз;', 0, 346, NULL, NULL),
(1372, 'Б) арқаға жатқызып, аяғын көтеру;', 0, 346, NULL, NULL),
(1373, 'В) басының астына жұмсақ көрпе салу;', 0, 346, NULL, NULL),
(1374, 'Г) барлық жауап дұрыс', 0, 346, NULL, NULL),
(1375, 'А) жгут қолдану;', 0, 347, NULL, NULL),
(1376, 'Б) уды сору;', 0, 347, NULL, NULL),
(1377, 'В) кесу жасау;', 0, 347, NULL, NULL),
(1378, 'Г) барлық жауап дұрыс', 0, 347, NULL, NULL),
(1379, 'А) тоқтатпау;', 0, 348, NULL, NULL),
(1380, 'Б) жақын заттарды алып тастау;', 0, 348, NULL, NULL),
(1381, 'В) бастың астына жұмсақ көрпе салу;', 0, 348, NULL, NULL),
(1382, 'Г) барлық жауап дұрыс', 0, 348, NULL, NULL),
(1383, 'А) Жедел жәрдем шақыру;', 0, 349, NULL, NULL),
(1384, 'Б) физикалық жүктемені тоқтату;', 0, 349, NULL, NULL),
(1385, 'В) зардап шегушіні отырғызу;', 0, 349, NULL, NULL),
(1386, 'Г) барлық жауап дұрыс', 0, 349, NULL, NULL),
(1387, 'А) ҚР ДСжӘДМ 05.22.2015 ж., №380;', 0, 350, NULL, NULL),
(1388, 'Б) ҚР ҰЭМ 05.17.2016 жылғы №458;', 0, 350, NULL, NULL),
(1389, 'В) ҚР ДСМ 12.04.2018 жылғы №168;', 0, 350, NULL, NULL),
(1390, 'Г) барлық жауап дұрыс', 0, 350, NULL, NULL),
(1391, 'А) оқиға орнында жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адаммен жүзеге асырылатын төтенше жағдайлардағы асқынулардың алдын алу бойынша жедел негізгі шаралар кешені (өзара көмек);', 0, 351, NULL, NULL),
(1392, 'Б) оқиға болған жерде жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адам жүзеге асыратын адамның өмірін сақтап қалу және төтенше жағдайлар кезінде асқынулардың алдын алу жөніндегі шұғыл негізгі шаралар кешені (өзара көмек);', 0, 351, NULL, NULL),
(1393, 'В) оқиға болған жерде жәбірленушінің өзі (өзіне-өзі көмек көрсету) немесе жақын маңдағы басқа адам жүзеге асыратын (өзара көмек) адамның өмірін сақтауға арналған шұғыл негізгі шаралар жиынтығы;', 0, 351, NULL, NULL),
(1394, 'Г) барлық жауап дұрыс', 0, 351, NULL, NULL),
(1395, 'А) приложить холод через ткань в течении 10-15 минут;', 0, 352, NULL, NULL),
(1396, 'Б) приложить холод через ткань в течении 5-10 минут;', 0, 352, NULL, NULL),
(1397, 'В) приложить холод через ткань в течении 15-20 минут;', 0, 352, NULL, NULL),
(1398, 'Г) Все варианты', 0, 352, NULL, NULL),
(1399, 'А) охладить холодной водой не менее 15 минут;', 0, 353, NULL, NULL),
(1400, 'Б) наложить гипс;', 0, 353, NULL, NULL),
(1401, 'В) обработать перекисью водорода;', 0, 353, NULL, NULL),
(1402, 'Г) Все варианты', 0, 353, NULL, NULL),
(1403, 'А) когда без сознания, нет дыхания, есть пульс на сонной артерии;', 0, 354, NULL, NULL),
(1404, 'Б) когда без сознания, нет дыхания, нет пульса на сонной артерии;', 0, 354, NULL, NULL),
(1405, 'В) когда без сознания, есть дыхание, нет пульса на сонной артерии;', 0, 354, NULL, NULL),
(1406, 'Г) Все варианты', 0, 354, NULL, NULL),
(1407, 'А) переместить пострадавшего в теплое помещение;', 0, 355, NULL, NULL),
(1408, 'Б) обработать перекисью водорода;', 0, 355, NULL, NULL),
(1409, 'В) употребить спиртной напиток;', 0, 355, NULL, NULL),
(1410, 'Г) Все варианты', 0, 355, NULL, NULL),
(1411, 'А) сделать массаж тела;', 0, 356, NULL, NULL),
(1412, 'Б) дать выпить большое количество воды;', 0, 356, NULL, NULL),
(1413, 'В) дать слабительные средства;', 0, 356, NULL, NULL),
(1414, 'Г) Все варианты', 0, 356, NULL, NULL),
(1415, 'А) должен лежать на спине, на твердой поверхности;', 0, 357, NULL, NULL),
(1416, 'Б) должен лежать на боку, на твердой поверхности;', 0, 357, NULL, NULL),
(1417, 'В) должен лежать на животе, на твердой поверхности.', 0, 357, NULL, NULL),
(1418, 'Г) Все варианты', 0, 357, NULL, NULL),
(1419, 'А) вывести пострадавшего на чистый воздух в безопасное место;', 0, 358, NULL, NULL),
(1420, 'Б) дать выпить большое количество воды;', 0, 358, NULL, NULL),
(1421, 'В) вызывать рвоту;', 0, 358, NULL, NULL),
(1422, 'Г) Все варианты', 0, 358, NULL, NULL),
(1423, 'А) дать выпить большое количество воды;', 0, 359, NULL, NULL),
(1424, 'Б) сделать массаж тела;', 0, 359, NULL, NULL),
(1425, 'В) вызывать рвоту, давать слабительные средства', 0, 359, NULL, NULL),
(1426, 'Г) Все варианты', 0, 359, NULL, NULL),
(1427, 'А) на твердых носилках на спине с валиками под шеей, поясницей и под коленями или на мягких носилках – на животе;', 0, 360, NULL, NULL),
(1428, 'Б) на спине с валиком под коленями и слегка разведенными ногами;', 0, 360, NULL, NULL),
(1429, 'В) транспортировка проводится в восстановительном положении;', 0, 360, NULL, NULL),
(1430, 'Г) Все варианты', 0, 360, NULL, NULL),
(1431, 'А) промыть рану водой;', 0, 361, NULL, NULL),
(1432, 'Б) уложить на спину и приподнять ноги;', 0, 361, NULL, NULL),
(1433, 'В) положить под голову мягкое одеяло;', 0, 361, NULL, NULL),
(1434, 'Г) Все варианты', 0, 361, NULL, NULL),
(1435, 'А) применять жгут;', 0, 362, NULL, NULL),
(1436, 'Б) отсасывать яд;', 0, 362, NULL, NULL),
(1437, 'В) делать надрез;', 0, 362, NULL, NULL),
(1438, 'Г) Все варианты', 0, 362, NULL, NULL),
(1439, 'А) не останавливать приступ;', 0, 363, NULL, NULL),
(1440, 'Б) убрать рядом находящиеся предметы;', 0, 363, NULL, NULL),
(1441, 'В) положить под голову мягкое одеяло;', 0, 363, NULL, NULL),
(1442, 'Г) Все варианты', 0, 363, NULL, NULL),
(1443, 'А) вызвать скорую помощь;', 0, 364, NULL, NULL),
(1444, 'Б) прекратить физическую деятельность;', 0, 364, NULL, NULL),
(1445, 'В) усадить пострадавшего;', 0, 364, NULL, NULL),
(1446, 'Г) Все варианты', 0, 364, NULL, NULL),
(1447, 'А) МЗиСР РК №380 от 22.05.2015 года;', 0, 365, NULL, NULL),
(1448, 'Б) МНЭ РК №458 от 17.05.2016 года;', 0, 365, NULL, NULL),
(1449, 'В) МЗ РК №168 от 12.04.2018 года;', 0, 365, NULL, NULL),
(1450, 'Г) Все варианты', 0, 365, NULL, NULL),
(1451, 'А) комплекс срочных базовых мероприятий для предупреждения осложнений при экстренных состояниях, проводимых на месте происшествия самим пострадавшим (самопомощь) или другим лицом, находящимся поблизости (взаимопомощь)', 0, 366, NULL, NULL),
(1452, 'Б) комплекс срочных базовых мероприятий для спасения жизни человека и предупреждения осложнений при экстренных состояниях, проводимых на месте происшествия самим пострадавшим (самопомощь) или другим лицом, находящимся поблизости (взаимопомощь);', 0, 366, NULL, NULL),
(1453, 'В) комплекс срочных базовых мероприятий для спасения жизни человека, проводимых на месте происшествия самим пострадавшим (самопомощь) или другим лицом, находящимся поблизости (взаимопомощь).', 0, 366, NULL, NULL),
(1454, 'Г) Все варианты', 0, 366, NULL, NULL),
(1455, 'а) Кәсіпорынның бірінші басшысының рұқсатымен барлық тұрғын үй-жайлар мен өндірістік үй-жайларға кедергісіз кіру, сондай-ақ азаматтарды құтқаруға, өрттің таралуын және өрттің алдын-алуға бағытталған шараларды қабылдау', 0, 367, NULL, NULL),
(1456, 'б) барлық тұрғын, өндірістік және басқа үй-жайларға кедергісіз кіру, сондай-ақ азаматтарды құтқару, өрттің таралуын болдырмау және өрттің алдын алу үшін түзетілген барлық шараларды қабылдау', 0, 367, NULL, NULL),
(1457, 'в) екі жауап қате', 0, 367, NULL, NULL),
(1458, 'а) өрт сөндіру бастығына', 0, 368, NULL, NULL),
(1459, 'б) өрт болған ұйымның немесе объектінің басшысына', 0, 368, NULL, NULL),
(1460, 'в) мемлекеттік өртке қарсы мекеме басшысына', 0, 368, NULL, NULL),
(1461, 'а) уәкілетті орган', 0, 369, NULL, NULL),
(1462, 'б) Қазақстан Республикасының Үкіметі', 0, 369, NULL, NULL),
(1463, 'в) уәкілетті орган жергілікті атқарушы органмен бірлесіп', 0, 369, NULL, NULL),
(1464, 'а) өрт қауіпсіздігі саласындағы бақылауды ҚР заңнамасына сәйкес жүзеге асыратын арнайы мемлекеттік орган болып табылады', 0, 370, NULL, NULL),
(1465, 'б) ҚР заңнамасына сәйкес өрттің алдын-алу, өрт қауіпсіздігі және өрт сөндіру саласындағы бақылауды жүзеге асыратын мемлекеттік орган болып табылады', 0, 370, NULL, NULL),
(1466, 'в) ҚР заңнамасына сәйкес өрттің алдын алуды жүзеге асыратын мемлекеттік орган болып табылады', 0, 370, NULL, NULL),
(1467, 'а) өрттің және оның шығынын болдырмауға бағытталған экономикалық, әлеуметтік, ұйымдастырушылық, ғылыми-техникалық және құқықтық шаралар, сондай-ақ өртке қарсы қызметтің күштері мен техникалық құралдары', 0, 371, NULL, NULL),
(1468, 'б) өрттің алдын алуға бағытталған ұйымдастырушылық іс-шаралар кешені, сондай-ақ өртке қарсы қызметтің техникалық құралдары', 0, 371, NULL, NULL),
(1469, 'в) өрттің алдын алуға бағытталған ғылыми-техникалық шаралар кешені', 0, 371, NULL, NULL),
(1470, 'а) бірыңғай мемлекеттік саясатты жүргізеді, өрт қауіпсіздігі саласында салааралық үйлестіруді жүзеге асырады', 0, 372, NULL, NULL),
(1471, 'б) өрт қауіпсіздігі саласындағы ережелерді, стандарттар мен ережелерді әзірлейді', 0, 372, NULL, NULL),
(1472, 'в) екі жауап дұрыс', 0, 372, NULL, NULL),
(1473, 'а) мемлекеттік өртке қарсы қызмет қызметкерлері', 0, 373, NULL, NULL),
(1474, 'б) төтенше жағдайларды жою жөніндегі басшыға', 0, 373, NULL, NULL),
(1475, 'в) тиісті облыстың облыстық маңызы бар қаланың, ауданның әкімі', 0, 373, NULL, NULL),
(1476, 'а) уәкілетті орган, уәкілетті органның департаменттері, оның аумақтық бөлімшелері және мемлекеттік мекемелер, соның ішінде өрт-техникалық оқу орындары', 0, 374, NULL, NULL),
(1477, 'б) басқару органдары, күштер мен құралдар, соның ішінде өрт сөндіру бөлімшелері', 0, 374, NULL, NULL),
(1478, 'в) басқару органдары, күштер мен құралдар, соның ішінде өрт сөндіру бөлімшелері мен зерттеу институттары', 0, 374, NULL, NULL),
(1479, 'а) мемлекеттік өртке қарсы қызмет', 0, 375, NULL, NULL),
(1480, 'б) мемлекеттік емес өртке қарсы қызмет', 0, 375, NULL, NULL),
(1481, 'в) жергілікті атқарушы органдар', 0, 375, NULL, NULL),
(1482, 'а) тиісті аумақтағы халық', 0, 376, NULL, NULL),
(1483, 'б) тиісті аумақтағы жергілікті атқарушы органдар', 0, 376, NULL, NULL),
(1484, 'в) дұрыс жауабы жоқ', 0, 376, NULL, NULL),
(1485, 'а) Мемлекеттік емес өртке қарсы қызмет бастығы', 0, 377, NULL, NULL),
(1486, 'б) Қазақстан Республикасының Үкіметі', 0, 377, NULL, NULL),
(1487, 'в) уәкілетті орган', 0, 377, NULL, NULL),
(1488, 'а) халықты және ұйымдарды өрт қауіпсіздігі саласындағы шаралар туралы хабардар ету; ', 0, 378, NULL, NULL),
(1489, 'б) өз құзыреті шегінде өрттен зардап шеккен азаматтар мен жұмысшыларды әлеуметтік қорғауды, азаматтардың денсаулығы мен мүлкіне, қоршаған ортаға және бизнес нысандарына келтірілген зиянды өтеуді қамтамасыз ету; ', 0, 378, NULL, NULL),
(1490, 'в) барлық жауаптар дұрыс.', 0, 378, NULL, NULL),
(1491, 'а) мемлекеттік мекеменің басшысы.', 0, 379, NULL, NULL),
(1492, 'б) тиісті аумақтағы әкім.', 0, 379, NULL, NULL),
(1493, 'в) уәкілетті органның басшысы', 0, 379, NULL, NULL),
(1494, 'а) уәкілетті орган мен Қазақстан Республикасының тиісті заңды тұлғалары арасындағы келісімдер.', 0, 380, NULL, NULL),
(1495, 'б) реттелмеген.', 0, 380, NULL, NULL),
(1496, 'в) өрт қауіпсіздігі ережелері.', 0, 380, NULL, NULL),
(1497, 'a) тиісті объектілерде өрттің алдын алу және сөндіру.', 0, 381, NULL, NULL),
(1498, 'б) тиісті объектілерде өртті сөндіруге байланысты авариялық-құтқару жұмыстарын жүргізу.', 0, 381, NULL, NULL),
(1499, 'в) екі жауап дұрыс.', 0, 381, NULL, NULL),
(1500, 'а) тек өрт сөндіру саймандарымен.', 0, 382, NULL, NULL),
(1501, 'б) мемлекеттік өртке қарсы қызмет органдары үшін белгіленген нормаларға сәйкес арнайы киім және өрт сөндіру саймандарымен.', 0, 382, NULL, NULL),
(1502, 'в) тек арнайы киіммен.', 0, 382, NULL, NULL),
(1503, 'а) тиісті облыстың (республикалық маңызы бар қаланың, астананың) жергілікті бюджетіне. ', 0, 383, NULL, NULL),
(1504, 'б) шығындар өтелмейді. ', 0, 383, NULL, NULL),
(1505, 'в) республикалық бюджетке.', 0, 383, NULL, NULL),
(1506, 'а) уәкілетті органмен;', 0, 384, NULL, NULL),
(1507, 'б) уәкілетті органның аумақтық бөлімшесімен.', 0, 384, NULL, NULL),
(1508, 'в) Қазақстан Республикасының Үкіметімен.', 0, 384, NULL, NULL),
(1509, 'а) Қазақстан Республикасының Үкіметімен. ', 0, 385, NULL, NULL),
(1510, 'б) ерікті өрттің құрылуы туралы жарғысымен. ', 0, 385, NULL, NULL),
(1511, 'в) Қазақстан Республикасы Еңбек және халықты әлеуметтік қорғау министрлігімен.', 0, 385, NULL, NULL),
(1512, 'а) Қазақстан Республикасының заңнамасына сәйкес өрттің алдын-алу, өрт қауіпсіздігі және өрт сөндіру саласындағы бақылауды жүзеге асыратын мемлекеттік органдар болып табылады', 0, 386, NULL, NULL),
(1513, 'б) Қазақстан Республикасының заңнамасына сәйкес өрттің алдын-алу және сөндіруді жүзеге асыратын мемлекеттік органдар болып табылады', 0, 386, NULL, NULL),
(1514, 'в) Қазақстан Республикасының заңнамасына сәйкес өрт қауіпсіздігі саласындағы бақылауды жүзеге асыратын мемлекеттік органдар болып табылады', 0, 386, NULL, NULL),
(1515, 'а) жергілікті атқарушы органға', 0, 387, NULL, NULL),
(1516, 'б) уәкілетті органға', 0, 387, NULL, NULL),
(1517, 'в) ұйымдардың басшыларына', 0, 387, NULL, NULL),
(1518, 'а) ерікті өрт сөндіру топтары.', 0, 388, NULL, NULL),
(1519, 'б) өнеркәсіптік өртке қарсы қызмет.', 0, 388, NULL, NULL),
(1520, 'в) жергілікті атқарушы органдардың өрт сөндіру бригадалары.', 0, 388, NULL, NULL),
(1521, 'а) жергілікті атқарушы орган әзірлейді және уәкілетті органның аумақтық бөлімшесінің басшысы бекітеді.', 0, 389, NULL, NULL),
(1522, 'б) ерікті өрт сөндіру бөлімінің бастығы әзірлейді және уәкілетті органның аумақтық бөлімшесінің басшысы бекітеді.', 0, 389, NULL, NULL),
(1523, 'в) жергілікті атқарушы орган бекіткен ерікті өрт сөндіру бөлімінің бастығы әзірлейді', 0, 389, NULL, NULL),
(1524, 'а) бір мезгілде жүз және одан да көп адамның тұруына арналған сауда кәсіпорындарының, қоғамдық тамақтандырудың, тұрмыстық қызметтердің, сауықтыру, спорт, мәдени және білім беру және ойын-сауық ұйымдарының, діни мекемелердің, ойын-сауық объектілерінің, теміржол станциясының ғимараттары, құрылыстары мен үй-жайлары; сонымен қатар жиырма бес және одан да көп адамның бір уақытта болуына арналған денсаулық сақтау ұйымдарының, білім беру, қонақ үйлердің ғимараттары мен құрылыстары,', 0, 390, NULL, NULL),
(1525, 'б) бір мезгілде елу және одан да көп адамның болуына арналған сауда кәсіпорындарының ғимараттары, ғимараттары, үй-жайлары, қоғамдық тамақтану, тұрмыстық қызмет көрсету, спорт және дене шынықтыру, спорт, мәдени және білім беру және ойын-сауық ұйымдары, салқын үйлер, ойын-сауық орындары, барлық көлік түрлерінің теміржол станциялары.', 0, 390, NULL, NULL),
(1526, 'в) денсаулық сақтау ұйымдарының ғимараттары мен құрылыстары, білім беру, қонақ үйлер, бір мезгілде қырық және одан да көп адамның болуына арналған', 0, 390, NULL, NULL),
(1527, 'а) төтенше жағдайлар саласындағы уәкілетті органның заңды тұлғаның төтенше жағдай саласындағы тәуекелдерді тәуелсіз бағалау жөніндегі жұмыстарды жүргізу құзыретін ресми мойындауы. ', 0, 391, NULL, NULL),
(1528, 'б) өрт қауіпсіздігі саласындағы уәкілетті органның заңды тұлғаның өрт қауіпсіздігі саласындағы тәуекелдерді тәуелсіз бағалау бойынша жұмыстарды жүргізуге ресми тануы. ', 0, 391, NULL, NULL),
(1529, 'в) жоғарыда айтылғандардың бәрі дұрыс емес;', 0, 391, NULL, NULL),
(1530, 'а) заңды тұлғаның сот-сараптама қызметімен айналысу құқығын куәландыратын, өрт қауіпсіздігі саласындағы уәкілетті орган берген құжат. ', 0, 392, NULL, NULL),
(1531, 'б) заңды тұлғаның өрт қауіпсіздігі саласындағы тәуекелдерді тәуелсіз бағалау жөніндегі жұмыстарды жүргізу құқығын растайтын өнеркәсіп саласындағы уәкілетті орган берген құжат. ', 0, 392, NULL, NULL),
(1532, 'в) заңды тұлғаның өрт қауіпсіздігі саласындағы тәуекелдерді тәуелсіз бағалау жөніндегі жұмыстарды жүргізу құқығын куәландыратын өрт қауіпсіздігі саласындағы уәкілетті орган берген құжат.', 0, 392, NULL, NULL),
(1533, 'а) жеке тұлғалардың немесе заңды тұлғалардың меншігі, мемлекеттік меншік, оның ішінде ғимараттардың, құрылыстардың, құрылыстардың, технологиялық қондырғылардың, жабдықтардың, қондырғылардың және басқа да мүліктің, өрт қауіпсіздігі талаптары өрттің алдын алу және адамдарды өрт кезінде қорғауға арналған болуы керек.', 0, 393, NULL, NULL),
(1534, 'б) б) заңды тұлғалардың меншігі, мемлекеттік меншік, оның ішінде ғимараттардың, құрылыстардың, құрылыстардың, технологиялық қондырғылардың, жабдықтардың, агрегаттардың және өрттің алдын алу және адамдарды қорғау үшін өрт қауіпсіздігі талаптары белгіленетін немесе құрылуы керек басқа мүлік.', 0, 393, NULL, NULL),
(1535, 'в). жеке немесе заңды тұлғалардың мүлкі, мемлекет меншігі', 0, 393, NULL, NULL),
(1536, 'а) жеке кәсіпкерлер және заңды тұлғалар. ', 0, 394, NULL, NULL),
(1537, 'б) заңды тұлғалар.', 0, 394, NULL, NULL),
(1538, 'в) дұрыс жауап жоқ.', 0, 394, NULL, NULL),
(1539, 'а) ҚР заңнамасында өрт қауіпсіздігін қамтамасыз ету мақсатында белгіленген техникалық және әлеуметтік сипаттағы ерекше жағдайлар. ', 0, 395, NULL, NULL),
(1540, 'б) ҚР заңнамасында өрт қауіпсіздігін қамтамасыз ету мақсатында белгіленген техникалық сипаттағы жағдайлар. ', 0, 395, NULL, NULL),
(1541, 'в) ҚР заңнамасында ұлттық қауіпсіздікті қамтамасыз ету мақсатында белгіленген ерекше жағдайлар.', 0, 395, NULL, NULL),
(1542, 'а) объектілердің өрт қауіпсіздігі талаптарына сәйкестігін немесе сәйкес келмеуін анықтау бойынша кәсіпкерлік қызмет.', 0, 396, NULL, NULL),
(1543, 'б) объектілердің өрт қауіпсіздігі талаптарына сәйкестігін немесе сәйкес еместігін анықтау бойынша ғылыми-зерттеу жұмыстары.', 0, 396, NULL, NULL),
(1544, 'в) жоғарыда айтылғандардың бәрі дұрыс.', 0, 396, NULL, NULL),
(1545, 'а) уәкілетті органның өз құзыреті шегінде жеке және заңды тұлғалардың өрт қауіпсіздігі ережелерінің талаптарын сақтауын қамтамасыз етуге бағытталған қызметі.', 0, 397, NULL, NULL),
(1546, 'б) уәкілетті органның өз құзыреті шегінде жеке және заңды тұлғалардың Қазақстан Республикасы заңдарының, Қазақстан Республикасы Президентінің жарлықтарының және Қазақстан Республикасы Үкіметінің өрт қауіпсіздігі саласындағы қаулыларының талаптарын сақтауын қамтамасыз етуге бағытталған қызметі. ', 0, 397, NULL, NULL),
(1547, 'в) уәкілетті органның жеке және заңды тұлғалардың техникалық регламенттердің талаптарын сақтауын қамтамасыз етуге бағытталған өз құзыреті шегіндегі қызметі.', 0, 397, NULL, NULL),
(1548, 'а) өрт қауіпсіздігі саласындағы басшылықты қамтамасыз ететін мемлекеттік орган.', 0, 398, NULL, NULL),
(1549, 'б) төтенше жағдайлар саласындағы басшылықты қамтамасыз ететін мемлекеттік орган.', 0, 398, NULL, NULL),
(1550, 'в) мемлекеттік орган. азаматтық қорғаныс саласындағы көшбасшылықты қамтамасыз ету.', 0, 398, NULL, NULL),
(1551, 'а) техникалық және өрт қауіпсіздігі талаптарын сақтау бойынша іс-шаралар. ', 0, 399, NULL, NULL),
(1552, 'б) өрт қауіпсіздігі талаптарын сақтау бойынша іс-шаралар. ', 0, 399, NULL, NULL),
(1553, 'в) өртке қарсы қызметтердің талаптарын орындау бойынша іс-шаралар.', 0, 399, NULL, NULL),
(1554, 'а) электрондық компьютерлер мен мәліметтер базасына арналған бағдарламалар, сондай-ақ өрттің алдын алу мен сөндірудің басқа құралдары. ', 0, 400, NULL, NULL),
(1555, 'б) арнайы техникалық. өрт қауіпсіздігін қамтамасыз етуге арналған ғылыми, техникалық және интеллектуалдық өнімдер, соның ішінде өрт сөндіру техникасы мен жабдықтары, өрт сөндіру техникасы, өрт сөндіру және оттан сақтайтын заттар, арнайы байланыс және басқару құралдары, электрондық компьютерлер мен мәліметтер базасына арналған бағдарламалар, сондай-ақ басқа да ескерту құралдары өрттерді сөндіру. ', 0, 400, NULL, NULL),
(1556, 'в) өрт қауіпсіздігін қамтамасыз етуге арналған арнайы техникалық, ғылыми, техникалық және зияткерлік өнімдер.', 0, 400, NULL, NULL),
(1557, 'a) өрт қауіпсіздігі саласындағы тәуекелдерді тәуелсіз бағалауды жүзеге асыру үшін белгіленген тәртіппен аккредиттелген ұйым. ', 0, 401, NULL, NULL),
(1558, 'б) сот қызметін жүзеге асыру үшін белгіленген тәртіппен аккредиттелген ұйым. ', 0, 401, NULL, NULL),
(1559, 'в) ұйымдастыру. өрт қауіпсіздігі саласындағы бағалау жұмыстарын жүргізу.', 0, 401, NULL, NULL),
(1560, 'а) жұмысын тоқтату (тоқтата тұру) елді мекендер мен аумақтардың әлеуметтік және инженерлік инфрақұрылымын бұзуға алып келетін денсаулық сақтау, телекоммуникациялар, байланыс, газ, энергетика, жылу, су және су бұру ұйымдары. ', 0, 402, NULL, NULL),
(1561, 'б) жұмысын тоқтату (тоқтата тұру) елді мекендер мен аумақтардың әлеуметтік және инженерлік инфрақұрылымын бұзуға әкеп соқтыратын сумен жабдықтау және су бұруды ұйымдастыру. ', 0, 402, NULL, NULL),
(1562, 'в) дұрыс жауап жоқ.', 0, 402, NULL, NULL),
(1563, 'а) тәуелсіз тәуелсіз бағалаудың оң қорытындысы.', 0, 403, NULL, NULL),
(1564, 'б) өрт қаупі рұқсат етілген мәндерден аспайды.', 0, 403, NULL, NULL),
(1565, 'в) объект қажетті мөлшерде өрттен қорғайтын қондырғылармен қамтамасыз етілген.', 0, 403, NULL, NULL),
(1566, 'а) мемлекет меншігінде. ', 0, 404, NULL, NULL),
(1567, 'б) адамдардың көп болуы және өмірді қамтамасыз ету объектілерінде. ', 0, 404, NULL, NULL),
(1568, 'в) екі жауап дұрыс.', 0, 404, NULL, NULL),
(1569, 'а) штатында кемінде бес маман болу керек.', 0, 405, NULL, NULL),
(1570, 'б) оның штатында кемінде үш маман болуы.', 0, 405, NULL, NULL),
(1571, 'в) оның штатында кемінде екі маман болуы.', 0, 405, NULL, NULL),
(1572, 'а) өртке қарсы тәжірибе. ', 0, 406, NULL, NULL),
(1573, 'б) заттардың, материалдардың, технологиялық процестердің, бұйымдардың, құрылыстардың, ғимараттар мен құрылыстардың өрт қауіптілігін бағалау. ', 0, 406, NULL, NULL),
(1574, 'в) екі жауап дұрыс.', 0, 406, NULL, NULL),
(1575, 'а) өрт қауіпсіздігі саласындағы уәкілетті органның аумақтық бөлімшелері.', 0, 407, NULL, NULL),
(1576, 'б) өртке қарсы қызмет, ерікті өрт сөндіру топтары.', 0, 407, NULL, NULL),
(1577, 'в) облыстардың, республикалық маңызы бар қаланың және астананың, аудандардың жергілікті атқарушы органдары.', 0, 407, NULL, NULL),
(1578, 'а) жеке кәсіпкерлер мен қала тұрғындары.', 0, 408, NULL, NULL),
(1579, 'б) жеке және заңды тұлғалар.', 0, 408, NULL, NULL),
(1580, 'в) мемлекеттік ұйымдар мен шаруашылық жүргізуші субъектілер.', 0, 408, NULL, NULL),
(1581, 'а) құрылыс нормалары мен ережелерінде. ', 0, 409, NULL, NULL),
(1582, 'б) техникалық регламенттерде. ', 0, 409, NULL, NULL),
(1583, 'в) өрт қауіпсіздігі ережелерінде.', 0, 409, NULL, NULL),
(1584, 'а) өрт қауіпсіздігі саласындағы уәкілетті орган. ', 0, 410, NULL, NULL),
(1585, 'б) ҚР тиісті уәкілетті органы. ', 0, 410, NULL, NULL),
(1586, 'в) ҚР Төтенше жағдайлар министрлігінің аумақтық бөлімшелері.', 0, 410, NULL, NULL),
(1587, 'а) техникалық реттеу саласындағы уәкілетті орган.', 0, 411, NULL, NULL),
(1588, 'б) өрт қауіпсіздігі саласындағы уәкілетті орган.', 0, 411, NULL, NULL),
(1589, 'в) аумақтық органдар.', 0, 411, NULL, NULL),
(1590, 'а) на беспрепятственный доступ во все жилые помещения, и производственные помещения с разрешения первого руководителя предприятия, а также принимать законные меры, направленные на спасение граждан, предотвращение распространения огня и на ликвидацию пожаров;', 0, 412, NULL, NULL),
(1591, 'б) на беспрепятственный доступ во все жилые, производственные и другие помещения, а также принимать любые меры, исправленные на спасение граждан, предотвращение распространения огня и на ликвидацию пожаров;', 0, 412, NULL, NULL);
INSERT INTO `options` (`id`, `body`, `isTrue`, `question_id`, `created_at`, `updated_at`) VALUES
(1592, 'в) оба ответа неверны.', 0, 412, NULL, NULL),
(1593, 'а) руководителю тушения пожара.', 0, 413, NULL, NULL),
(1594, 'б) руководителю организации или объекта, на котором произошел пожар.', 0, 413, NULL, NULL),
(1595, 'в) начальнику государственного учреждения пожаротушения.', 0, 413, NULL, NULL),
(1596, 'а) уполномоченный орган.', 0, 414, NULL, NULL),
(1597, 'б) Правительство Республики Казахстан.', 0, 414, NULL, NULL),
(1598, 'в) уполномоченный орган совместно с местным исполнительным органом.', 0, 414, NULL, NULL),
(1599, 'а) специальными государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан контроль в области пожарной безопасности.', 0, 415, NULL, NULL),
(1600, 'б) государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан предупреждение пожаров, контроль в области пожарной безопасности и тушение пожаров.', 0, 415, NULL, NULL),
(1601, 'в) государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан предупреждение пожаров.', 0, 415, NULL, NULL),
(1602, 'а) совокупность экономических, социальных, организационных, научно-технических н правовых мер, а также сил и технических средств противопожарной службы, направленных на предотвращение пожара и ущерба от него.', 0, 416, NULL, NULL),
(1603, 'б) совокупность организационных мер, а также технических средств противопожарной службы, направленных на предотвращение пожара.', 0, 416, NULL, NULL),
(1604, 'в) совокупность научно-технических мер, направленных на предотвращение пожара.', 0, 416, NULL, NULL),
(1605, 'а) проводит единую государственную политику, осуществляет межотраслевую координацию в области пожарной безопасности.', 0, 417, NULL, NULL),
(1606, 'б) разрабатывает нормативы, стандарты и правила в области пожарной безопасности.', 0, 417, NULL, NULL),
(1607, 'в) оба ответа верны.', 0, 417, NULL, NULL),
(1608, 'а) должностных лиц органов государственной противопожарной службы.', 0, 418, NULL, NULL),
(1609, 'б) руководителя ликвидации чрезвычайных ситуаций.', 0, 418, NULL, NULL),
(1610, 'в) акима соответствующей области (города республиканского значения, столицы), города областного значения, района.', 0, 418, NULL, NULL),
(1611, 'а) уполномоченного органа, ведомства уполномоченного органа, его территориальных подразделений и государственных учреждений, в том числе пожарно-технических учебных заведений.', 0, 419, NULL, NULL),
(1612, 'б) органов управления, силы и средства, в том числе противопожарные формирования.', 0, 419, NULL, NULL),
(1613, 'в) органов управления, силы и средства, в том числе противопожарные формирования и научно-исследовательские учреждения.', 0, 419, NULL, NULL),
(1614, 'а) органами государственной противопожарной службы.', 0, 420, NULL, NULL),
(1615, 'б) негосударственными противопожарными службами.', 0, 420, NULL, NULL),
(1616, 'в) местными исполнительными органами.', 0, 420, NULL, NULL),
(1617, 'а) населением на соответствующей территории.', 0, 421, NULL, NULL),
(1618, 'б) местными исполнительными органами на соответствующей территории.', 0, 421, NULL, NULL),
(1619, 'в) нет верного ответа.', 0, 421, NULL, NULL),
(1620, 'а) руководителем негосударственной противопожарной службы.', 0, 422, NULL, NULL),
(1621, 'б) Правительством Республики Казахстан.', 0, 422, NULL, NULL),
(1622, 'в) уполномоченным органом.', 0, 422, NULL, NULL),
(1623, 'а) информирование населения и организации о мерах в области пожарной безопасности;', 0, 423, NULL, NULL),
(1624, 'б) обеспечение в пределах своей компетенции социальной защиты граждан и работников, пострадавших вследствие пожаров, возмещение вреда, причиненного здоровью и имуществу граждан, окружающей среде и объектам хозяйствования;', 0, 423, NULL, NULL),
(1625, 'в) все ответы верны.', 0, 423, NULL, NULL),
(1626, 'а) руководитель государственного учреждения.', 0, 424, NULL, NULL),
(1627, 'б) Аким на соответствующей территории.', 0, 424, NULL, NULL),
(1628, 'в) руководитель уполномоченного органа.', 0, 424, NULL, NULL),
(1629, 'а) соглашениями между уполномоченным органом и соответствующими юридическими лицами Республики Казахстан.', 0, 425, NULL, NULL),
(1630, 'б) не регламентируется.', 0, 425, NULL, NULL),
(1631, 'в) правилами пожарной безопасности.', 0, 425, NULL, NULL),
(1632, 'а) предупреждение и тушение пожаров на соответствующих объектах.', 0, 426, NULL, NULL),
(1633, 'б) проведение первоочередных аварийно-спасательных работ, связанных с тушением пожаров па соответствующих объектах.', 0, 426, NULL, NULL),
(1634, 'в) оба ответа верны.', 0, 426, NULL, NULL),
(1635, 'а) только противопожарным снаряжением.', 0, 427, NULL, NULL),
(1636, 'б) специальным обмундированием н противопожарным снаряжением по нормам, установленным для органов государственной противопожарной службы.', 0, 427, NULL, NULL),
(1637, 'в) только специальным обмундированием.', 0, 427, NULL, NULL),
(1638, 'а) в местный бюджет соответствующей области (города республиканского значения, столицы).', 0, 428, NULL, NULL),
(1639, 'б) затраты не возмещаются.', 0, 428, NULL, NULL),
(1640, 'в) в республиканский бюджет.', 0, 428, NULL, NULL),
(1641, 'а) уполномоченным органом,', 0, 429, NULL, NULL),
(1642, 'б) территориальным подразделением уполномоченного органа.', 0, 429, NULL, NULL),
(1643, 'в) Правительством Республики Казахстан.', 0, 429, NULL, NULL),
(1644, 'а) Правительством Республики Казахстан.', 0, 430, NULL, NULL),
(1645, 'б) уставом добровольного противопожарного формирования.', 0, 430, NULL, NULL),
(1646, 'в) Министерством труда и социальной зашиты Республики Казахстан.', 0, 430, NULL, NULL),
(1647, 'а) государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан предупреждение пожаров, контроль в области пожарной безопасности и тушение пожаров.', 0, 431, NULL, NULL),
(1648, 'б) государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан предупреждение и тушение пожаров.', 0, 431, NULL, NULL),
(1649, 'в) государственными органами, осуществляющими в соответствии с законодательством Республики Казахстан контроль в области пожарной безопасности.', 0, 431, NULL, NULL),
(1650, 'а) местный исполнительный орган,', 0, 432, NULL, NULL),
(1651, 'б) уполномоченный орган.', 0, 432, NULL, NULL),
(1652, 'в) руководителей организаций.', 0, 432, NULL, NULL),
(1653, 'а) добровольные противопожарные формирования.', 0, 433, NULL, NULL),
(1654, 'б) отраслевые противопожарные службы.', 0, 433, NULL, NULL),
(1655, 'в) пожарные команды местных исполнительных органов.', 0, 433, NULL, NULL),
(1656, 'а) разрабатывается местным исполнительным органом и утверждается руководителем территориального подразделения уполномоченного органа.', 0, 434, NULL, NULL),
(1657, 'б) разрабатывается руководителем добровольного противопожарного формирования и утверждается руководителем территориального подразделения уполномоченного органа.', 0, 434, NULL, NULL),
(1658, 'в) разрабатывается руководителем добровольного противопожарного формированная утверждается местным наполнительным органом.', 0, 434, NULL, NULL),
(1659, 'а) здания, сооружения и помещения предприятий торговли, общественного питания, бытового обслуживания, физкультурно-оздоровительных, спортивных, культурно-просветительских и зрелищных организаций, культовых учреждений, развлекательных заведений, вокзалов всех видов транспорта, рассчитанные на одновременное пребывание ста и более человек, а также здания и сооружения организаций здравоохранения, образования, гостиниц, рассчитанные на одновременное пребывание двадцати пяти и более человек,', 0, 435, NULL, NULL),
(1660, 'б) здания, сооружения и помещения предприятий торговли, общественного питания, бытового обслуживания, физкультурно-оздоровительных, спортивных, культурно-просветительских и зрелищных организаций, кулевых учреждений, развлекательных заведений, вокзалов всех видов транспорта, рассчитанные на одновременное пребывание пятидесяти и более человек.', 0, 435, NULL, NULL),
(1661, 'в) здания и сооружения организаций здравоохранения, образования, гостиниц, рассчитанные на одновременное пребывание сорока н более человек.', 0, 435, NULL, NULL),
(1662, 'а) официальное признание уполномоченным органом в области чрезвычайных ситуаций правомочий юридического лица выполнять работы по проведению независимой оценки рисков в области чрезвычайных ситуаций.', 0, 436, NULL, NULL),
(1663, 'б) официальное признание уполномоченным органом в области пожарной безопасности правомочий юридического лица выполнять работы по проведению независимой оценки рисков в области пожарной безопасности.', 0, 436, NULL, NULL),
(1664, 'в) все перечисленное не верно,', 0, 436, NULL, NULL),
(1665, 'а) документ, выдаваемый уполномоченным органом в области пожарной безопасности, удостоверяющий право юридического лица выполнять работы по проведению судебно-экспертной деятельности.', 0, 437, NULL, NULL),
(1666, 'б) документ, выдаваемый уполномоченным органом в области промышлености, удостоверяющий право юридического лица выполнять работы по проведению независимой оценки рисков в области пожарной безопасности.', 0, 437, NULL, NULL),
(1667, 'в) документ, выдаваемый уполномоченным органом в области пожарной безопасности, удостоверяющий право юридического лица выполнять работы по проведению независимой оценки рисков в области пожарной безопасности.', 0, 437, NULL, NULL),
(1668, 'а) имущество физических или юридических лиц, государственное имущество, в том числе здания, сооружения, строения, технологические установки, оборудование, агрегаты и иное имущество, к которому установлены или должны быть установлены требования пожарной безопасности для предотвращения пожара н защиты людей при пожаре.', 0, 438, NULL, NULL),
(1669, 'б) имущество юридических лиц, государственное имущество, в том числе здания, сооружения, строения, технологические установки, оборудование, агрегаты и иное имущество, к которому установлены или должны быть установлены требования пожаробезопасности для предотвращения пожара и защиты людей при пожаре.', 0, 438, NULL, NULL),
(1670, 'в) имущество физических или юридических лиц, государственное имущество.', 0, 438, NULL, NULL),
(1671, 'а) индивидуальные предприниматели и юридические лица.', 0, 439, NULL, NULL),
(1672, 'б) юридические лица.', 0, 439, NULL, NULL),
(1673, 'в) нет верного ответа.', 0, 439, NULL, NULL),
(1674, 'а) специальные условия технического и (или) социального характера, установленные в целях обеспечения пожарной безопасности законодательством Республики Казахстан.', 0, 440, NULL, NULL),
(1675, 'б) условия техническою характера, установленные в целях обеспечения пожаробезопасности законодательством Республики Казахстан.', 0, 440, NULL, NULL),
(1676, 'в) специальные условия, установленные в целях обеспечения национальной безопасности законодательством Республики Казахстан.', 0, 440, NULL, NULL),
(1677, 'а) предпринимательская деятельность по установлению соответствия или несоответствия объектов требованиям пожарной безопасности.', 0, 441, NULL, NULL),
(1678, 'б) научно-исследовательская деятельность по установлению соответствия или несоответствия объектов требованиям пожарной безопасности.', 0, 441, NULL, NULL),
(1679, 'в) все перечисленное верно.', 0, 441, NULL, NULL),
(1680, 'а) деятельность уполномоченного органа в пределах его компетенции, направленная на обеспечение соблюдения физическими и юридическим лицами требований Правил пожарной безопасности.', 0, 442, NULL, NULL),
(1681, 'б) деятельность уполномоченного органа в пределах его компетенции, направленная на обеспечение соблюдения физическими и юридическими лицами требований законов Республики Казахстан, указов Президента Республики Казахстан и постановлений Правительства Республики Казахстан в области пожарной безопасности.', 0, 442, NULL, NULL),
(1682, 'в) деятельность уполномоченного органа в пределах его компетенции, направленная на обеспечение соблюдения физическими и юридическими лицами требований Технических регламентов.', 0, 442, NULL, NULL),
(1683, 'а) государственный орган, осуществляющий руководство в области пожарной безопасности.', 0, 443, NULL, NULL),
(1684, 'б) государственный орган, осуществляющий руководство в области чрезвычайных ситуаций.', 0, 443, NULL, NULL),
(1685, 'в) государственный орган. осуществляющий руководство в области гражданской обороны.', 0, 443, NULL, NULL),
(1686, 'а) действия по выполнению требований технической и противопожарной безопасности.', 0, 444, NULL, NULL),
(1687, 'б) действия по выполнению требований пожарной безопасности.', 0, 444, NULL, NULL),
(1688, 'в) действия по выполнению требований противопожарных служб.', 0, 444, NULL, NULL),
(1689, 'а) программы для электронных вычислительных машин и базы данных, а также иные средства предупреждения и тушения пожаров.', 0, 445, NULL, NULL),
(1690, 'б) специальная техническая. научно-техническая и интеллектуальная продукция, предназначенная для обеспечения пожарной безопасности, в том числе пожарная техника и оборудование, пожарное снаряжение, огнетушащие и огнезащитные вещества, средства специальной связи н управления, программы для электронных вычислительных машин и базы данных, а также иные средства предупреждения н тушения пожаров.', 0, 445, NULL, NULL),
(1691, 'в) специальная техническая, научно-техническая и интеллектуальная продукция, предназначенная для обеспечения пожарной безопасности.', 0, 445, NULL, NULL),
(1692, 'а) организация, аккредитованная в установленном порядке на осуществление деятельности по независимой оценке рисков в области пожарной безопасности.', 0, 446, NULL, NULL),
(1693, 'б) организация, аккредитованная в установленном порядке на осуществление судебно-экспертной деятельности.', 0, 446, NULL, NULL),
(1694, 'в) организация. осуществляющая оценочную деятельность в области пожарной безопасности.', 0, 446, NULL, NULL),
(1695, 'а) организации здравоохранения, телекоммуникаций, связи, газо-, энерго-, тепло-, водоснабжения и водоотведения, прекращение (приостановка) эксплуатации которых влечет за собой нарушение деятельности социальной и инженерной инфраструктур населенных пунктов и территорий.', 0, 447, NULL, NULL),
(1696, 'б) организации водоснабжения и водоотведения, прекращение (приостановка)эксплуатации которых влечет за собой нарушение деятельности социальной и инженерной инфраструктур населенных пунктов и территорий.', 0, 447, NULL, NULL),
(1697, 'в) нет верного ответа.', 0, 447, NULL, NULL),
(1698, 'а) положительное заключение независимой оценки рисков.', 0, 448, NULL, NULL),
(1699, 'б) пожарный риск не превышает допустимых значений.', 0, 448, NULL, NULL),
(1700, 'в) объект обеспечен необходимым количеством установок автоматической противопожарной защиты.', 0, 448, NULL, NULL),
(1701, 'а) на объектах государственной собственности.', 0, 449, NULL, NULL),
(1702, 'б) на объектах с массовым пребыванием людей и жизнеобеспечения.', 0, 449, NULL, NULL),
(1703, 'в) оба ответа верны.', 0, 449, NULL, NULL),
(1704, 'а) имеющие в своем штате не менее пяти специалистов.', 0, 450, NULL, NULL),
(1705, 'б) имеющие в своем штате не менее трех специалистов.', 0, 450, NULL, NULL),
(1706, 'в) имеющие в своем штате не менее двух специалистов.', 0, 450, NULL, NULL),
(1707, 'а) опыта борьбы с пожарами.', 0, 451, NULL, NULL),
(1708, 'б) оценки пожарной опасности веществ, материалов, технологических процессов, изделий, конструкций, зданий и сооружений.', 0, 451, NULL, NULL),
(1709, 'в) оба ответа верны.', 0, 451, NULL, NULL),
(1710, 'а) территориальные подразделения уполномоченного органа в области пожарной безопасности.', 0, 452, NULL, NULL),
(1711, 'б) противопожарные службы, добровольные противопожарные формирования.', 0, 452, NULL, NULL),
(1712, 'в) местные исполнительные органы областей, городов республиканского значения и столицы, районов (городов областного значения).', 0, 452, NULL, NULL),
(1713, 'а) индивидуальные предприниматели и городские лица.', 0, 453, NULL, NULL),
(1714, 'б) физические н юридические лица.', 0, 453, NULL, NULL),
(1715, 'в) государственные организации и субъекты предпринимательства.', 0, 453, NULL, NULL),
(1716, 'а) в строительных нормах и правилах.', 0, 454, NULL, NULL),
(1717, 'б) в технических регламентах.', 0, 454, NULL, NULL),
(1718, 'в) в правилах пожарной безопасности.', 0, 454, NULL, NULL),
(1719, 'а) уполномоченным органом в области пожарной безопасности.', 0, 455, NULL, NULL),
(1720, 'б) соответствующим уполномоченным органом Республики Казахстан.', 0, 455, NULL, NULL),
(1721, 'в) территориальными подразделениями МЧС РК.', 0, 455, NULL, NULL),
(1722, 'а) уполномоченным органом в области технического регулирования.', 0, 456, NULL, NULL),
(1723, 'б) уполномоченным органом в области пожарной безопасности.', 0, 456, NULL, NULL),
(1724, 'в) территориальными органами.', 0, 456, NULL, NULL),
(1725, '1) 425-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 457, NULL, NULL),
(1726, '2) 423-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 457, NULL, NULL),
(1727, '3) 424-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 457, NULL, NULL),
(1728, '4) 426-бап. Халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнама талаптарын, сондай-ақ гигиеналық нормативтердi бұзу', 0, 457, NULL, NULL),
(1729, '1) кемінде 5 минутты құрайды', 0, 458, NULL, NULL),
(1730, '2) кемінде 15 минутты құрайды', 0, 458, NULL, NULL),
(1731, '3) кемінде 25 минутты құрайды', 0, 458, NULL, NULL),
(1732, '4) кемінде 30 минутты құрайды', 0, 458, NULL, NULL),
(1733, '1) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 459, NULL, NULL),
(1734, '2) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 459, NULL, NULL),
(1735, '3) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау және қадағалау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 459, NULL, NULL),
(1736, '4) ҚР 06.01.2011 ж «ҚР мемлекеттік бақылау» Заңына сәйкес жүргізілетін тексерулер барысында халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы мемлекеттік орган ведомствосының аумақтық бөлімшелерінің лауазымды тұлғалары тексереді', 0, 459, NULL, NULL),
(1737, '1) әскери билет', 0, 460, NULL, NULL),
(1738, '2) жеке медициналық кітапша', 0, 460, NULL, NULL),
(1739, '3) санитарлық кітапша', 0, 460, NULL, NULL),
(1740, '4) барлық жауап дұрыс', 0, 460, NULL, NULL),
(1741, '1) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі жылына екі рет кезеңділігімен жүргізіледі', 0, 461, NULL, NULL),
(1742, '2) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі екі жылда бір рет кезеңділігімен жүргізіледі', 0, 461, NULL, NULL),
(1743, '3) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі жылына бір рет кезеңділігімен жүргізіледі', 0, 461, NULL, NULL),
(1744, '4) Халықтың декреттелген тобын гигиеналық оқыту және аттестаттау (емтихан) жұмысқа тұру кезінде және одан әрі үш жылда бір рет кезеңділігімен жүргізіледі', 0, 461, NULL, NULL),
(1745, '1) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді күтіп ұстауға, пайдалануға және орналастыруға қойылатын гигиеналық және санитариялық-эпидемиологиялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 462, NULL, NULL),
(1746, '2) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді пайдалануға қойылатын гигиеналық және санитариялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 462, NULL, NULL),
(1747, '3) халықтың декреттелген тобын инфекциялық аурулардың алдын алуға, объектілерді күтіп ұстауға және орналастыруға қойылатын гигиеналық және эпидемиологиялық талаптарды, білім алушылардың кәсіптеріне сәйкес жеке және қоғамдық гигиенаны сақтауға оқыту.', 0, 462, NULL, NULL),
(1748, '4) барлық жауап дұрыс', 0, 462, NULL, NULL),
(1749, '1) 1,4 м биіктікте', 0, 463, NULL, NULL),
(1750, '2) 1,5 м биіктікте', 0, 463, NULL, NULL),
(1751, '3) 1,3 м биіктікте', 0, 463, NULL, NULL),
(1752, '4) 1,6 м биіктікте', 0, 463, NULL, NULL),
(1753, '1) халықтың декреттелген тобы дербес көтереді немесе объектінің басшысы', 0, 464, NULL, NULL),
(1754, '2) халықтың декреттелген тобы дербес көтереді немесе тараптардың келісімі бойынша гигиеналық оқыту шығыстарын объектінің басшысы', 0, 464, NULL, NULL),
(1755, '3) тараптардың келісімі бойынша гигиеналық оқыту шығыстарын объектінің басшысы', 0, 464, NULL, NULL),
(1756, '4) барлық жауап дұрыс', 0, 464, NULL, NULL),
(1757, '1) 5 минутты құрайды', 0, 465, NULL, NULL),
(1758, '2) 10 минутты құрайды', 0, 465, NULL, NULL),
(1759, '3) 30 минутты құрайды', 0, 465, NULL, NULL),
(1760, '4) 15 минутты құрайды', 0, 465, NULL, NULL),
(1761, '1) 1600 АЕК', 0, 466, NULL, NULL),
(1762, '2) 30 АЕК', 0, 466, NULL, NULL),
(1763, '3) 230 АЕК', 0, 466, NULL, NULL),
(1764, '4) 310 АЕК', 0, 466, NULL, NULL),
(1765, '1) 1600 АЕК', 0, 467, NULL, NULL),
(1766, '2) 30 АЕК', 0, 467, NULL, NULL),
(1767, '3) 2000 АЕК', 0, 467, NULL, NULL),
(1768, '4) 310 АЕК', 0, 467, NULL, NULL),
(1769, '1) 30 минут үзіліс көзделеді', 0, 468, NULL, NULL),
(1770, '2) 50 минут үзіліс көзделеді', 0, 468, NULL, NULL),
(1771, '3) 40 минут үзіліс көзделеді', 0, 468, NULL, NULL),
(1772, '4) 20 минут үзіліс көзделеді', 0, 468, NULL, NULL),
(1773, '1) +2С тан +6С дейін', 0, 469, NULL, NULL),
(1774, '2) +1С тан +5С дейін', 0, 469, NULL, NULL),
(1775, '3) +3С тан +7С дейін', 0, 469, NULL, NULL),
(1776, '4) барлық жауап дұрыс', 0, 469, NULL, NULL),
(1777, '1) -18 °С аспайтын кезде ұйымдастыру', 0, 470, NULL, NULL),
(1778, '2) -19 °С аспайтын кезде ұйымдастыру ', 0, 470, NULL, NULL),
(1779, '3) -17 °С аспайтын кезде ұйымдастыру', 0, 470, NULL, NULL),
(1780, '4) барлық жауап дұрыс', 0, 470, NULL, NULL),
(1781, '1) 2 рет жүргізіледі', 0, 471, NULL, NULL),
(1782, '2) 1 рет жүргізіледі', 0, 471, NULL, NULL),
(1783, '3) 3 рет жүргізіледі', 0, 471, NULL, NULL),
(1784, '4) 4 рет жүргізіледі', 0, 471, NULL, NULL),
(1785, '1) Статья 423 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 472, NULL, NULL),
(1786, '2) Статья 425 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 472, NULL, NULL),
(1787, '3) Статья 424 КоАП РК «Нарушение требований законодательства в области санитарно-эпидемиологического благополучия населения, а также гигиенических нормативов»', 0, 472, NULL, NULL),
(1788, '4) все ответы верны', 0, 472, NULL, NULL),
(1789, '1) не менее 15 минут', 0, 473, NULL, NULL),
(1790, '2) не менее 20 минут', 0, 473, NULL, NULL),
(1791, '3) не менее 5 минут', 0, 473, NULL, NULL),
(1792, '4) все ответы верны', 0, 473, NULL, NULL),
(1793, '1) должностными лицами территориального подразделения ведомства государственного органа в сфере эпидемиологического контроля населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 474, NULL, NULL),
(1794, '2) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарного благополучия населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 474, NULL, NULL),
(1795, '3) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарно-эпидемиологического благополучия населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 474, NULL, NULL),
(1796, '4) должностными лицами территориального подразделения ведомства государственного органа в сфере санитарно-эпидемиологического контроля населения в ходе проверок, проводимых в соответствии с Законом РК от 06.01.2011 г \"О государственном контроле и надзоре в РК\", и отражается в акте санитарно-эпидемиологического обследования.', 0, 474, NULL, NULL),
(1797, '1) военный билет;', 0, 475, NULL, NULL),
(1798, '2) личная медицинская книжка;', 0, 475, NULL, NULL),
(1799, '3) санитарная книжка;', 0, 475, NULL, NULL),
(1800, '4) все ответы верны;', 0, 475, NULL, NULL),
(1801, '1) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в год', 0, 476, NULL, NULL),
(1802, '2) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в два года', 0, 476, NULL, NULL),
(1803, '3) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в пол год', 0, 476, NULL, NULL),
(1804, '4) Гигиеническое обучение и аттестация (экзамен) декретированной группы населения проводится при поступлении на работу и в дальнейшем с периодичностью один раз в три года.', 0, 476, NULL, NULL),
(1805, '1) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению личной гигиены в соответствии с профессиями обучающихся;', 0, 477, NULL, NULL),
(1806, '2) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению личной и общественной гигиены в соответствии с профессиями обучающихся;', 0, 477, NULL, NULL),
(1807, '3) обучение декретированных групп населения профилактике инфекционных заболеваний, гигиеническим и санитарно-эпидемиологическим требованиям к содержанию, эксплуатации и размещению объектов, соблюдению общественной гигиены;', 0, 477, NULL, NULL),
(1808, '4) все ответы верны', 0, 477, NULL, NULL),
(1809, '1) менее 1,8 м', 0, 478, NULL, NULL),
(1810, '2) не менее 1,8 м', 0, 478, NULL, NULL),
(1811, '3) более 1,5 м', 0, 478, NULL, NULL),
(1812, '4) не менее 1,5 м', 0, 478, NULL, NULL),
(1813, '1) самостоятельно, либо по соглашению сторон расходы на гигиеническое обучение могут быть понесены руководителем объекта.', 0, 479, NULL, NULL),
(1814, '2) самостоятельно, либо без соглашения сторон расходы на гигиеническое обучение могут быть понесены руководителем объекта.', 0, 479, NULL, NULL),
(1815, '3) самостоятельно, либо по соглашению сторон расходы на гигиеническое обучение не могут быть понесены руководителем объекта.', 0, 479, NULL, NULL),
(1816, '4) все ответы верны', 0, 479, NULL, NULL),
(1817, '1) 15 минут', 0, 480, NULL, NULL),
(1818, '2) 20 минут', 0, 480, NULL, NULL),
(1819, '3) 30 минут', 0, 480, NULL, NULL),
(1820, '4) все ответы верны', 0, 480, NULL, NULL),
(1821, '1) 30 МРП', 0, 481, NULL, NULL),
(1822, '2) 230 МРП', 0, 481, NULL, NULL),
(1823, '3) 200 МРП', 0, 481, NULL, NULL),
(1824, '4) 310 МРП', 0, 481, NULL, NULL),
(1825, '1) 420 МРП', 0, 482, NULL, NULL),
(1826, '2) 2000 МРП', 0, 482, NULL, NULL),
(1827, '3) 310 МРП', 0, 482, NULL, NULL),
(1828, '4) 1600 МРП', 0, 482, NULL, NULL),
(1829, '1) 2,5 – 3 часов', 0, 483, NULL, NULL),
(1830, '2) 1,5 – 2 часов', 0, 483, NULL, NULL),
(1831, '3) 3,5 – 4 часов', 0, 483, NULL, NULL),
(1832, '4) все ответы верны', 0, 483, NULL, NULL),
(1833, '1) от +2С до +6С.', 0, 484, NULL, NULL),
(1834, '2) от +1С до +5С.', 0, 484, NULL, NULL),
(1835, '3) от +3С до +7С.', 0, 484, NULL, NULL),
(1836, '4) все ответы верны', 0, 484, NULL, NULL),
(1837, '1) не более 18°С', 0, 485, NULL, NULL),
(1838, '2) не более 19°С', 0, 485, NULL, NULL),
(1839, '3) не более 17°С', 0, 485, NULL, NULL),
(1840, '4) не более 16°С', 0, 485, NULL, NULL),
(1841, '1) не реже 1 раза в неделю', 0, 486, NULL, NULL),
(1842, '2) не реже 2 раз в неделю', 0, 486, NULL, NULL),
(1843, '3) не реже 3 раз в неделю', 0, 486, NULL, NULL),
(1844, '4) все ответы верны', 0, 486, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `organization_blocks`
--

CREATE TABLE `organization_blocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `percent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `info1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `info2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `organization_blocks`
--

INSERT INTO `organization_blocks` (`id`, `title`, `image`, `percent`, `info1`, `info2`, `created_at`, `updated_at`) VALUES
(1, 'Промышленность', 'organization-blocks\\January2021\\GTZ0NrwzFuSneQpv3VWi.png', '10', '12 организаций', '107 участников', '2021-01-08 05:35:13', '2021-01-20 00:57:37'),
(2, 'Рынки', 'organization-blocks\\January2021\\kvyCPD9tE41X4seAHGjG.png', '97', '5 организаций', '89 участников', '2021-01-20 00:59:02', '2021-01-20 00:59:02'),
(3, 'Банки', 'organization-blocks\\January2021\\GjrlrPHfq6UuNg7QHiHj.png', '10', '5 организаций', '52 участников', '2021-01-20 00:59:45', '2021-01-20 00:59:45'),
(4, 'Университеты', 'organization-blocks\\January2021\\5TmjoLpabeDK3G7Ij6U8.png', '98', '41 организаций', '389 участников', '2021-01-20 01:00:42', '2021-01-20 01:00:42'),
(5, 'Рестораны', 'organization-blocks\\January2021\\8k0ZMI77eLcGVfCPzuOy.png', '30', '251 организаций', '256 участников', '2021-01-20 01:01:03', '2021-01-20 01:01:15'),
(6, 'АЗС', 'organization-blocks\\January2021\\fZlFT8EdnuTLO6WjxnTd.png', '46', '13 организаций', '41 участников', '2021-01-20 01:01:48', '2021-01-20 01:01:48'),
(7, 'Здравоохранение', 'organization-blocks\\January2021\\Db4AagrDP49n4TkPGBKT.png', '97', '122 организаций', '653 участников', '2021-01-20 01:02:17', '2021-01-20 01:02:50'),
(8, 'Образование', 'organization-blocks\\January2021\\Ufs9bKkKyGsawRNV1Cai.png', '99', '400 организаций', '451 участников', '2021-01-20 01:03:24', '2021-01-20 01:03:24');

-- --------------------------------------------------------

--
-- Структура таблицы `org_sliders`
--

CREATE TABLE `org_sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `org_sliders`
--

INSERT INTO `org_sliders` (`id`, `image`, `created_at`, `updated_at`) VALUES
(1, 'org-sliders\\January2021\\useAWyMLdVNXaGu12OWj.png', '2021-01-11 00:39:23', '2021-01-11 00:39:23'),
(3, 'org-sliders\\January2021\\2uUPF3ErJRQWvM6IPPd6.png', '2021-01-11 00:39:53', '2021-01-11 00:39:53'),
(4, 'org-sliders\\January2021\\Jj4Fh40Alr5ydfUP1NH0.png', '2021-01-11 00:40:04', '2021-01-11 00:40:04'),
(5, 'org-sliders\\January2021\\68AD9mWojqRAQiz2Cluc.png', '2021-01-11 00:40:16', '2021-01-11 00:40:16'),
(6, 'org-sliders\\January2021\\mUtEeQ5zb6ErH7gkWu9E.png', '2021-01-20 01:05:44', '2021-01-20 01:05:44'),
(7, 'org-sliders\\January2021\\KW3USTBN3xLP5Y4Am7n6.png', '2021-01-20 01:06:02', '2021-01-20 01:06:02'),
(8, 'org-sliders\\January2021\\gPl3gegicm4e30stmed8.png', '2021-01-20 01:06:28', '2021-01-20 01:06:28'),
(9, 'org-sliders\\January2021\\3b5WCOMJRxCxRwx3oMw9.png', '2021-01-20 01:06:43', '2021-01-20 01:06:43');

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'browse_admin', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(2, 'browse_bread', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(3, 'browse_database', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(4, 'browse_media', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(5, 'browse_compass', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(6, 'browse_menus', 'menus', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(7, 'read_menus', 'menus', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(8, 'edit_menus', 'menus', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(9, 'add_menus', 'menus', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(10, 'delete_menus', 'menus', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(11, 'browse_roles', 'roles', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(12, 'read_roles', 'roles', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(13, 'edit_roles', 'roles', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(14, 'add_roles', 'roles', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(15, 'delete_roles', 'roles', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(16, 'browse_users', 'users', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(17, 'read_users', 'users', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(18, 'edit_users', 'users', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(19, 'add_users', 'users', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(20, 'delete_users', 'users', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(21, 'browse_settings', 'settings', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(22, 'read_settings', 'settings', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(23, 'edit_settings', 'settings', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(24, 'add_settings', 'settings', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(25, 'delete_settings', 'settings', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(26, 'browse_hooks', NULL, '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(27, 'browse_community_blocks', 'community_blocks', '2021-01-08 04:29:00', '2021-01-08 04:29:00'),
(28, 'read_community_blocks', 'community_blocks', '2021-01-08 04:29:00', '2021-01-08 04:29:00'),
(29, 'edit_community_blocks', 'community_blocks', '2021-01-08 04:29:00', '2021-01-08 04:29:00'),
(30, 'add_community_blocks', 'community_blocks', '2021-01-08 04:29:00', '2021-01-08 04:29:00'),
(31, 'delete_community_blocks', 'community_blocks', '2021-01-08 04:29:00', '2021-01-08 04:29:00'),
(32, 'browse_header_slides', 'header_slides', '2021-01-08 04:30:58', '2021-01-08 04:30:58'),
(33, 'read_header_slides', 'header_slides', '2021-01-08 04:30:58', '2021-01-08 04:30:58'),
(34, 'edit_header_slides', 'header_slides', '2021-01-08 04:30:58', '2021-01-08 04:30:58'),
(35, 'add_header_slides', 'header_slides', '2021-01-08 04:30:58', '2021-01-08 04:30:58'),
(36, 'delete_header_slides', 'header_slides', '2021-01-08 04:30:58', '2021-01-08 04:30:58'),
(37, 'browse_organization_blocks', 'organization_blocks', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(38, 'read_organization_blocks', 'organization_blocks', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(39, 'edit_organization_blocks', 'organization_blocks', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(40, 'add_organization_blocks', 'organization_blocks', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(41, 'delete_organization_blocks', 'organization_blocks', '2021-01-08 04:32:31', '2021-01-08 04:32:31'),
(42, 'browse_articles', 'articles', '2021-01-08 11:19:12', '2021-01-08 11:19:12'),
(43, 'read_articles', 'articles', '2021-01-08 11:19:12', '2021-01-08 11:19:12'),
(44, 'edit_articles', 'articles', '2021-01-08 11:19:12', '2021-01-08 11:19:12'),
(45, 'add_articles', 'articles', '2021-01-08 11:19:12', '2021-01-08 11:19:12'),
(46, 'delete_articles', 'articles', '2021-01-08 11:19:12', '2021-01-08 11:19:12'),
(47, 'browse_courses', 'courses', '2021-01-08 11:20:11', '2021-01-08 11:20:11'),
(48, 'read_courses', 'courses', '2021-01-08 11:20:11', '2021-01-08 11:20:11'),
(49, 'edit_courses', 'courses', '2021-01-08 11:20:11', '2021-01-08 11:20:11'),
(50, 'add_courses', 'courses', '2021-01-08 11:20:11', '2021-01-08 11:20:11'),
(51, 'delete_courses', 'courses', '2021-01-08 11:20:11', '2021-01-08 11:20:11'),
(52, 'browse_materials', 'materials', '2021-01-08 11:21:35', '2021-01-08 11:21:35'),
(53, 'read_materials', 'materials', '2021-01-08 11:21:35', '2021-01-08 11:21:35'),
(54, 'edit_materials', 'materials', '2021-01-08 11:21:35', '2021-01-08 11:21:35'),
(55, 'add_materials', 'materials', '2021-01-08 11:21:35', '2021-01-08 11:21:35'),
(56, 'delete_materials', 'materials', '2021-01-08 11:21:35', '2021-01-08 11:21:35'),
(57, 'browse_options', 'options', '2021-01-08 11:34:13', '2021-01-08 11:34:13'),
(58, 'read_options', 'options', '2021-01-08 11:34:13', '2021-01-08 11:34:13'),
(59, 'edit_options', 'options', '2021-01-08 11:34:13', '2021-01-08 11:34:13'),
(60, 'add_options', 'options', '2021-01-08 11:34:13', '2021-01-08 11:34:13'),
(61, 'delete_options', 'options', '2021-01-08 11:34:13', '2021-01-08 11:34:13'),
(62, 'browse_questions', 'questions', '2021-01-08 11:36:38', '2021-01-08 11:36:38'),
(63, 'read_questions', 'questions', '2021-01-08 11:36:38', '2021-01-08 11:36:38'),
(64, 'edit_questions', 'questions', '2021-01-08 11:36:38', '2021-01-08 11:36:38'),
(65, 'add_questions', 'questions', '2021-01-08 11:36:38', '2021-01-08 11:36:38'),
(66, 'delete_questions', 'questions', '2021-01-08 11:36:38', '2021-01-08 11:36:38'),
(67, 'browse_tests', 'tests', '2021-01-08 11:38:01', '2021-01-08 11:38:01'),
(68, 'read_tests', 'tests', '2021-01-08 11:38:01', '2021-01-08 11:38:01'),
(69, 'edit_tests', 'tests', '2021-01-08 11:38:01', '2021-01-08 11:38:01'),
(70, 'add_tests', 'tests', '2021-01-08 11:38:01', '2021-01-08 11:38:01'),
(71, 'delete_tests', 'tests', '2021-01-08 11:38:01', '2021-01-08 11:38:01'),
(72, 'browse_vacancies', 'vacancies', '2021-01-08 11:40:11', '2021-01-08 11:40:11'),
(73, 'read_vacancies', 'vacancies', '2021-01-08 11:40:11', '2021-01-08 11:40:11'),
(74, 'edit_vacancies', 'vacancies', '2021-01-08 11:40:11', '2021-01-08 11:40:11'),
(75, 'add_vacancies', 'vacancies', '2021-01-08 11:40:11', '2021-01-08 11:40:11'),
(76, 'delete_vacancies', 'vacancies', '2021-01-08 11:40:11', '2021-01-08 11:40:11'),
(77, 'browse_org_sliders', 'org_sliders', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(78, 'read_org_sliders', 'org_sliders', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(79, 'edit_org_sliders', 'org_sliders', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(80, 'add_org_sliders', 'org_sliders', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(81, 'delete_org_sliders', 'org_sliders', '2021-01-11 00:34:03', '2021-01-11 00:34:03'),
(82, 'browse_course_codes', 'course_codes', '2021-01-11 02:00:34', '2021-01-11 02:00:34'),
(83, 'read_course_codes', 'course_codes', '2021-01-11 02:00:34', '2021-01-11 02:00:34'),
(84, 'edit_course_codes', 'course_codes', '2021-01-11 02:00:34', '2021-01-11 02:00:34'),
(85, 'add_course_codes', 'course_codes', '2021-01-11 02:00:34', '2021-01-11 02:00:34'),
(86, 'delete_course_codes', 'course_codes', '2021-01-11 02:00:34', '2021-01-11 02:00:34'),
(87, 'browse_bids', 'bids', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(88, 'read_bids', 'bids', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(89, 'edit_bids', 'bids', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(90, 'add_bids', 'bids', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(91, 'delete_bids', 'bids', '2021-01-18 06:40:24', '2021-01-18 06:40:24'),
(92, 'browse_vacancy_bids', 'vacancy_bids', '2021-01-20 04:59:14', '2021-01-20 04:59:14'),
(93, 'read_vacancy_bids', 'vacancy_bids', '2021-01-20 04:59:14', '2021-01-20 04:59:14'),
(94, 'edit_vacancy_bids', 'vacancy_bids', '2021-01-20 04:59:14', '2021-01-20 04:59:14'),
(95, 'add_vacancy_bids', 'vacancy_bids', '2021-01-20 04:59:14', '2021-01-20 04:59:14'),
(96, 'delete_vacancy_bids', 'vacancy_bids', '2021-01-20 04:59:14', '2021-01-20 04:59:14');

-- --------------------------------------------------------

--
-- Структура таблицы `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(87, 1),
(88, 1),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `questions`
--

INSERT INTO `questions` (`id`, `body`, `test_id`, `created_at`, `updated_at`) VALUES
(4, 'В каком из перечисленных случаев внеплановый противопожарный инструктаж не проводится?', 2, '2021-01-12 01:07:09', '2021-01-12 01:07:09'),
(5, 'За счет каких средств проводятся обучения, инструктирование, проверка знаний работников по вопросам безопасности и охраны труда?', 2, '2021-01-12 01:09:21', '2021-01-12 01:09:21'),
(6, 'Какова периодичность прохождения повторного инструктажа по безопасности и охране труда работниками независимо от квалификации, образования, стажа, характера выполняемой работы?', 2, '2021-01-12 01:09:36', '2021-01-12 01:09:36'),
(7, 'С какой периодичностью проводится обучение пожарно-техническому минимуму руководителей, специалистов и работников организаций, не связанных со взрывопожароопасным производством?', 2, '2021-01-12 01:09:49', '2021-01-12 01:09:49'),
(8, 'Кто несет персональную ответственность за соблюдение требований пожарной безопасности в организации?', 2, '2021-01-12 01:10:06', '2021-01-12 01:10:06'),
(9, 'Терроризм дегеніміз не?', 1, '2021-01-21 00:01:32', '2021-01-21 00:01:32'),
(10, 'Жарылғыш затқа ұқсас күдікті затттарға тыйым салынады:', 1, '2021-01-21 00:01:46', '2021-01-21 00:01:46'),
(11, 'Егер сізді кепілдікке алса, жасайтын әрекеттер...', 1, '2021-01-21 00:02:02', '2021-01-21 00:02:02'),
(12, 'Жарылғыш заттың орналасқаны жайында жалған ақпарат таратуға жаза:', 1, '2021-01-21 00:02:34', '2021-01-21 00:02:34'),
(13, 'Қандай жағдайда террористік қауіптіліктің Сыни «қызыл» деңгейі анықталды:', 1, '2021-01-21 00:02:46', '2021-01-21 00:02:46'),
(14, 'Террористік тұрғыдан осал нысандардың иелері, басшылары немесе басқа лауазымды\r\nтұлғалардың міндеттері', 1, '2021-01-21 00:02:57', '2021-01-21 00:02:57'),
(15, 'Жедел штабтар:', 1, '2021-01-21 00:03:09', '2021-01-21 00:03:09'),
(16, 'Терроризмге қарсы операцияны...', 1, '2021-01-21 00:03:23', '2021-01-21 00:03:23'),
(17, 'Нысанға жарылғыш зат қою қаупі туралы ақпаратты телефон арқылы алған кезде', 1, '2021-01-21 00:03:36', '2021-01-21 00:03:36'),
(18, 'ҚР терроризмге қарсы орталығы туралы ереже және терроризмге қарсы комиссиялар\r\nтуралы үлгі ереже кіммен бекітіледі', 1, '2021-01-21 00:03:51', '2021-01-21 00:03:51'),
(19, 'ҚР 08.28.2013 ж № 876 Үкіметінің қаулысы:', 1, '2021-01-21 00:04:03', '2021-01-21 00:04:03'),
(20, 'ҚР террористік тұрғыдан осал нысандарының тізіміне кіреді:', 1, '2021-01-21 00:04:23', '2021-01-21 00:04:23'),
(21, 'Стратегиялық нысандар', 1, '2021-01-21 00:04:34', '2021-01-21 00:04:34'),
(22, 'Қоғамдық тәртіпті бұзуға немесе азаматтардың немесе ұйымдардың құқықтары мен заңды\r\nмүдделеріне немесе қоғамның немесе заңмен қорғалатын мемлекеттің мүдделеріне елеулі зиян келтіретін\r\nқауіп тудыратын көрінеу жалған ақпарат тарату', 1, '2021-01-21 00:04:46', '2021-01-21 00:04:46'),
(23, 'Қоғамдық тәртіпті бұзу немесе азаматтардың немесе ұйымдардың құқықтары мен заңды\r\nмүдделеріне немесе қоғамның немесе заңмен қорғалатын мемлекеттің мүдделеріне елеулі зиян келтіру\r\nқаупін туғызатын көрінеу жалған ақпарат таратқаны үшін қандай мөлшерде айыппұл салынады:', 1, '2021-01-21 00:04:58', '2021-01-21 00:04:58'),
(24, 'Терроризм – это:', 3, NULL, NULL),
(25, 'Подозрительный предмет, похожий на взрывное устройство, категорически запрещается:', 3, NULL, NULL),
(26, 'При захвате вас в заложники рекомендуется:', 3, NULL, NULL),
(27, 'Заведомо ложное сообщение об акте терроризма предусматривает наказание в виде:', 3, NULL, NULL),
(28, 'Критический («красный») уровень террористической опасности устанавливается:', 3, NULL, NULL),
(29, 'Обязанности собственников, руководителей или иных должностных лиц объектов, УТО:', 3, NULL, NULL),
(30, 'Оперативные штабы:', 3, NULL, NULL),
(31, 'Руководство антитеррористической операцией:', 3, NULL, NULL),
(32, 'При получении по телефону сообщения об угрозе минирования объекта:', 3, NULL, NULL),
(33, 'Положение об Антитеррористическом центре Республики Казахстан и типовое положение об\nантитеррористических комиссиях утверждаются:', 3, NULL, NULL),
(34, 'Постановление Правительства РК от 28.08.2013 года № 876:', 3, NULL, NULL),
(35, 'Перечень объектов РК, уязвимых в террористическом отношении:', 3, NULL, NULL),
(36, 'Стратегические объекты:', 3, NULL, NULL),
(37, 'Распространение заведомо ложной информации, создающей опасность нарушения\nобщественного порядка или причинения существенного вреда правам и законным интересам граждан\nили организаций либо охраняемым законом интересам общества или государства:', 3, NULL, NULL),
(38, 'За распространение заведомо ложной информации, создающей опасность нарушения\nобщественного порядка или причинения существенного вреда правам и законным интересам граждан\nили организаций либо охраняемым законом интересам общества или государства наказывается штрафом\nв размере:', 3, NULL, NULL),
(39, '«Охрана труда»:', 4, NULL, NULL),
(40, 'Травма – это:', 4, NULL, NULL),
(41, 'Опасные и вредные производственные факторы относятся к физическим:', 4, NULL, NULL),
(42, 'Опасные и вредные производственные факторы относятся к психофизиологическим их:', 4, NULL, NULL),
(43, 'Дать определение коэффициента тяжести травматизма:', 4, NULL, NULL),
(44, 'Имеет право налагать штраф на предприятие за нарушение нормативных актов по охране труда:', 4, NULL, NULL),
(45, 'Что понимают под управлением охраной труда:', 4, NULL, NULL),
(46, 'Служба охраны труда создается:', 4, NULL, NULL),
(47, 'Служба охраны труда функционирует как самостоятельное подразделение при численности работающих на\nпредприятии производственной сферы:', 4, NULL, NULL),
(48, 'Служба охраны труда комплектуется:', 4, NULL, NULL),
(49, 'Ненормированный рабочий день – это:', 4, NULL, NULL),
(50, 'Юрисконсульт предприятия:', 4, NULL, NULL),
(51, 'Непрерывный контроль за безопасностью труда на предприятии обеспечивает, занимается организацией и\nкоординацией работы по охране труда:', 4, NULL, NULL),
(52, 'Проводит и регистрирует повторный инструктаж:', 4, NULL, NULL),
(53, 'В состав комиссии по расследованию простого несчастного случая на предприятии входят:', 4, NULL, NULL),
(54, 'Еңбекті қорғау:', 5, NULL, NULL),
(55, 'Жарақат дегеніміз:', 5, NULL, NULL),
(56, 'Қауіпті және зиянды өндірістік факторлар:', 5, NULL, NULL),
(57, 'Қауіпті және зиянды өндірістік факторлар олардың психофизиологиялық ерекшеліктеріне жатады', 5, NULL, NULL),
(58, 'Жарақаттың ауырлық коэффициентін анықтаңыз', 5, NULL, NULL),
(59, 'Еңбекті қорғау ережелерін бұзғаны үшін кәсіпорынға айыппұл салуға құқылы', 5, NULL, NULL),
(60, 'Еңбекті қорғауды басқару нені білдіреді?', 5, NULL, NULL),
(61, 'Еңбекті қорғау қызметі құрылады:', 5, NULL, NULL),
(62, 'Еңбекті қорғау қызметі өндірістік сектордағы жұмысшылар саны бар тәуелсіз бөлімше ретінде жұмыс\nістейді:', 5, NULL, NULL),
(63, 'Еңбекті қорғау қызметі жабдықталады:', 5, NULL, NULL),
(64, 'Жүйесіз жұмыс уақыты:', 5, NULL, NULL),
(65, 'Кәсіпорынның заңгер кеңесшісі', 5, NULL, NULL),
(66, 'Кәсіпорындағы еңбек қауіпсіздігінің тұрақты бақылау еңбекті қорғау бойынша жұмысты қамтамасыз етеді,\nұйымдастырады және үйлестіреді', 5, NULL, NULL),
(67, 'Қайта нұсқаманы жүргізеді және тіркейді', 5, NULL, NULL),
(68, 'Кәсіпорындағы қарапайым жазатайым оқиғаны тергеу жөніндегі комиссия құрамына:', 5, NULL, NULL),
(69, 'Когда был принят Кодекс Республики Казахстан «О здоровье народа и системе здравоохранения»:', 6, NULL, NULL),
(70, 'Первая помощь – это…', 6, NULL, NULL),
(71, 'Для проведения базовой реанимации пострадавший:', 6, NULL, NULL),
(72, 'Для искусственного дыхания:', 6, NULL, NULL),
(73, 'Когда делается базовая реанимация:', 6, NULL, NULL),
(74, 'Сколько делается компрессий во время СЛР:', 6, NULL, NULL),
(75, 'Первая помощь при артериальном кровотечении (если повреждена кисть):', 6, NULL, NULL),
(76, 'Первая помощь при венозном кровотечении:', 6, NULL, NULL),
(77, 'Действия при закрытой травме:', 6, NULL, NULL),
(78, 'Действия при открытой травме:', 6, NULL, NULL),
(79, 'Как делается транспортировка пострадавшего', 6, NULL, NULL),
(80, 'Как делается транспортировка пострадавшего при травме позвоночника:', 6, NULL, NULL),
(81, 'Если имеются покраснения, отеки, пузыри от ожога, то необходимо:', 6, NULL, NULL),
(82, 'Если на коже имеются корочки серого или черного цвета от ожога, то необходимо:', 6, NULL, NULL),
(83, 'При обморожении запрещается:', 6, NULL, NULL),
(84, 'Қазақстан Республикасының «Адамдардың денсаулығы және денсаулық сақтау жүйесі туралы»\nКодексі қашан қабылданды:', 7, NULL, NULL),
(85, 'Алғашқы көмек:', 7, NULL, NULL),
(86, 'Негізгі реанимация үшін зардап шегуші:', 7, NULL, NULL),
(87, 'Жасанды тыныс жасау үшін:', 7, NULL, NULL),
(88, 'Негізгі реанимация қашан жасалады:', 7, NULL, NULL),
(89, 'Жүрек-өкпе реанимациясы кезінде қанша компрессия жасалады:', 7, NULL, NULL),
(90, 'Артериялық қан кеткенде алғашқы көмек (егер қол зақымдалған болса):', 7, NULL, NULL),
(91, 'Тамырдан қан кеткенде алғашқы көмек:', 7, NULL, NULL),
(92, 'Жабық жарақат алу кезіндегі көмек:', 7, NULL, NULL),
(93, 'Ашық жарақат алу кезіндегі көмек (егер қан кетсе):', 7, NULL, NULL),
(94, 'Зардап шегуші ес-түссіз жағдайда тасымалдау қалай жүреді:', 7, NULL, NULL),
(95, 'Омыртқа жарақатымен зардап шеккен адамды тасымалдау қалай жүзеге асырылады:', 7, NULL, NULL),
(96, 'Егер күйіп қалудан қызару, ісіну, көпіршіктер болса, онда бұл қажет:', 7, NULL, NULL),
(97, 'Егер күйік кезінде теріде сұр немесе қара қабықтар болса, онда бұл қажет:', 7, NULL, NULL),
(98, 'Үсіген кезде тыйым салынады:', 7, NULL, NULL),
(99, 'Реестр добровольных противопожарных формировании ведется:', 8, NULL, NULL),
(100, 'В систему обеспечения пожарной безопасности входит:', 8, NULL, NULL),
(101, 'Какое из нижеследующих определений пожара дано Законом РК «О пожарной\nбезопасности»:', 8, NULL, NULL),
(102, 'Какое из нижеследующих определений добровольного пожарного дано Законом РК «О\nпожарной безопасности»:', 8, NULL, NULL),
(103, 'Какое из нижеследующих определений селитебной территории верно:', 8, NULL, NULL),
(104, 'Добровольные противопожарные формирования:', 8, NULL, NULL),
(105, 'Противопожарная служба - это:', 8, NULL, NULL),
(106, 'Первоочередные аварийно-спасательные работы', 8, NULL, NULL),
(107, 'Негосударственная противопожарная служба:', 8, NULL, NULL),
(108, 'Перечень организаций и объектов, на которых в обязательном порядке создается\nпротивопожарная служба, утверждается:', 8, NULL, NULL),
(109, 'На работу в негосударственную противопожарную службу могут быть приняты:', 8, NULL, NULL),
(110, 'Тушение пожаров - это:', 8, NULL, NULL),
(111, 'Какой из перечисленных принципов относится к обеспечению пожарной безопасности:', 8, NULL, NULL),
(112, 'В случае привлечения органов государственной противопожарной службы к тушению\nпожаров в организациях н на объектах, на которых в обязательном порядке создается\nпротивопожарная служба, возмещение затрат:', 8, NULL, NULL),
(113, 'Выезд подразделений противопожарной службы на тушение пожаров н участие в их\nликвидации осуществляется:', 8, NULL, NULL),
(114, 'Ерікті өрт сөндіру құрлымдарын тіркеуді кім жүргізеді?', 9, NULL, NULL),
(115, 'Өрт қауіпсіздігі жүйесінің құрамына кіреді', 9, NULL, NULL),
(116, 'Төмендегі «өрт» анықтамаларының қайсысы «Өрт қауіпсіздігі туралы» ҚР Заңымен көрсетілген', 9, NULL, NULL),
(117, 'Ерікті өрт сөндірушінің келесі анықтамаларының қайсысы «Өрт қауіпсіздігі туралы» ҚР\nкөрсетілген.', 9, NULL, NULL),
(118, 'Төмендегі анықтамалардың қайсысы дұрыс?', 9, NULL, NULL),
(119, 'Ерікті өрт сөндіру құрылымдары:', 9, NULL, NULL),
(120, 'Өрт қызметі:', 9, NULL, NULL),
(121, 'Өрт сөндіруге байланысты төтенше жағдай', 9, NULL, NULL),
(122, 'Мемлекеттік емес өртке қарсы қызмет', 9, NULL, NULL),
(123, 'Өрт сөндіру қызметі міндетті түрде құрылатын ұйымдар мен объектілердің тізімі бекітілді', 9, NULL, NULL),
(124, 'Мемлекеттік емес өртке қарсы қызметке жұмысқа қабылдануға болады', 9, NULL, NULL),
(125, 'Өрт сөндіру', 9, NULL, NULL),
(126, 'Төмендегі қағидалардың қайсысы өрт қауіпсіздігін қамтамасыз етуге қолданылады', 9, NULL, NULL),
(127, 'Өртке қарсы қызмет міндетті болып табылатын ұйымдардағы және объектілердегі өрттерді\nсөндіруге мемлекеттік өртке қарсы қызмет тартылған жағдайда, шығындарды өтеу', 9, NULL, NULL),
(128, 'Өрт сөндіруге өрт сөндіру бөлімшелерінің кетуі және оларды жоюға қатысуы жүзеге асырылады', 9, NULL, NULL),
(129, 'Халықтың декреттелген тобын гигиеналық оқыту:', 10, NULL, NULL),
(130, 'Халықтың декреттелген тобындағы адамдарды гигиеналық оқыту қағидалары сәйкес әзірленген:', 10, NULL, NULL),
(131, 'ҚР ДСМ 12.04.2018 ж №168 бұйрығы:', 10, NULL, NULL),
(132, 'Халықтың декреттелген тобы:', 10, NULL, NULL),
(133, 'Халықтың декреттелген тобын гигиеналық оқытуды және аттестаттауды жүргізу тәртібі:', 10, NULL, NULL),
(134, 'Гигиеналық оқытудан өтумен байланысты шығыстарды жұмсайды', 10, NULL, NULL),
(135, 'Жеке медициналық кітапша:', 10, NULL, NULL),
(136, 'Гигиеналық оқытудан өткеннен кейін:', 10, NULL, NULL),
(137, 'Халықтың декреттелген топтары адамдарының халықтың санитариялық-эпидемиологиялық\nсаламаттылығы саласындағы ҚР нормативтік құқықтық актілерін және гигиеналық нормативтерін білуін:', 10, NULL, NULL),
(138, 'Қызметкерлердің санитарлық ережелерді және гигиеналық нормативтердің талаптарын сақтамағаны үшін\nжауапкершілігі:', 10, NULL, NULL),
(139, 'Қазақстан Республикасының халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы\nзаңнамасының талаптарын, сондай-ақ гигиеналық нормативтердi, техникалық регламенттерді адам\nденсаулығына зиян келтіруге әкеп соқпаған бұзушылық жеке тұлғаларға:', 10, NULL, NULL),
(140, 'Қазақстан Республикасының халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы\nзаңнамасының талаптарын, сондай-ақ гигиеналық нормативтердi, техникалық регламенттерді адам\nденсаулығына зиян келтіруге әкеп соқпаған бұзушылық орта кәсіпкерлік субъектілеріне:', 10, NULL, NULL),
(141, 'ҚР ДСМ 16.08.2017 ж № 611 бұйрығы:', 10, NULL, NULL),
(142, 'Ылғалды режимде жұмыс істейтін үй-жайлардың қабырғаларын кемінде', 10, NULL, NULL),
(143, 'Жалпы білім беру ұйымдарының барлық түрінде оқушылар үшін сабақтар арасындағы үзілістің ұзақтығы:', 10, NULL, NULL),
(144, 'Гигиеническое обучение декретированной группы населения:', 11, NULL, NULL),
(145, 'Правила гигиенического обучения лиц декретированной группы населения разработаны в соответствии:', 11, NULL, NULL),
(146, 'Приказ МЗ РК от 12.04.2018 г № 168', 11, NULL, NULL),
(147, 'Декретированная группа населения:', 11, NULL, NULL),
(148, 'Порядок проведения гигиенического обучения и аттестации декретированной группы населения:', 11, NULL, NULL),
(149, 'Расходы, связанные с прохождением гигиенического обучения, лица декретированной группы населения несут:', 11, NULL, NULL),
(150, 'Личная медицинская книжка:', 11, NULL, NULL),
(151, 'После прохождения гигиенического обучения проводится:', 11, NULL, NULL),
(152, 'Знание, лицами декретированных групп населения, НПА РК в сфере санитарно-эпидемиологического\nблагополучия населения и гигиенических нормативов проверяется:', 11, NULL, NULL),
(153, 'Ответственность работников за несоблюдение требований санитарных правил и гигиенических нормативов:', 11, NULL, NULL),
(154, 'Нарушение требований законодательства РК в области санитарно-эпидемиологического благополучия\nнаселения, не повлекшее причинение вреда здоровью человека, влечет штраф на физических лиц в размере:', 11, NULL, NULL),
(155, 'Нарушение требований законодательства РК в области санитарно-эпидемиологического благополучия\nнаселения, не повлекшее причинение вреда здоровью человека, влечет штраф на субъектов среднего\nпредпринимательства в размере:', 11, NULL, NULL),
(156, 'Приказ МЗ РК от 16.08.2017 г № 611:', 11, NULL, NULL),
(157, 'В помещениях с влажным режимом работы стены облицовывают плиткой или другими материалами, на\nвысоту:', 11, NULL, NULL),
(158, 'Продолжительность перемен между уроками для учащихся всех видов общеобразовательных организаций\nсоставляет:', 11, NULL, NULL),
(159, 'Жарылғыш затқа ұқсас күдікті затқа қатаң тыйым салынады', 1, NULL, NULL),
(160, 'Терроризм актісі туралы анық емес жалған ақпарат таратқаны үшін жаза:', 1, NULL, NULL),
(161, 'Нысанға жарылғыш зат қою қаупі туралы ақпаратты телефон арқылы алған кезде', 1, NULL, NULL),
(162, 'Қоғамдық тәртіпті бұзу немесе азаматтардың немесе ұйымдардың құқықтары мен заңды мүдделеріне немесе қоғамның немесе заңмен қорғалатын мемлекеттің мүдделеріне елеулі зиян келтіру қаупін туғызатын көрінеу жалған ақпарат таратқаны үшін қандай мөлшерде айыппұл салынады:', 1, NULL, NULL),
(163, 'ҰҚКД сенім телефоны:', 1, NULL, NULL),
(164, 'Жедел қызмет диспетчеріне не хабарлау керек:', 1, NULL, NULL),
(165, 'Террористік қауіп деңгейі:', 1, NULL, NULL),
(166, 'Терроризм актісінің шынайы мүмкіндігін растауды қажет ететін ақпарат болған кезде', 1, NULL, NULL),
(167, '«Терроризмге қарсы комиссиялар туралы үлгі ережені бекіту туралы» ҚР Президентінің Жарлығы', 1, NULL, NULL),
(168, 'ҚР ішкі істер министрлігінің № 582 бақылау парағын бұйрығы бекіту күні', 1, NULL, NULL),
(169, 'ҚР Үкіметінің 2013 жылғы 12 қарашадағы № 1217 Қаулысы', 1, NULL, NULL),
(170, 'Жоғары «қызғылт сары»', 1, NULL, NULL),
(171, 'Терроризмді насихаттау немесе терроризм актісін жасауға шақыру, сондай-ақ көрсетілген мазмұндағы материалдарды тарату немесе тарату мақсатында дайындау, сақтауға қолданылатын жаза:', 1, NULL, NULL),
(172, 'Зорлық-зомбылықты негіздейтін, соның ішінде саяси, діни, идеологиялық және басқа мақсаттарға қол жеткізу үшін террористік әдістер мен құралдарды қолданатын әлеуметтік теориялар мен көзқарастар жүйесі:', 1, NULL, NULL),
(173, 'ҚР «Терроризмге қарсы іс-қимыл туралы» № 416 Заңы қабылданған күні', 1, NULL, NULL),
(174, 'Сізді кепілдікке алған кезде:', 1, NULL, NULL),
(175, 'Террористік тұрғыдан осал нысандардың иелері, менеджерлері немесе басқа лауазымды тұлғалардың міндеттері, ', 1, NULL, NULL),
(176, 'Терроризмге қарсы операцияны кім басқарады:', 1, NULL, NULL),
(177, 'ҚР 08.28.2013 ж № 876 Үкіметінің қаулысы:', 1, NULL, NULL),
(178, 'Орташа «сары»:', 1, NULL, NULL),
(179, 'Терроризмге қарсы қорғанысты және террористік тұрғыдан осал нысан қауіпсіздігінің тиісті деңгейіне сәйкестігін қамтамасыз ету жөніндегі міндеттемелерді орындамау және (немесе) тиісінше орындамау', 1, NULL, NULL),
(180, 'Террористік тұрғыдан осал нысандарды терроризмге қарсы қорғаудың жай-күйін кім тексереді', 1, NULL, NULL),
(181, 'Аса маңызды мемлекеттік нысандар', 1, NULL, NULL),
(182, 'Жарылғыш және улы заттарды сақтауға арналған заңды тұлғалардың объектілері', 1, NULL, NULL),
(183, 'ҚР Президентінің 2013 жылғы 9 тамыздағы № 611 Жарлығы', 1, NULL, NULL),
(184, 'Терроризм актілерін, террористік қауіптерді жоюға кім қатысады', 1, NULL, NULL),
(185, 'Терроризм актісі туралы жалған хабарлау үшін қылмыстық жауаптылық қанша жастан басталады (ҚР ҚК 273-бабы):', 1, NULL, NULL),
(186, 'Жарылыс кезінде не істеу керек', 1, NULL, NULL),
(187, 'Егер ғимаратқа шабуыл басталса, онда....', 1, NULL, NULL),
(188, 'Адамдар көптеп жиналатын нысандар', 1, NULL, NULL),
(189, 'Терроризм дегеніміз не? ', 1, NULL, NULL),
(190, 'Қандай жағдайда террористік қауіптіліктің Сыни «қызыл» деңгейі анықталды', 1, NULL, NULL),
(191, 'Терроризм актісі болған кезде, меншік түріне қарамастан, террористік тұрғыдан осал нысандар басшыларының және қызметкерлерінің міндеттері ', 1, NULL, NULL),
(192, 'Тиісті шараларды жүзеге асыру үшін террористік тұрғыдан осал нысандар меншік иелері, иелері, менеджерлері немесе басқа лауазымды тұлғалардан талап етіледі', 1, NULL, NULL),
(193, 'ҚР «Терроризмге қарсы іс-қимыл туралы» № 416 Заңы қабылданған күні', 1, NULL, NULL),
(194, 'Терроризм актісінің нақты мүмкіндігі туралы расталған ақпараттың болуы', 1, NULL, NULL),
(195, 'ҚР Ұлттық Банкінің объектілері, оның филиалдары мен қоймалары', 1, NULL, NULL),
(196, 'Терроризмге қарсы комиссия', 1, NULL, NULL),
(197, 'Терроризмге қарсы қорғанысты және террористік тұрғыдан осал нысан қауіпсіздігінің тиісті деңгейіне сәйкестігін қамтамасыз ету жөніндегі міндеттемелерді орындамау немесе тиісінше орындамау', 1, NULL, NULL),
(198, 'Орташа «сары»:', 1, NULL, NULL),
(199, 'Сыни «қызыл» жағдайында', 1, NULL, NULL),
(200, 'Жоғары «Қызғылт сары»:', 1, NULL, NULL),
(201, 'Нысанға жарылғыш зат қою қаупі туралы ақпаратты телефон арқылы алған кезде ', 1, NULL, NULL),
(202, 'Подозрительный предмет, похожий на взрывное устройство, категорически запрещается:', 3, NULL, NULL),
(203, 'Заведомо ложное сообщение об акте терроризма предусматривает наказание в виде:', 3, NULL, NULL),
(204, 'При получении по телефону сообщения об угрозе минирования объекта:', 3, NULL, NULL),
(205, 'За распространение заведомо ложной информации, создающей опасность нарушения общественного порядка или причинения существенного вреда правам и законным интересам граждан или организаций либо охраняемым законом интересам общества или государства наказывается штрафом в размере:', 3, NULL, NULL),
(206, 'Телефон доверия ДКНБ:', 3, NULL, NULL),
(207, 'Что необходимо сообщить диспетчеру экстренной службы:', 3, NULL, NULL),
(208, 'Уровень террористической опасности:', 3, NULL, NULL),
(209, 'При наличии требующей подтверждения информации о реальной возможности совершения акта терроризма:', 3, NULL, NULL),
(210, 'Указ Президента РК «Об утверждении Типового положения об антитеррористических комиссиях»', 3, NULL, NULL),
(211, 'Приказ МВД РК «Об утверждении проверочного листа в сфере контроля за состоянием антитеррористической защиты объектов, уязвимых в террористическом отношении, за исключением объектов РК, охраняемых Вооруженными Силами, другими войсками и воинскими формированиями РК, а также специальными государственными органами, и соблюдением их руководителями требований, предусмотренных законодательством РК о противодействии терроризму» № 582', 3, NULL, NULL),
(212, 'Постановление Правительства РК от 12 ноября 2013 года № 1217 ', 3, NULL, NULL),
(213, 'Высокий («оранжевый»)', 3, NULL, NULL),
(214, 'Пропаганда терроризма или публичные призывы к совершению акта терроризма, а равно изготовление, хранение с целью распространения или распространение материалов указанного содержания наказывается', 3, NULL, NULL),
(215, 'Система общественных теорий, взглядов и идей, оправдывающих насилие, в том числе с применением террористических методов и средств, для достижения политических, религиозных, идеологических и иных целей', 3, NULL, NULL),
(216, 'Закон Республики Казахстан «О противодействии терроризму» № 416', 3, NULL, NULL),
(217, 'При захвате вас в заложники рекомендуется', 3, NULL, NULL),
(218, 'Обязанности собственников, руководителей или иных должностных лиц объектов, УТО:', 3, NULL, NULL),
(219, 'Руководство антитеррористической операцией:', 3, NULL, NULL),
(220, 'Постановление Правительства РК от 28.08.2013 года № 876:', 3, NULL, NULL),
(221, 'Умеренный «желтый»:', 3, NULL, NULL),
(222, '«Неисполнение и (или) ненадлежащее исполнение обязанностей по обеспечению антитеррористической защиты и соблюдению должного уровня безопасности объекта, уязвимого в террористическом отношении»', 3, NULL, NULL),
(223, 'Кто осуществляет проверку состояния антитеррористической защиты объектов, уязвимых в террористическом отношении', 3, NULL, NULL),
(224, 'Особо важные государственные объекты', 3, NULL, NULL),
(225, 'Объекты юридических лиц по хранению взрывчатых и ядовитых веществ', 3, NULL, NULL),
(226, 'Указ Президента Республики Казахстан от 9 августа 2013 года № 611', 3, NULL, NULL),
(227, 'Кто занимается ликвидацией актов терроризма, террористических угроз?', 3, NULL, NULL),
(228, 'Уголовная ответственность за заведомо ложное сообщение об акте терроризма (Статья 273 УК РК) начинается:', 3, NULL, NULL),
(229, 'Что вы должны сделать при взрыве?', 3, NULL, NULL),
(230, 'Если начался штурм здания, то нужно….', 3, NULL, NULL),
(231, 'Объекты массового скопления людей', 3, NULL, NULL),
(232, 'Терроризм – это…', 3, NULL, NULL),
(233, 'Критический («красный») уровень террористической опасности устанавливается:', 3, NULL, NULL),
(234, 'Перечень объектов РК, уязвимых в террористическом отношении:', 3, NULL, NULL),
(235, 'Стратегические объекты:', 3, NULL, NULL),
(236, 'В случае совершения акта терроризма руководители и (или) сотрудники объектов, уязвимых в террористическом отношении, независимо от форм собственности, обязаны:', 3, NULL, NULL),
(237, 'В целях реализации соответствующих мероприятий собственники, владельцы, руководители или иные должностные лица объектов, уязвимых в террористическом отношении, независимо от форм собственности, обязаны:', 3, NULL, NULL),
(238, 'Закон Республики Казахстан «О противодействии терроризму» № 416', 3, NULL, NULL),
(239, 'Наличие подтвержденной информации о реальной возможности совершения акта (актов) терроризма', 3, NULL, NULL),
(240, 'Объекты Национального Банка РК, его филиалы и хранилища ', 3, NULL, NULL),
(241, 'Антитеррористическая комиссия', 3, NULL, NULL),
(242, '«Неисполнение и (или) ненадлежащее исполнение обязанностей по обеспечению антитеррористической защиты и соблюдению должного уровня безопасности объекта, уязвимого в террористическом отношении»', 3, NULL, NULL),
(243, 'Умеренный «желтый»:', 3, NULL, NULL),
(244, 'При Критическом “Красном”:', 3, NULL, NULL),
(245, 'При Высоком “Оранжевом”:', 3, NULL, NULL),
(246, 'При получении по телефону сообщения об угрозе минирования объекта:', 3, NULL, NULL),
(247, 'Кәдімгі кәсіптің қызметкерлерімен еңбекті қорғау мәселелері бойынша қайталанған нұсқама өткізіледі:', 5, NULL, NULL),
(248, 'Өндірістегі жазатайым оқиға жазатайым болып саналады, егер:', 5, NULL, NULL),
(249, 'Кәсіпорындағы еңбек қорғау инженері өткізетін нұсқама түрі', 5, NULL, NULL),
(250, 'Өндірістегі жазатайым оқиғаларды арнайы тексеруге бөлінген күндер саны:', 5, NULL, NULL),
(251, 'Арнайы тергеуге жататын жазатайым оқиғалар', 5, NULL, NULL),
(252, 'Сақтандырылған қызметкерге еңбекке уақытша жарамсыздық кезінде келтірілген залалдың орнын толтыратын сома', 5, NULL, NULL),
(253, 'Жұмыс орнында қайтыс болған сақтандырылған жұмысшының отбасына біржолғы төлем', 5, NULL, NULL),
(254, 'Өнеркәсіптік санитария:', 5, NULL, NULL),
(255, 'Қандай параметрлердің толықтығы метеорологиялық жағдаймен сипатталады', 5, NULL, NULL),
(256, 'Жылулық сәулелену болған кезде температураны өлшеу', 5, NULL, NULL),
(257, 'Ауаның салыстырмалы ылғалдылығы қандай бірлікте анықталады', 5, NULL, NULL),
(258, 'Микроклимат параметрлерін қалыпқа келтіргенде есептеледі:', 5, NULL, NULL),
(259, 'Стационарлық психрометрмен салыстырмалы ылғалдылықты анықтау кезінде ескеріледі:', 5, NULL, NULL),
(260, 'Берілген микроклимат параметрлерінің ішіндегі ең жақсысы', 5, NULL, NULL),
(261, 'Адам ағзасына әсер ету дәрежесі бойынша зиянды заттар (ГОСТ сәйкес) сынып санына бөлінеді', 5, NULL, NULL),
(262, 'Зиянды заттар стандарттайды', 5, NULL, NULL),
(263, 'Күнделікті жұмыс кезінде бүкіл жұмыс тәжірибесінде ауру тудырмайтын зиянды заттардың концентрациясының атауы', 5, NULL, NULL),
(264, 'УГ-2 газ анализаторының жұмыс принципі негізделген', 5, NULL, NULL),
(265, 'Ауадағы зиянды заттардың концентрациясы қандай бірлікпен анықталады', 5, NULL, NULL),
(266, 'Екінші дәрежелі зиянды заттардың шекті рұқсат етілген концентрациясы (ШРЕК)', 5, NULL, NULL),
(267, 'Адам ағзасына шаң әкелуі мүмкін әрекет', 5, NULL, NULL),
(268, 'Шаңның қандай түрі болмайды:', 5, NULL, NULL),
(269, 'Фильтр арқылы тартылған және қалыпты жағдайға дейін төмендетілген ауа көлемін есептеуге болатын формула', 5, NULL, NULL),
(270, 'Уытты шаңмен жұмыс кезігде қолданылатын қорғаныс құралдары', 5, NULL, NULL),
(271, 'Жарық беру:', 5, NULL, NULL),
(272, 'Жарық өлшенетін бірлік:', 5, NULL, NULL),
(273, 'Ю-116 люксметрінің элементтері:', 5, NULL, NULL),
(274, 'Желдету тапсырмалары', 5, NULL, NULL),
(275, 'Ауа алмасуын зиянды заттарды шығармай есептеу үшін сіз білуіңіз керек', 5, NULL, NULL),
(276, 'Санитарлық желдетудің тиімділігі бағаланады', 5, NULL, NULL),
(277, 'Шаң концентрациясы 27 мг / м3 болатын шаңның шекті концентрациясы 3 мг / м болатын жем беру цехындағы ауа алмасу жылдамдығын анықтаңыз', 5, NULL, NULL),
(278, 'Шу қалыпқа келтіріледі', 5, NULL, NULL),
(279, 'Бір жұмысшы үшін ең аз рұқсат етілетін алаң м кв', 5, NULL, NULL),
(280, 'Кәсіпорындағы еңбек қауіпсіздігін басқару органы құрамына кіреді', 5, NULL, NULL),
(281, 'Шекті доза', 5, NULL, NULL),
(282, 'Қандай ұйымдарда еңбек қорғау қызметін құрайды', 5, NULL, NULL),
(283, 'Қандай жағдайда жұмыс беруші қызметкерді жұмыс істемейтін қызметкерді ауыстыру үшін сол ұйымдағы басқа жұмысқа ауыстыруға құқылы', 5, NULL, NULL),
(284, 'Баспалдақтар мен баспалдақтардан жұмыс қауіпсіздігін қамтамасыз ету үшін қандай ұйымдастыру шараларын жүргізу керек', 5, NULL, NULL),
(285, 'Жеке электронды компьютерлерді (ДК) пайдаланушылардың қандай санаттары жұмысқа тұру және мерзімді медициналық тексеруден өту үшін қажет?', 5, NULL, NULL),
(286, 'Гигиеналық өлшемдер дегеніміз не, олар қайда және неге қолданылады', 5, NULL, NULL),
(287, 'Зиянды өндірістік фактор дегеніміз не?', 5, NULL, NULL),
(288, 'Еңбек қауіпсіздігі мен кадрларды кәсіби таңдаудың қандай байланысы бар?', 5, NULL, NULL),
(289, 'Сақтанушының кінәсінің қанша пайызын комиссия жазатайым оқиғаны тергеу кезінде анықтай алады', 5, NULL, NULL),
(290, 'Түнгі жұмыс деп қандай жұмыс саналады және ол қалай төленеді', 5, NULL, NULL),
(291, 'Төменде келтірілген ережелердің қайсысы еңбек шартының маңызды талаптары болып табылады', 5, NULL, NULL),
(292, 'Повторный инструктаж по вопросам охраны труда с работниками обычных профессий проводится:', 4, NULL, NULL),
(293, 'Несчастный случай считается несчастным случаем на производстве, когда:', 4, NULL, NULL),
(294, 'Вид инструктажа, который проводится инженером по охране труда на предприятии:', 4, NULL, NULL),
(295, 'Количество дней, которые отводятся на проведение специального расследования несчастных случаев на производстве:', 4, NULL, NULL),
(296, 'Несчастные случаи, которые подлежат специальному расследованию:', 4, NULL, NULL),
(297, 'Размер, который составляет возмещение ущерба, причиненного застрахованному работнику при временной потере трудоспособности:', 4, NULL, NULL),
(298, 'Размер, который составляет единовременное пособие семье застрахованного работника, погибшего на производстве:', 4, NULL, NULL),
(299, 'Производственная санитария – это:', 4, NULL, NULL),
(300, 'Совокупностью которых параметров характеризуются метеорологические условия:', 4, NULL, NULL),
(301, 'Для измерения температуры при наличии тепловых излучений используют:', 4, NULL, NULL),
(302, 'Относительную влажность воздуха определяют в единицах:', 4, NULL, NULL),
(303, 'При нормировании параметров микроклимата учитывается:', 4, NULL, NULL),
(304, 'При определении относительной влажности стационарным психрометром учитывается:', 4, NULL, NULL),
(305, 'Из перечисленных параметров микроклимата лучшие:', 4, NULL, NULL),
(306, 'По степени воздействия на организм человека вредные вещества (согласно ГОСТа) разделяют на количество классов:', 4, NULL, NULL),
(307, 'Вредные вещества нормируют по:', 4, NULL, NULL),
(308, 'Название концентрации вредных веществ, которая при ежедневной работе в течение всего трудового стажа не вызывает заболевания:', 4, NULL, NULL),
(309, 'Принцип работы газоанализатора УГ-2 базируется на:', 4, NULL, NULL),
(310, 'Концентрация вредных веществ в воздухе определяется в единицах:', 4, NULL, NULL),
(311, 'Предельно допустимая концентрация вредных веществ второго класса:', 4, NULL, NULL),
(312, 'Действие, которое может привести пыль на организм человека:', 4, NULL, NULL),
(313, 'По происхождению пыль не бывает:', 4, NULL, NULL),
(314, 'Формула, по которой можно рассчитать объем воздуха, протянутый через фильтр и приведенный к нормальным условиям:', 4, NULL, NULL),
(315, 'Средства защиты, используемые при работе с токсической пылью:', 4, NULL, NULL),
(316, 'Освещение – это:', 4, NULL, NULL),
(317, 'Единицы, в которых измеряется освещение:', 4, NULL, NULL),
(318, 'Элементы, из которых состоит люксметр Ю-116:', 4, NULL, NULL),
(319, 'Задачи вентиляции:', 4, NULL, NULL),
(320, 'Для расчета воздухообмена без выделения вредных веществ нужно знать:', 4, NULL, NULL),
(321, 'Санитарно-гигиеничная эффективность вентиляции оценивается:', 4, NULL, NULL),
(322, 'Определить кратность воздухообмена в кормоцеха, в котором концентрация пыли составляет 27мг/м3, а ПДК пыли 3 мг/м', 4, NULL, NULL),
(323, 'Нормируется шум по:', 4, NULL, NULL),
(324, 'Наименьшая допустимая площадь производственного помещения на одного рабочего (м кв):', 4, NULL, NULL),
(325, 'К управляющему органу СУОТ на предприятии относятся:', 4, NULL, NULL),
(326, 'Пороговая доза – это:', 4, NULL, NULL),
(327, 'Когда в организации создают службу охраны труда?', 4, NULL, NULL),
(328, 'На каких условиях работодатель имеет право перевести работника на другую работу в той же организации для замещения отсутствующего работника?', 4, NULL, NULL),
(329, 'Какие организационные мероприятия следует выполнять для обеспечения безопасности работ с приставных лестниц и стремянок?', 4, NULL, NULL),
(330, 'Какие категории пользователей персональными электронно-вычислительными машинами (ПЭВМ) проходят обязательные при приеме на работу и периодические медицинские осмотры?', 4, NULL, NULL),
(331, 'Что такое гигиенические критерии, где и для чего они используются?', 4, NULL, NULL),
(332, 'Что такое вредный производственный фактор?', 4, NULL, NULL),
(333, 'Каким образом связаны между собой безопасность труда и профессиональный отбор персонала?', 4, NULL, NULL),
(334, 'Сколько процентов вины застрахованного может быть установлено комиссией при расследовании несчастного случая?', 4, NULL, NULL),
(335, 'Какая работа считается работа в ночное время и как она оплачивается?', 4, NULL, NULL),
(336, 'Какие из перечисленных положений являются существенными условиями трудового договора?', 4, NULL, NULL),
(337, 'Жабық жарақат алу кезіндегі көмек:', 7, NULL, NULL),
(338, 'Егер күйіп қалудан қызару, ісіну, көпіршіктер болса, онда:', 7, NULL, NULL),
(339, 'Негізгі реанимация қашан жасалады: ', 7, NULL, NULL),
(340, 'Адам үсіген кезде:', 7, NULL, NULL),
(341, 'Ағза ауыз арқылы уланған кезде:', 7, NULL, NULL),
(342, 'Негізгі реанимация үшін зардап шегуші:', 7, NULL, NULL),
(343, 'Тыныс алу жолдары арқылы уланған жағдайда:', 7, NULL, NULL),
(344, 'Тыныс алу жолдарына арқылы уланған жағдайда тыйым салынады:', 7, NULL, NULL),
(345, 'Омыртқа жарақатымен зардап шеккен адамды тасымалдау қалай жүзеге асырылады:', 7, NULL, NULL),
(346, 'Адамды улы жәндік шаққан кезде қажет:', 7, NULL, NULL),
(347, 'Адамды улы жәндік шаққан кезде тыйым салынады:', 7, NULL, NULL),
(348, 'Сіңір тартылған кезде қажет:', 7, NULL, NULL),
(349, 'Кеуде ауырсыну кезінде:', 7, NULL, NULL),
(350, 'Алғашқы медициналық көмек қобдишасының құрамы қандай бұйрықпен бекітілген', 7, NULL, NULL),
(351, 'Алғашқы көмек:', 7, NULL, NULL),
(352, 'Действия при закрытой травме:', 6, NULL, NULL),
(353, 'Если имеются покраснения, отеки, пузыри от ожога, то необходимо:', 6, NULL, NULL),
(354, 'Когда делается базовая реанимация:', 6, NULL, NULL),
(355, 'При обморожении необходимо:', 6, NULL, NULL),
(356, 'При отравлении организма через рот необходимо:', 6, NULL, NULL),
(357, 'Для проведения базовой реанимации пострадавший:', 6, NULL, NULL),
(358, 'При отравлении дыхательных путей необходимо:', 6, NULL, NULL),
(359, 'При отравлении дыхательных путей запрещается:', 6, NULL, NULL),
(360, 'Как делается транспортировка пострадавшего при травме позвоночника:', 6, NULL, NULL),
(361, 'При укусах необходимо:', 6, NULL, NULL),
(362, 'При укусах запрещается:', 6, NULL, NULL),
(363, 'При судорогах необходимо:', 6, NULL, NULL),
(364, 'При боли в груди необходимо:', 6, NULL, NULL),
(365, 'Состав аптечки утвержден Приказом:', 6, NULL, NULL),
(366, 'Первая помощь – это…', 6, NULL, NULL),
(367, 'Өрттерді сөндіру кезінде өртке қарсы қызмет қызметкері құқылы', 9, NULL, NULL),
(368, 'Өртті сөндіруге қатысатын өрт сөндіру бөлімдері бағынышты:', 9, NULL, NULL),
(369, 'Өрт сөндіру қызметтерінің іс әрекеттерін үйлестіреді:', 9, NULL, NULL),
(370, 'Мемлекеттік өртке қарсы қызмет органдары:', 9, NULL, NULL),
(371, 'Қазақстан Республикасындағы өрт қауіпсіздігі жүйесі', 9, NULL, NULL),
(372, 'Өз құзыреті шегінде өрт қауіпсіздігі саласындағы уәкілетті орган', 9, NULL, NULL),
(373, 'Өрттерді сөндіруге қатысы жоқ аварияларды, табиғи апаттарды және басқа да төтенше жағдайларды жою кезінде мемлекеттік өртке қарсы қызмет органдарының күштері мен қаражаты қайда бағытталады:', 9, NULL, NULL),
(374, 'Мемлекеттік өртке қарсы қызмет органдарынан құрылымы:', 9, NULL, NULL),
(375, 'Тұрғын үй алаптарындағы, стратегиялық, әсіресе маңызды мемлекеттік нысандардағы және мемлекеттік меншікті тіршілік ету объектілеріндегі өрттерді сөндіру жүзеге асырылады', 9, NULL, NULL),
(376, 'Дала өрттерін, сондай-ақ мемлекеттік өртке қарсы қызмет органдары орнатылмаған елді мекендердегі өрттерді кім  сөндіреді:', 9, NULL, NULL),
(377, 'Өрттерді сөндіруді ұйымдастыру және оған мемлекеттік емес өртке қарсы қызметтерді тарту', 9, NULL, NULL),
(378, 'Өрт қауіпсіздігі саласындағы облыстардың, республикалық маңызы бар қаланың және астананың, аудандардың (облыстық маңызы бар қалалардың) жергілікті атқарушы органдарының өкілеттіктеріне: ', 9, NULL, NULL),
(379, 'Өртке қарсы қызметтің аға офицері:', 9, NULL, NULL),
(380, 'Ұлттық қауiпсiздiк, Қазақстан Республикасының iшкi iстерi, әуе, темiр жол, теңiз және iшкi су көлiгi, орман шаруашылығы және қорғаныс объектiлерiндегi өртті сөндіру:', 9, NULL, NULL),
(381, 'Мемлекеттік емес өртке қарсы қызметтің негізгі міндеттері:', 9, NULL, NULL),
(382, 'Мемлекеттік емес өрт сөндіру қызметі өз қызметкерлерін қамтамасыз етуге міндетті: ', 9, NULL, NULL),
(383, 'Өртке қарсы қызмет міндетті түрде құрылатын ұйымдар мен объектілердегі өрттерді сөндіруге мемлекеттік өртке қарсы қызмет тартылған жағдайда өтелген шығыстардың сомасы есептеледі: ', 9, NULL, NULL),
(384, 'Ерікті өрт сөндірушілерді даярлаудың бастапқы бағдарламасы бекітіледі:', 9, NULL, NULL),
(385, 'Ерікті өрт сөндірушінің қайтыс болуы (жарақаттануы) немесе жарақаттануы кезінде оның өрттің алдын алу және сөндіру, өрт қауіпсіздігін қамтамасыз ету және өрттерді жоюға байланысты авариялық-құтқару жұмыстарын жүргізу жөніндегі жұмыс барысында кепілдіктер белгіленеді: ', 9, NULL, NULL),
(386, 'Мемлекеттік өртке қарсы қызмет органдары: ', 9, NULL, NULL),
(387, 'Өрт қауіпсіздігі және өрт сөндіру ұйымдарын қамтамасыз ету кімге жүктеледі: ', 9, NULL, NULL),
(388, 'Мемлекеттік өртке қарсы қызмет құрылмаған ұйымдардағы, елді мекендердегі өрттің, сондай-ақ өрттің алдын алу және сөндіру жөніндегі іс-шараларды жүзеге асыру мақсатында мыналар құрылуы мүмкін:', 9, NULL, NULL),
(389, 'Ерікті өрт сөндірушілерді кейінгі оқыту бағдарламасы:', 9, NULL, NULL),
(390, 'Адамдар көптеп болатын объект - бұл:', 9, NULL, NULL),
(391, 'Аккредитация:', 9, NULL, NULL),
(392, 'Аккредиттеу туралы куәлік: ', 9, NULL, NULL),
(393, 'Өрт қауіпсіздігі саласындағы қолданыстағы заңнамаға сәйкес «Нысан» термині:', 9, NULL, NULL),
(394, 'Өрт қауіпсіздігі саласындағы нормалар, ережелер, техникалық регламенттер мен стандарттардың сақталуын бақылауға мыналар жатады: ', 9, NULL, NULL),
(395, 'Өрт қауіпсіздігінің талаптары: ', 9, NULL, NULL),
(396, 'Өрт қауіпсіздігі саласындағы тәуелсіз бағалау:', 9, NULL, NULL),
(397, 'Өрт қауіпсіздігі саласындағы мемлекеттік бақылау: ', 9, NULL, NULL),
(398, 'Өрт қауіпсіздігі саласындағы уәкілетті орган:', 9, NULL, NULL),
(399, 'Өрт қауіпсіздігі шаралары: ', 9, NULL, NULL),
(400, 'Өрт-техникалық өнімдер: ', 9, NULL, NULL),
(401, 'Сараптама ұйымы: ', 9, NULL, NULL),
(402, 'Өмірді қолдау нысаны: ', 9, NULL, NULL),
(403, 'Нысанның өрт қауіпсіздігі келесі шарттардың бірі орындалған жағдайда қамтамасыз етілген болып саналады:', 9, NULL, NULL),
(404, 'Өрт қаупін тәуелсіз бағалау жүргізілмейді: ', 9, NULL, NULL),
(405, 'Сараптамалық ұйымдар:', 9, NULL, NULL),
(406, 'Өрт қауіпсіздігі шаралары мыналардың негізінде жасалады:', 9, NULL, NULL),
(407, 'Халықты өрт қауіпсіздігі шаралары туралы ақпараттандыру жүзеге асырылады:', 9, NULL, NULL),
(408, 'Өрт қауіпсіздігі саласындағы ережелер, техникалық регламенттер мен стандарттардың сақталуын бақылауға мыналар жатады:', 9, NULL, NULL),
(409, 'Өнімдер мен оның өмірлік циклінің процестеріне өрт қауіпсіздігінің талаптары: ', 9, NULL, NULL),
(410, 'Теміржол көлігіндегі өрт қауіпсіздігі саласындағы бақылау: ', 9, NULL, NULL),
(411, 'ҚР аумағында қолданылатын өрт-техникалық өнiмдерiнiң түрлерi:', 9, NULL, NULL),
(412, 'При тушении пожаров сотрудник противопожарной службы имеет право:', 8, NULL, NULL),
(413, 'Подразделения противопожарной службы, привлекаемые к тушению пожара, подчиняются', 8, NULL, NULL),
(414, 'Деятельность противопожарных служб координирует:', 8, NULL, NULL),
(415, 'Органы государственной противопожарной службы являются:', 8, NULL, NULL),
(416, 'Система пожарной безопасности в Республике Казахстан - это:', 8, NULL, NULL),
(417, 'Уполномоченный орган в области пожарной безопасности в пределах своей компетенции:', 8, NULL, NULL),
(418, 'При ликвидации аварий, стихийных бедствий и иных чрезвычайных ситуаций, не связанных с тушением пожаров, силы н средства (кроме денежных средств) органов государственной противопожарной службы поступают в распоряжение:', 8, NULL, NULL),
(419, 'Органы государственной противопожарной службы состоит из:', 8, NULL, NULL),
(420, 'Тушение пожаров на селитебных территориях, стратегических, особо важных государственных объектах н объектах жизнеобеспечения государственной собственности осуществляется:', 8, NULL, NULL),
(421, 'Тушение степных пожаров, а также пожаров в населенных пунктах, в которых не созданы органы государственной противопожарной службы, осуществляется:', 8, NULL, NULL),
(422, 'Порядок организации тушения пожаров и привлечения к этому негосударственных противопожарных служб устанавливается:', 8, NULL, NULL),
(423, 'К полномочиям местных исполнительных органов областей, городов республиканского значения и столицы, районов (юродов областного значения) в области пожарной безопасности относятся:', 8, NULL, NULL),
(424, 'Старшим оперативным начальником в отношении всех противопожарных служб является:', 8, NULL, NULL),
(425, 'Тушение пожаров на объектах органов национальной безопасности, внутренних дел и обороны Республики Казахстан, воздушного, железнодорожного, морского и внутреннего водного транспорта, лесного хозяйства регламентируется:', 8, NULL, NULL),
(426, 'Основные задачи негосударственной противопожарной службы:', 8, NULL, NULL),
(427, 'Негосударственная противопожарная служба обязана обеспечивать своих работников:', 8, NULL, NULL),
(428, 'Сумма затрат, возмещаемая в случае привлечения органов государственной противопожарной службы к тушению пожаров в организациях и на объектах, на которых в обязательном порядке создается противопожарная служба, зачисляется:', 8, NULL, NULL),
(429, 'Программа первоначальной подготовки добровольных пожарных утверждается:', 8, NULL, NULL),
(430, 'Гарантии в случае гибели (смерти) или увечья добровольного пожарного в период выполнения им работ по предупреждению н тушению пожаров, обеспечению пожарной безопасности и проведению первоочередных аварийно-спасательных работ, связанных с тушением пожаров, устанавливаются:', 8, NULL, NULL),
(431, 'Органы государственной противопожарной службы являются:', 8, NULL, NULL),
(432, 'Обеспечение пожарной безопасности н пожаротушения организаций возлагается на:', 8, NULL, NULL),
(433, 'В целях осуществления мероприятий по профилактике и тушению стенных пожаров, а также пожаров в организациях, насаленных пунктах, в которых не созданы органы государственной противопожарной службы, могут создаваться:', 8, NULL, NULL),
(434, 'Программа последующей подготовки добровольных пожарных:', 8, NULL, NULL),
(435, 'Объект с массовым пребыванием людей - что:', 8, NULL, NULL),
(436, 'Аккредитация - это:', 8, NULL, NULL),
(437, 'Аттестат аккредитации - это:', 8, NULL, NULL),
(438, 'В соответствии с действующим законодательством в области пожарной безопасности под понятием «Объект» подразумевается:', 8, NULL, NULL),
(439, 'Контролю за соблюдением норм, правил, технических регламентов и стандартов в области пожарной безопасности подлежат:', 8, NULL, NULL),
(440, 'Требования пожарной безопасности - это:', 8, NULL, NULL),
(441, 'Независимая оценка рисков в области пожарной безопасности - это:', 8, NULL, NULL),
(442, 'Государственный контроль в области пожарной безопасности - это:', 8, NULL, NULL),
(443, 'Уполномоченный орган в области пожарной безопасности - это:', 8, NULL, NULL),
(444, 'Меры пожарной безопасности - это:', 8, NULL, NULL),
(445, 'Пожарно-техническая продукция - это:', 8, NULL, NULL),
(446, 'Экспертная организация - это:', 8, NULL, NULL),
(447, 'Объект жизнеобеспечения - это:', 8, NULL, NULL),
(448, 'Пожарная безопасность объекта считается обеспеченной, если выполняется одно из нижеследующих условий:', 8, NULL, NULL),
(449, 'Независимая оценка рисков в области пожарной безопасности не проводится:', 8, NULL, NULL),
(450, 'Экспертными организациями могут быть организации:', 8, NULL, NULL),
(451, 'Меры пожарной безопасности разрабатываются па основе:', 8, NULL, NULL),
(452, 'Информирование населения о мерах пожарной безопасности осуществляют:', 8, NULL, NULL),
(453, 'Контролю за соблюдением норм правил, технических регламентов н стандартов в области пожарной безопасности подлежат:', 8, NULL, NULL),
(454, 'Требования пожарной безопасности к продукции и процессам ее жизненного цикла устанавливают:', 8, NULL, NULL),
(455, 'Контроль в области пожарной безопасности на железнодорожном транспорте осуществляется:', 8, NULL, NULL),
(456, 'Виды пожарно-технической продукции, применяемые на территории РК, определяются:', 8, NULL, NULL),
(457, 'Қызметкерлердің санитарлық ережелерді және гигиеналық нормативтердің талаптарын сақтамағаны үшін жауапкершілігі:', 10, NULL, NULL),
(458, 'Жалпы білім беру ұйымдарының барлық түрінде оқушылар үшін сабақтар арасындағы үзілістің ұзақтығы:', 10, NULL, NULL),
(459, 'Халықтың декреттелген топтары адамдарының халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы ҚР нормативтік құқықтық актілерін және гигиеналық нормативтерін білуін:', 10, NULL, NULL),
(460, 'Жұмысқа жіберілу туралы белгі қойылып, міндетті медициналық қарап-тексерудің нәтижелері енгізілетін жеке құжат:', 10, NULL, NULL),
(461, 'Халықтың декреттелген тобын гигиеналық оқытуды және аттестаттауды жүргізу тәртібі:', 10, NULL, NULL),
(462, 'Халықтың декреттелген тобын гигиеналық оқыту:', 10, NULL, NULL),
(463, 'Ылғалды режимде жұмыс істейтін үй-жайлардың қабырғаларын кемінде', 10, NULL, NULL),
(464, 'Гигиеналық оқытудан өтумен байланысты шығыстарды жұмсайды', 10, NULL, NULL),
(465, 'Жалпы білім беру ұйымдарының барлық түрінде оқушылар үшін сабақтар арасындағы үлкен үзіліс:', 10, NULL, NULL),
(466, 'Қазақстан Республикасының халықтың санитариялық-эпидемиологиялық саламаттылығы саласындағы заңнамасының талаптарын, сондай-ақ гигиеналық нормативтердi, техникалық регламенттерді адам денсаулығына зиян келтіруге әкеп соқпаған бұзушылық жеке тұлғаларға:', 10, NULL, NULL),
(467, 'Адамның денсаулығына зиян келтiруге әкеп соққан әрекет (әрекетсіздік), егер бұл әрекетте (әрекетсіздікте) қылмыстық жазаланатын іс-әрекет белгiлерi болмаса ірі кәсіпкерлік субъектілеріне:', 10, NULL, NULL),
(468, 'Ауысымдар арасында ылғалды жинау және желдету үшін ұзақтығы кемінде:', 10, NULL, NULL),
(469, 'Сынамаларды қақпағы бар таза шыны ыдысқа алады және қанша температурада тоңазытқышта арнайы бөлінген орында сақтайды:', 10, NULL, NULL),
(470, 'Таза ауада дене шынықтыру сабақтарын жылы уақытта атмосфералық ауа температурасы:', 10, NULL, NULL),
(471, 'Үй-жайларды күрделі жинау аптасына кемінде', 10, NULL, NULL),
(472, 'Ответственность работников за несоблюдение требований санитарных правил и гигиенических нормативов:', 11, NULL, NULL),
(473, 'Продолжительность перемен между уроками для учащихся всех видов общеобразовательных организаций составляет:', 11, NULL, NULL),
(474, 'Знание, лицами декретированных групп населения, НПА РК в сфере санитарно-эпидемиологического благополучия населения и гигиенических нормативов проверяется:', 11, NULL, NULL),
(475, 'Персональный документ, в который заносятся результаты обязательных медицинских осмотров с отметкой о допуске к работе:', 11, NULL, NULL),
(476, 'Порядок проведения гигиенического обучения и аттестации декретированной группы населения:', 11, NULL, NULL),
(477, 'Гигиеническое обучение декретированной группы населения:', 11, NULL, NULL),
(478, 'В помещениях с влажным режимом работы стены облицовывают плиткой или другими материалами, на высоту:', 11, NULL, NULL),
(479, 'Расходы, связанные с прохождением гигиенического обучения, лица декретированной группы населения несут:', 11, NULL, NULL),
(480, 'Продолжительность большой перемены между уроками для учащихся всех видов общеобразовательных организаций составляет ', 11, NULL, NULL),
(481, 'Действие (бездействие), предусмотренное частью первой статьи 425 КоАП РК, повлекшее причинение вреда здоровью человека, если это действие (бездействие) не содержит признаков уголовно наказуемого деяния, влечет штраф на физических лиц в размере:', 11, NULL, NULL),
(482, 'Нарушение требований законодательства РК в области санитарно-эпидемиологического благополучия населения, не повлекшее причинение вреда здоровью человека, влечет штраф на субъектов крупного предпринимательств в размере:', 11, NULL, NULL),
(483, 'Интервалы между приемами пищи не должны превышать:', 11, NULL, NULL),
(484, 'Пробы отбирают в чистую стеклянную посуду с крышкой и хранят в специально отведенном месте холодильника при температуре:', 11, NULL, NULL),
(485, 'Организуются уроки физической культуры на свежем воздухе в теплый период времени при температуре атмосферного воздуха:', 11, NULL, NULL),
(486, 'Генеральная уборка помещений проводится:', 11, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', '2021-01-08 01:58:17', '2021-01-08 01:58:17'),
(2, 'user', 'Normal User', '2021-01-08 01:58:17', '2021-01-08 01:58:17');

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `key`, `display_name`, `value`, `details`, `type`, `order`, `group`) VALUES
(1, 'site.title', 'Название сайта', 'РЕСПУБЛИКАНСКИЙ ЦЕНТР ПОДГОТОВКИ И ПОВЫШЕНИЯ КВАЛИФИКАЦИИ', '', 'text', 1, 'Site'),
(2, 'site.description', 'Описание сайта', 'Site Description', '', 'text', 2, 'Site'),
(3, 'site.logo', 'Логотип сайта', 'settings\\January2021\\whoz4E7oop3ySHSIOYpb.png', '', 'image', 3, 'Site'),
(4, 'site.google_analytics_tracking_id', 'Google Analytics Tracking ID', NULL, '', 'text', 4, 'Site'),
(5, 'admin.bg_image', 'Admin Background Image', '', '', 'image', 5, 'Admin'),
(6, 'admin.title', 'Admin Title', 'Voyager', '', 'text', 1, 'Admin'),
(7, 'admin.description', 'Admin Description', 'Welcome to Voyager. The Missing Admin for Laravel', '', 'text', 2, 'Admin'),
(8, 'admin.loader', 'Admin Loader', '', '', 'image', 3, 'Admin'),
(9, 'admin.icon_image', 'Admin Icon Image', '', '', 'image', 4, 'Admin'),
(10, 'admin.google_analytics_client_id', 'Google Analytics Client ID (used for admin dashboard)', NULL, '', 'text', 1, 'Admin'),
(12, 'site.phone', 'Номер телефона', '+7 (727) 364-54-00', NULL, 'text', 6, 'Site'),
(13, 'site.comm_title', 'Заголовок о сообществе', 'Наше сообщество', NULL, 'text', 7, 'Site'),
(14, 'site.comm_text', 'Содержание о сообществе', 'Первые руководители организаций довольны обучением, проведенным Республиканским центром подготовки и повышения квалификации', NULL, 'text_area', 8, 'Site'),
(15, 'site.org_title', 'Заголовок организации', 'Организации, которые проходят обучение сейчас', NULL, 'text', 9, 'Site'),
(16, 'site.slider_slogan', 'Слоган слайдера', 'Присоединись к 7354 организациям', NULL, 'text', 10, 'Site'),
(17, 'site.footer_address', 'Футер Адрес', 'РК, 050060, г. Алматы, пр Достык 210А', NULL, 'text', 11, 'Site'),
(18, 'site.footer_address2', 'Футер Адрес 2', 'БЦ Koktem Grand, (Блок) 6 этаж', NULL, 'text', 12, 'Site'),
(19, 'site.footer_phone', 'Футер телефон', '+7 (727) 364-54-00', NULL, 'text', 13, 'Site'),
(20, 'site.footer_email', 'Футер Email', 'cppkcenter12@gmail.com', NULL, 'text', 14, 'Site'),
(21, 'site.footer_text', 'Футер текст', 'Республиканский центр подготовки и повышения квалификации', NULL, 'text', 15, 'Site'),
(22, 'site.about', 'О нас', '<div id=\"content\">\r\n<h1 class=\"text-center\">О нас</h1>\r\n<div class=\"section\">\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 16px;\"><strong>Республиканский центр подготовки и повышения квалификации</strong>&nbsp;(РЦПК) является специализированной организацией по выполнению комплекса профессиональных услуг, связанных с обеспечением безопасности и охраны труда, а также пожарной безопасности&nbsp;в организациях Республики Казахстан.</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 16px;\">Действуя на основании имеющихся разрешений (лицензий) территориальных органов: ПРИКАЗА о создании постоянно-действующей экзаменационной комиссии по проверке знаний по безопасности и охране труда с включением председателем ПДЭК Государственного инспектора по труду УГИТиМ&nbsp;№08 от 10 марта 2016 года, согласно &laquo;Правил и сроков проведения обучения, инструктирования и проверок знаний по вопросам безопасности и охраны труда работников&raquo;, утвержденных Приказом Министерства здравоохранения и социального развития Республики Казахстан от 25 декабря 2015 года № 1019, ЦППК на основании действующего законодательства РК, осуществляет подготовку, переподготовку, повышение квалификации специалистов в области:</span></p>\r\n<p style=\"text-align: justify;\"><br /><span style=\"font-size: 16px;\">&bull;&nbsp; Безопасности и охраны труда в соответствии с Трудовым Кодексом Республики Казахстан ЗРК №414-V от 23 ноября 2015 г. и Приказом МЗиСР РК от 25 декабря 2015 года № 1019 &laquo;Правила и сроки проведения обучения, инструктирования и проверок знаний по вопросам безопасности и охраны труда работников&raquo; с выдачей сертификатов установленного образца и пакетом необходимой нормативно-технической документации;&nbsp;</span></p>\r\n<p style=\"text-align: justify;\"><br /><span style=\"font-size: 16px;\">&bull;&nbsp; Пожарной безопасности в объеме пожарно-технического минимума на основании Закона Республики Казахстан &laquo;О гражданской защите&raquo; от 11 апреля 2014 г. №188-V, Приказа МВД от 16 сентября 2015 г. №777, Правил пожарной безопасности, утвержденных Постановлением Правительства&nbsp; от 09 октября 2014 года&nbsp; №1077, Технического регламента &laquo;Общие требования к пожарной безопасности&raquo; от 16 января 2009 года № 14 с выдачей удостоверений установленного образца и пакетом необходимой нормативно-технической документации.</span></p>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<div style=\"text-align: justify;\"><span style=\"font-size: 16px;\"><strong><em>Порядок обучения</em></strong><br />&nbsp;<br />&bull; Обучение по вопросам БиОТ и ПТМ проводится с участием <strong>ПОЛКОВНИКА ЗАПАСА</strong>&nbsp;Департамента по чрезвычайным ситуациям;<br />&bull; На обучении <u><strong>заседают</strong></u> государственные инспекторы ДЧС и Государственной инспекции труда;<br />&bull; Выездной семинар (<u>более 10 человек</u>) + консультативный аудит на соответствие требованиям безопасности и охране труда в организациях;<br />&bull; Раздаточный материал;<br />&bull; Журнал по пожарной безопасности;<br />&bull; По завершению выдается Сертификат (Удостоверение) государственного образца, подписанный государственным инспектором, действующий сроком до 3 лет.<br />&bull; Проведение онлайн обучения.</span></div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<div style=\"text-align: justify;\"><em><strong><span style=\"font-size: 16px;\">Как производится проверка знаний по Пожарной безопасности и Охране труда?</span></strong></em></div>\r\n<div style=\"text-align: justify;\"><span style=\"font-size: 16px;\">Итоговая проверка знаний по Пожарной безопасности и Охране труда проводится в форме теста, по результатам которого выдается Удостоверние или Сертификат об успешном прохождении курса.</span></div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n<div style=\"text-align: justify;\"><em><strong><span style=\"font-size: 16px;\">Варианты проведения обучения, чтобы оптимально использовать Ваше время и затраты.</span></strong></em></div>\r\n<div style=\"text-align: justify;\"><span style=\"font-size: 16px;\">1. Пройти обучение в учебном центре РЦПК</span></div>\r\n<div style=\"text-align: justify;\"><span style=\"font-size: 16px;\">2. Выздной семинар</span></div>\r\n<div style=\"text-align: justify;\"><span style=\"font-size: 16px;\">3. Онлайн обучение.</span></div>\r\n<div style=\"text-align: justify;\">&nbsp;</div>\r\n</div>\r\n</div>', NULL, 'rich_text_box', 16, 'Site'),
(23, 'site.contacts', 'Контакты', '<div class=\"section\">\r\n<h1 class=\"title\">Контакты</h1>\r\n<div class=\"row\">\r\n<div class=\"col-sm-6\">\r\n<div id=\"form_text\">\r\n<div id=\"contact_text\">\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-size: 16px;\">Адрес: РК, 050060, г. Алматы, пр Достык 210А</span></p>\r\n<p><span style=\"font-size: 16px;\">БЦ Koktem Grand, &nbsp;(Блок А</span><span style=\"font-size: 16px;\">) 6 этаж</span></p>\r\n<p><span style=\"font-size: 16px;\">Тел. +7(727)364-54-00</span></p>\r\n<p><span style=\"font-size: 16px;\">Email: cppkcenter12@gmail.com</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-sm-6\">\r\n<div id=\"map\"><a class=\"dg-widget-link\" style=\"display: none;\" href=\"http://2gis.kz/almaty/firm/70000001029834301/center/76.96077346801759,43.2297735870938/zoom/16?utm_medium=widget-source&amp;utm_campaign=firmsonmap&amp;utm_source=bigMap\">Посмотреть на карте Алматы</a>\r\n<div class=\"dg-widget-link\" style=\"display: none;\"><a href=\"http://2gis.kz/almaty/center/76.960774,43.22961/zoom/16/routeTab/rsType/bus/to/76.960774,43.22961?Республиканский центр подготовки и повышения квалификации?utm_medium=widget-source&amp;utm_campaign=firmsonmap&amp;utm_source=route\">Найти проезд до Республиканский центр подготовки и повышения квалификации</a></div>\r\n<iframe style=\"border: 1px solid #a3a3a3; box-sizing: border-box;\" src=\"https://widgets.2gis.com/widget?type=firmsonmap&amp;options=%7B%22pos%22%3A%7B%22lat%22%3A43.2297735870938%2C%22lon%22%3A76.96077346801759%2C%22zoom%22%3A16%7D%2C%22opt%22%3A%7B%22city%22%3A%22almaty%22%7D%2C%22org%22%3A%2270000001029834301%22%7D\" width=\"100%\" height=\"600\" frameborder=\"no\"></iframe><noscript style=\"color: #c00; font-size: 16px; font-weight: bold;\">Виджет карты использует JavaScript. Включите его в настройках вашего браузера.</noscript></div>\r\n</div>\r\n</div>\r\n</div>', NULL, 'rich_text_box', 17, 'Site'),
(24, 'site.faq', 'Часто задаваемые вопросы', '<div class=\"section\"><br />\r\n<h1 class=\"text-center\">Часто задаваемые вопросы</h1>\r\n<br />\r\n<div id=\"accordion\" class=\"panel-group\">\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse1\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Кем проводится данное мероприятие?</a></h4>\r\n</div>\r\n<div id=\"collapse1\" class=\"panel-collapse collapse\">\r\n<div class=\"panel-body\">\r\n<p><span style=\"font-size: 16px;\">Квалификационной комиссией Республиканского центра подготовки и повышения квалификации в состав, которого входят инспекторы Департамента по чрезвычайным ситуациям и Государственной инспекции труда.</span></p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse2\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Обязательно ли проходить обучение по Безопасности и Охране труда и Пожарной безопасности?</a></h4>\r\n</div>\r\n<div id=\"collapse2\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<p><span style=\"font-size: 16px;\">В соответствии с Приказом МЗиСР РК от 25.12.2015 №1019 и МЧС РК от 9.06.2014 года № 276 (с изменениями и дополнениями Приказом МВД РК от 16.09.2015 года № 777) Руководящие и ответственные работники, периодически, не реже одного раза в три года обязаны проходить обучение.</span></p>\r\n<p><span style=\"font-size: 16px;\">Согласно совместного Приказа&nbsp; Министра здравоохранения и социального развития Республики Казахстан от 25 декабря 2015 года № 1022 и Министра национальной экономики Республики Казахстан от 28 декабря 2015 года № 801 обучение и наличие сертификата является необходимым и учитывается при проведении проверок надзорными органами, независимо от вида деятельности.</span></p>\r\n<p><span style=\"font-size: 16px;\">Согласно совместного Приказа Министра внутренних дел Республики Казахстан от 2 мая 2017 года № 307 и Министра национальной экономики Республики Казахстан от 20 июня 2017 года № 246 обучение и наличие сертификата является необходимым и учитывается при проведении проверок надзорными органами, независимо от вида деятельности.</span></p>\r\n<p><span style=\"font-size: 16px;\">Более того, по официальным сведениям, в Казахстане за 2017 год зарегистрировано более 15 438 пожаров. Все это привело к возбуждению административных и уголовных дел.&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse3\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Кто должен проходить обучение по Безопасности и Охране труда?</a></h4>\r\n</div>\r\n<div id=\"collapse3\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 16px;\">Согласно п. 21 Приказа МЗиСР РК от 25.12.2015 №1019 Руководящие и ответственные работники, периодически, не реже одного раза в три года обязаны проходить обучение.</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-size: 16px;\">Перечень &laquo;руководящих&raquo; работников определен Приказом МТиСЗ от №201</span></p>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse4\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Кто должен проходить обучение по Пожарно-техническому минимуму?</a></h4>\r\n</div>\r\n<div id=\"collapse4\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<p><span style=\"font-size: 16px;\">Согласно п. 28 МЧС РК от 9.06.2014 года № 276 (с изменениями и дополнениями Приказом МВД РК от 16.09.2015 года № 777) Руководящие и ответственные работники, периодически, не реже одного раза в три года обязаны проходить обучение.</span></p>\r\n<p><span style=\"font-size: 16px;\">Перечень &laquo;руководящих&raquo; работников определен Приказом МТиСЗ от №201</span></p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse5\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Кем финансируется обучение?</a></h4>\r\n</div>\r\n<div id=\"collapse5\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<p><span style=\"font-size: 16px;\">Согласно п. 3, ст. 180 Трудового Кодекса Финансирование данных мероприятий осуществляется за счет средств работодателя.&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse6\" data-toggle=\"collapse\" data-parent=\"#accordion\"> Что входит в стоимость обучения?</a></h4>\r\n</div>\r\n<div id=\"collapse6\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<div><span style=\"font-size: 16px;\">&bull; Обучение по вопросам БиОТ и ПТМ проводиться с участием ПОЛКОВНИКА ЗАПАСА с Департамента по чрезвычайным ситуациям;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; На обучении заседают государственные инспекторы ДЧС и Государственной инспекции труда;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; Журнал по пожарной безопасности;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; Раздаточный материал;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; Выездной семинар (более 10 человек) + консультативный аудит на соответствие требованиям безопасности и охране труда в организациях;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; Проведение онлайн обучения;</span></div>\r\n<div><span style=\"font-size: 16px;\">&bull; По завершению выдается Сертификат (удостоверение) государственного образца, подписанный государственным инспектором, действующий сроком до 3 лет.</span></div>\r\n<div>&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"panel panel-default\">\r\n<div class=\"panel-heading\">\r\n<h4 class=\"panel-title\"><a style=\"font-size: 22px; font-weight: bold; color: white;\" href=\"#collapse7\" data-toggle=\"collapse\" data-parent=\"#accordion\"> А мы уже проходили обучение в самом ДЧС!</a></h4>\r\n</div>\r\n<div id=\"collapse7\" class=\"panel-collapse collapse \">\r\n<div class=\"panel-body\">\r\n<p><span style=\"font-size: 16px;\">На самом деле ДЧС проводит обучение, которое регулируется Законом о Гражданской защите.</span></p>\r\n<p><span style=\"font-size: 16px;\">&laquo;Ресупбликанский центр подготовки и повышения квалификации&raquo; проводит обучение в рамках Приказов №1019 и №276, где выдается удостоверение и&nbsp; сертификат гос. образца.</span></p>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', NULL, 'rich_text_box', 18, 'Site'),
(25, 'site.ref', 'Ссылка на опрос', 'https://docs.google.com/forms/d/e/1FAIpQLSfinpocs-xachpsDPGZnUoPFGOdMk0Wgc9T10dragTk5pNc6w/viewform?vc=0&c=0&w=1', NULL, 'text', 19, 'Site');

-- --------------------------------------------------------

--
-- Структура таблицы `tests`
--

CREATE TABLE `tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tests`
--

INSERT INTO `tests` (`id`, `title`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 'Антитеррор - каз', 1, '2021-01-08 11:46:26', '2021-01-21 05:05:38'),
(2, 'Index', NULL, '2021-01-12 01:06:09', '2021-01-12 01:06:09'),
(3, 'Антитеррор - рус', 3, '2021-01-21 16:43:45', '2021-01-21 16:43:47'),
(4, 'БиОТ - рус', 4, NULL, NULL),
(5, 'БиОТ - каз', 5, NULL, NULL),
(6, 'Парамедика - рус', 6, NULL, NULL),
(7, 'Парамедика - каз', 7, NULL, NULL),
(8, 'ПТМ - рус', 8, NULL, NULL),
(9, 'ПТМ - каз', 9, NULL, NULL),
(10, 'СЭЗ - каз', 10, NULL, NULL),
(11, 'СЭЗ - рус', 11, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `translations`
--

CREATE TABLE `translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `role_id`, `company_name`, `fullname`, `position`, `phone`, `email`, `avatar`, `email_verified_at`, `password`, `remember_token`, `settings`, `created_at`, `updated_at`) VALUES
(2, 1, '123456', 'Иван Иванов', 'root', '+7(777) 777-77-77', 'a@gmail.com', 'users/default.png', NULL, '$2y$10$zDZpBjPBeDo/Ythyb8Svae/MVBGjXFHNMIyy0129IO1k/axQyR1ya', 'T4wr7dM3GSDUw2tNVkz8kFrt7R6FcGqvK3iivU4m94kV2bxn0EdZBSMj1azp', NULL, '2021-01-06 12:36:17', '2021-01-08 03:33:07'),
(3, 2, '12345678', 'L Lawliet', 'root', '877777777', 'a.kadirov.17.06@gmail.com', 'users/default.png', '2021-01-12 03:33:40', '$2y$10$.Fkw43x7EWM//.ZfkNP3eeKBxKYLs4XzoYsNMdf62RnRDbUQrc51W', NULL, NULL, '2021-01-11 07:12:27', '2021-01-12 03:33:40');

-- --------------------------------------------------------

--
-- Структура таблицы `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `vacancies`
--

CREATE TABLE `vacancies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `vacancies`
--

INSERT INTO `vacancies` (`id`, `title`, `salary`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Vacanchy 1', '100 000 - 200 000 $', '<pre style=\"background-color: #2b2b2b; color: #a9b7c6; font-family: \'JetBrains Mono\',monospace; font-size: 9,8pt;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur corporis doloremque eaque, eius eveniet facere numquam. Accusantium corporis distinctio dolor eius eligendi id natus perspiciatis qui recusandae vero. Accusantium, dolore.</pre>\r\n<pre style=\"font-family: \'JetBrains Mono\', monospace;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur corporis doloremque eaque, eius eveniet facere numquam. Accusantium corporis distinctio dolor eius eligendi id natus perspiciatis qui recusandae vero. Accusantium, dolore.</pre>\r\n<pre style=\"font-family: \'JetBrains Mono\', monospace;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur corporis doloremque eaque, eius eveniet facere numquam. Accusantium corporis distinctio dolor eius eligendi id natus perspiciatis qui recusandae vero. Accusantium, dolore.</pre>\r\n<pre style=\"font-family: \'JetBrains Mono\', monospace;\">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur corporis doloremque eaque, eius eveniet facere numquam. Accusantium corporis distinctio dolor eius eligendi id natus perspiciatis qui recusandae vero. Accusantium, dolore.</pre>', '2021-01-08 11:46:09', '2021-01-08 11:46:09');

-- --------------------------------------------------------

--
-- Структура таблицы `vacancy_bids`
--

CREATE TABLE `vacancy_bids` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacancy_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `vacancy_bids`
--

INSERT INTO `vacancy_bids` (`id`, `name`, `phone`, `text`, `vacancy_id`, `created_at`, `updated_at`) VALUES
(1, 'asdsgf', 'afgds', 'afegsh', 1, '2021-01-20 04:57:55', '2021-01-20 04:57:55');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `community_blocks`
--
ALTER TABLE `community_blocks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `course_codes`
--
ALTER TABLE `course_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_codes_course_id_foreign` (`course_id`),
  ADD KEY `course_codes_user_id_foreign` (`user_id`);

--
-- Индексы таблицы `data_rows`
--
ALTER TABLE `data_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_rows_data_type_id_foreign` (`data_type_id`);

--
-- Индексы таблицы `data_types`
--
ALTER TABLE `data_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_types_name_unique` (`name`),
  ADD UNIQUE KEY `data_types_slug_unique` (`slug`);

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Индексы таблицы `header_slides`
--
ALTER TABLE `header_slides`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `materials_course_id_foreign` (`course_id`);

--
-- Индексы таблицы `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Индексы таблицы `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- Индексы таблицы `metas`
--
ALTER TABLE `metas`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `options_question_id_foreign` (`question_id`);

--
-- Индексы таблицы `organization_blocks`
--
ALTER TABLE `organization_blocks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `org_sliders`
--
ALTER TABLE `org_sliders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_key_index` (`key`);

--
-- Индексы таблицы `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Индексы таблицы `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_test_id_foreign` (`test_id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Индексы таблицы `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Индексы таблицы `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tests_course_id_foreign` (`course_id`);

--
-- Индексы таблицы `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Индексы таблицы `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `user_roles_user_id_index` (`user_id`),
  ADD KEY `user_roles_role_id_index` (`role_id`);

--
-- Индексы таблицы `vacancies`
--
ALTER TABLE `vacancies`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `vacancy_bids`
--
ALTER TABLE `vacancy_bids`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vacancy_bids_vacancy_id_foreign` (`vacancy_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `bids`
--
ALTER TABLE `bids`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `community_blocks`
--
ALTER TABLE `community_blocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `course_codes`
--
ALTER TABLE `course_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `data_rows`
--
ALTER TABLE `data_rows`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT для таблицы `data_types`
--
ALTER TABLE `data_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `header_slides`
--
ALTER TABLE `header_slides`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `materials`
--
ALTER TABLE `materials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `metas`
--
ALTER TABLE `metas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT для таблицы `options`
--
ALTER TABLE `options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1845;

--
-- AUTO_INCREMENT для таблицы `organization_blocks`
--
ALTER TABLE `organization_blocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `org_sliders`
--
ALTER TABLE `org_sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT для таблицы `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=487;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `tests`
--
ALTER TABLE `tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `vacancies`
--
ALTER TABLE `vacancies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `vacancy_bids`
--
ALTER TABLE `vacancy_bids`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `course_codes`
--
ALTER TABLE `course_codes`
  ADD CONSTRAINT `course_codes_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `data_rows`
--
ALTER TABLE `data_rows`
  ADD CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `materials`
--
ALTER TABLE `materials`
  ADD CONSTRAINT `materials_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Ограничения внешнего ключа таблицы `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `vacancy_bids`
--
ALTER TABLE `vacancy_bids`
  ADD CONSTRAINT `vacancy_bids_vacancy_id_foreign` FOREIGN KEY (`vacancy_id`) REFERENCES `vacancies` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
