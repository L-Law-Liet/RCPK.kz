@extends('layouts.app')
@section('content')
    <div class="pt-5 d-flex justify-content-center">
        <div class="mt-5 pt-3" style="color: #255dcf">
            <h2>@lang('loc.thanks_pass_test')</h2>
            <p class="text-center mt-3">@lang('loc.result_materials')</p>
        </div>
    </div>
@endsection
