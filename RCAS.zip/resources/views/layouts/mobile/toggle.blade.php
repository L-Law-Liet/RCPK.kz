
<button class="navbar-toggle navbar-toggle_open d-lg-none">
    <span class="icon-bar speed"></span>
    <span class="icon-bar speed"></span>
    <span class="icon-bar speed"></span>
</button>
