
<div class="d-lg-none d-flex align-items-center justify-content-between">
    <div class="logo"><img src="{{asset('img/logo.png')}}" alt="Логотип"></div>
    <button class="navbar-toggle active d-lg-none">
        <span class="icon-bar speed"></span>
        <span class="icon-bar speed"></span>
        <span class="icon-bar speed"></span>
    </button>
</div>
