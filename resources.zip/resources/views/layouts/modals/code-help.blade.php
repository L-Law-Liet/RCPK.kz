
<!-- Modal -->

<div class="modal_code_1 modal_code_code">
    <div class="fullScreen flex-center">
        <div class="modal__box__code">
            <div class="modal__head text-center">
                <button id="codeClose" class="modal__close__code">X</button>
                <h2>@lang('loc.how_get_code')</h2>
            </div>
            <div class="modal__body">
                <p>@lang('loc.need_to_link_manager_no'): <br> <a href="tel:+77273645400">+7 (727) 364-54-00</a></p>
            </div>
        </div>
    </div>
</div>
